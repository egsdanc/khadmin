/*
  # Bayi Tablosu Alan Güncellemesi

  1. Yeni Alanlar
    - `il` (text): Bayinin bulunduğu il
    - `ilce` (text): Bayinin bulunduğu ilçe
    - `adres` (text): Bayinin açık adresi
    - `sabit_ip` (text): Bayinin sabit IP adresi
    - `yuzde_oran` (decimal): Firmanın bayiden alacağı pay oranı (%)
    - `telefon` (text): Bayi telefon numarası
    - `email` (text): Bayi e-posta adresi

  2. Kısıtlamalar
    - E-posta adresi unique olmalı
    - Yüzde oran 0-100 arasında olmalı
    - Telefon, il, ilçe ve adres zorunlu alanlar

  3. Güvenlik
    - RLS politikaları güncellendi
*/

-- Yeni alanları ekle
ALTER TABLE bayiler 
  ADD COLUMN IF NOT EXISTS il text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS ilce text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS adres text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS sabit_ip text,
  ADD COLUMN IF NOT EXISTS yuzde_oran decimal(5,2) DEFAULT 10.00,
  ADD COLUMN IF NOT EXISTS telefon text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS email text NOT NULL DEFAULT '';

-- Varsayılan değerleri kaldır
ALTER TABLE bayiler 
  ALTER COLUMN il DROP DEFAULT,
  ALTER COLUMN ilce DROP DEFAULT,
  ALTER COLUMN adres DROP DEFAULT,
  ALTER COLUMN telefon DROP DEFAULT,
  ALTER COLUMN email DROP DEFAULT;

-- E-posta için unique constraint ekle
ALTER TABLE bayiler
  ADD CONSTRAINT bayiler_email_unique UNIQUE (email);

-- Yüzde oran için check constraint ekle
ALTER TABLE bayiler
  ADD CONSTRAINT bayiler_yuzde_oran_check 
  CHECK (yuzde_oran >= 0 AND yuzde_oran <= 100);

-- RLS politikalarını güncelle
CREATE POLICY "Firmalar kendi bayilerini görebilir"
  ON bayiler
  FOR SELECT
  TO authenticated
  USING (
    auth.uid() IN (
      SELECT id FROM kullanicilar 
      WHERE firma = bayiler.firma
    )
  );

CREATE POLICY "Firmalar kendi bayilerini ekleyebilir"
  ON bayiler
  FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() IN (
      SELECT id FROM kullanicilar 
      WHERE firma = bayiler.firma
    )
  );

CREATE POLICY "Firmalar kendi bayilerini güncelleyebilir"
  ON bayiler
  FOR UPDATE
  TO authenticated
  USING (
    auth.uid() IN (
      SELECT id FROM kullanicilar 
      WHERE firma = bayiler.firma
    )
  )
  WITH CHECK (
    auth.uid() IN (
      SELECT id FROM kullanicilar 
      WHERE firma = bayiler.firma
    )
  );