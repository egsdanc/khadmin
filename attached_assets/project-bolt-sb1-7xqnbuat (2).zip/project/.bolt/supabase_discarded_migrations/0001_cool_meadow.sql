/*
  # Initial Schema Migration

  1. Mevcut Tablolar
    - bayiler
    - kullanicilar
    - diğer tablolar...

  2. Yeni Alanlar
    - Bayi tablosu için yeni alanlar
    - Güvenlik politikaları
*/

-- Enable RLS
ALTER TABLE bayiler ENABLE ROW LEVEL SECURITY;

-- Create initial schema
CREATE TABLE IF NOT EXISTS bayiler (
  id SERIAL PRIMARY KEY,
  ad TEXT NOT NULL,
  firma INTEGER NOT NULL,
  aktif BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  il TEXT NOT NULL,
  ilce TEXT NOT NULL,
  adres TEXT NOT NULL,
  sabit_ip TEXT,
  yuzde_oran DECIMAL(5,2) DEFAULT 10.00,
  telefon TEXT NOT NULL,
  email TEXT NOT NULL,
  CONSTRAINT bayiler_email_unique UNIQUE (email),
  CONSTRAINT bayiler_yuzde_oran_check CHECK (yuzde_oran >= 0 AND yuzde_oran <= 100)
);

-- Create RLS policies
CREATE POLICY "Firmalar kendi bayilerini görebilir"
  ON bayiler
  FOR SELECT
  TO authenticated
  USING (
    auth.uid() IN (
      SELECT id FROM kullanicilar 
      WHERE firma = bayiler.firma
    )
  );

CREATE POLICY "Firmalar kendi bayilerini ekleyebilir"
  ON bayiler
  FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() IN (
      SELECT id FROM kullanicilar 
      WHERE firma = bayiler.firma
    )
  );

CREATE POLICY "Firmalar kendi bayilerini güncelleyebilir"
  ON bayiler
  FOR UPDATE
  TO authenticated
  USING (
    auth.uid() IN (
      SELECT id FROM kullanicilar 
      WHERE firma = bayiler.firma
    )
  )
  WITH CHECK (
    auth.uid() IN (
      SELECT id FROM kullanicilar 
      WHERE firma = bayiler.firma
    )
  );

-- Add updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_bayiler_updated_at
    BEFORE UPDATE ON bayiler
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();