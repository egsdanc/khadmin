/*
  # Bayi tablosu güncellemesi

  1. Yeni Alanlar
    - `il` (text): Bayinin bulunduğu il
    - `ilce` (text): Bayinin bulunduğu ilçe
    - `adres` (text): Bayinin açık adresi
    - `sabit_ip` (text): Bayinin sabit IP adresi
    - `yuzde_oran` (decimal): Bayinin yüzde oranı
    - `telefon` (text): Bayi telefon numarası
    - `email` (text): Bayi e-posta adresi

  2. Değişiklikler
    - Mevcut tabloya yeni alanlar ekleniyor
    - Yüzde oran için varsayılan değer 90.00 olarak ayarlanıyor
    - E-posta için unique constraint ekleniyor
*/

-- Yeni alanları ekle
ALTER TABLE bayiler 
  ADD COLUMN IF NOT EXISTS il text,
  ADD COLUMN IF NOT EXISTS ilce text,
  ADD COLUMN IF NOT EXISTS adres text,
  ADD COLUMN IF NOT EXISTS sabit_ip text,
  ADD COLUMN IF NOT EXISTS yuzde_oran decimal(5,2) DEFAULT 90.00,
  ADD COLUMN IF NOT EXISTS telefon text,
  ADD COLUMN IF NOT EXISTS email text;

-- E-posta için unique constraint ekle
ALTER TABLE bayiler
  ADD CONSTRAINT bayiler_email_unique UNIQUE (email);

-- Yüzde oran için check constraint ekle
ALTER TABLE bayiler
  ADD CONSTRAINT bayiler_yuzde_oran_check 
  CHECK (yuzde_oran >= 0 AND yuzde_oran <= 100);