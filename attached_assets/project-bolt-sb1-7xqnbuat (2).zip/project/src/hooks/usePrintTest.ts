import { useRef } from 'react';
import { useReactToPrint } from 'react-to-print';

export function usePrintTest() {
  const componentRef = useRef<HTMLDivElement>(null);

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
    documentTitle: 'Test Raporu',
    removeAfterPrint: true,
    pageStyle: `
      @page {
        size: A4;
        margin: 15mm;
      }
      
      @media print {
        body {
          margin: 0;
          padding: 0;
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
        }
        
        table { page-break-inside: auto; }
        tr { page-break-inside: avoid; }
      }
    `,
    onBeforeGetContent: () => {
      return new Promise((resolve) => {
        setTimeout(resolve, 250);
      });
    },
    suppressErrors: true
  });

  return {
    componentRef,
    handlePrint
  };
}