import { useState, useEffect } from 'react';

// Mock veri
const mockUsers = [
  {
    id: 1,
    isim: 'tuzla',
    sifre: 'tuzla12345',
    macAddress: '34:F6:4B:7B:F9:4E',
    firstLogin: true,
    firma: 1,
    bayi: 1
  },
  {
    id: 2,
    isim: 'kadikoy',
    sifre: 'kadikoy12345',
    macAddress: '34:F6:4B:7B:F9:4F',
    firstLogin: true,
    firma: 1,
    bayi: 2
  },
  {
    id: 3,
    isim: 'maltepe',
    sifre: 'maltepe12345',
    macAddress: 'ASDFGHJK',
    firstLogin: false,
    firma: 2,
    bayi: 3
  }
];

export function useProgramUserFilters() {
  const [filters, setFilters] = useState({
    search: '',
    firstLogin: '',
    firma: '',
    bayi: ''
  });

  const [filteredUsers, setFilteredUsers] = useState(mockUsers);

  useEffect(() => {
    let result = [...mockUsers];

    // Arama filtresi
    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      result = result.filter(user => 
        user.isim.toLowerCase().includes(searchLower) ||
        user.macAddress.toLowerCase().includes(searchLower)
      );
    }

    // First Login filtresi
    if (filters.firstLogin !== '') {
      const isFirstLogin = filters.firstLogin === 'true';
      result = result.filter(user => user.firstLogin === isFirstLogin);
    }

    // Firma filtresi
    if (filters.firma) {
      result = result.filter(user => user.firma === parseInt(filters.firma));
    }

    // Bayi filtresi
    if (filters.bayi) {
      result = result.filter(user => user.bayi === parseInt(filters.bayi));
    }

    setFilteredUsers(result);
  }, [filters]);

  const handleFilterChange = (key: string, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  return {
    filters,
    filteredUsers,
    handleFilterChange
  };
}