import { useState, useEffect } from 'react';

// Test verilerini oluşturan yardımcı fonksiyon
const generateTestData = () => {
  const data = [];
  const startDate = new Date('2024-01-01');
  
  for (let i = 0; i < 25; i++) { // 25 test verisi oluştur
    const date = new Date(startDate);
    date.setDate(date.getDate() + i);
    
    data.push({
      id: i + 1,
      plaka: `34 FL ${2346 + i}`,
      markaModel: 'FIAT',
      saseNo: `NM422500006873${975 + i}`,
      motorNo: `199A90005542${258 + i}`,
      kontrolMod: 'OBD',
      km: `${176673 + (i * 1000)}`,
      ucret: 500,
      aciklama: 'Test başarılı',
      tarih: date.toISOString(),
      details: [
        { id: i * 10 + 1, moduleName: 'Powertrain Control Module 1', value: `${176673 + (i * 1000)}`, time: date.toISOString() },
        { id: i * 10 + 2, moduleName: 'Engine Control Module DPF ReGen', value: '833', time: date.toISOString() },
        { id: i * 10 + 3, moduleName: 'Engine Control Module', value: '329095 Minutes', time: date.toISOString() }
      ]
    });
  }
  
  return data;
};

export function useTestData() {
  const [testData, setTestData] = useState(generateTestData());

  useEffect(() => {
    // İleride gerçek API çağrısı yapılacak
    setTestData(generateTestData());
  }, []);

  return {
    testData
  };
}