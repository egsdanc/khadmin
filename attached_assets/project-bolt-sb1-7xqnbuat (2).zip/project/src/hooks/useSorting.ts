import { useState, useMemo } from 'react';

type SortDirection = 'asc' | 'desc';

interface UseSortingProps<T> {
  data: T[];
  defaultSortField?: keyof T;
  defaultDirection?: SortDirection;
}

export function useSorting<T>({ 
  data, 
  defaultSortField, 
  defaultDirection = 'asc' 
}: UseSortingProps<T>) {
  const [sortField, setSortField] = useState<keyof T | undefined>(defaultSortField);
  const [sortDirection, setSortDirection] = useState<SortDirection>(defaultDirection);

  const sortedData = useMemo(() => {
    if (!sortField) return data;

    return [...data].sort((a, b) => {
      const aValue = a[sortField];
      const bValue = b[sortField];

      if (aValue === bValue) return 0;
      
      const comparison = aValue < bValue ? -1 : 1;
      return sortDirection === 'asc' ? comparison : -comparison;
    });
  }, [data, sortField, sortDirection]);

  const handleSort = (field: keyof T) => {
    if (field === sortField) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  return {
    sortedData,
    sortField,
    sortDirection,
    handleSort
  };
}