import { useState, useEffect } from 'react';
import { User } from '../../types/auth';

interface UserFilters {
  search: string;
  role: string;
  firma: string;
  aktif: string;
}

export function useUserFilters(users: User[]) {
  const [filters, setFilters] = useState<UserFilters>({
    search: '',
    role: '',
    firma: '',
    aktif: ''
  });

  const [filteredUsers, setFilteredUsers] = useState<User[]>(users);

  useEffect(() => {
    let result = [...users];

    // Search filter
    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      result = result.filter(user => 
        user.ad.toLowerCase().includes(searchLower) ||
        user.email.toLowerCase().includes(searchLower)
      );
    }

    // Role filter
    if (filters.role) {
      result = result.filter(user => user.role === parseInt(filters.role));
    }

    // Company filter
    if (filters.firma) {
      result = result.filter(user => user.firma === parseInt(filters.firma));
    }

    // Status filter
    if (filters.aktif !== '') {
      const isActive = filters.aktif === 'true';
      result = result.filter(user => user.aktif === isActive);
    }

    setFilteredUsers(result);
  }, [users, filters]);

  const handleFilterChange = (key: string, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  return {
    filters,
    filteredUsers,
    handleFilterChange
  };
}