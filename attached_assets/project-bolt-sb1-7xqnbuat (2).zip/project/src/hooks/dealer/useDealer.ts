import { useEffect, useState } from 'react';
import { useDealerStore } from '../../store/dealer.store';
import { Dealer } from '../../types/dealer.types';

interface DealerFilters {
  search: string;
  firma: string;
  il: string;
  aktif: string;
}

export function useDealer() {
  const { dealers, loading, error, fetchDealers } = useDealerStore();
  const [filteredDealers, setFilteredDealers] = useState<Dealer[]>([]);
  const [filters, setFilters] = useState<DealerFilters>({
    search: '',
    firma: '',
    il: '',
    aktif: ''
  });

  useEffect(() => {
    fetchDealers().catch(console.error);
  }, [fetchDealers]);

  useEffect(() => {
    if (!dealers) return;

    let result = [...dealers];

    // Arama filtresi
    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      result = result.filter(
        dealer =>
          dealer.ad.toLowerCase().includes(searchLower) ||
          dealer.tel.toLowerCase().includes(searchLower) ||
          dealer.mail.toLowerCase().includes(searchLower)
      );
    }

    // Firma filtresi
    if (filters.firma) {
      result = result.filter(dealer => dealer.firma === parseInt(filters.firma));
    }

    // İl filtresi
    if (filters.il) {
      result = result.filter(dealer => dealer.il === filters.il);
    }

    // Durum filtresi
    if (filters.aktif !== '') {
      const isActive = filters.aktif === 'true';
      result = result.filter(dealer => dealer.aktif === isActive);
    }

    setFilteredDealers(result);
  }, [dealers, filters]);

  const handleFilterChange = (key: string, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  return {
    dealers: filteredDealers,
    loading,
    error,
    filters,
    handleFilterChange,
    isApiHealthy: true
  };
}