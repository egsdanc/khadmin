import { useState, useEffect } from 'react';
import { BalanceTransaction } from '../types/balance.types';
import { balanceApi } from '../services/balance/balance.api';
import toast from 'react-hot-toast';

export function useBalanceTransactions(dealerId: number) {
  const [transactions, setTransactions] = useState<BalanceTransaction[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchTransactions = async () => {
    try {
      const data = await balanceApi.getTransactions(dealerId);
      setTransactions(data);
    } catch (error) {
      toast.error('İşlem geçmişi alınamadı');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTransactions();
  }, [dealerId]);

  return {
    transactions,
    loading,
    refetch: fetchTransactions
  };
}