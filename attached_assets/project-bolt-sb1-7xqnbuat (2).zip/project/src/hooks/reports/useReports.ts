import { useState } from 'react';
import { ReportsService } from '../../services/reports/reports.service';
import type { 
  TestReport, 
  DealerReport, 
  RevenueReport, 
  ReportFilters 
} from '../../types/reports.types';

export function useReports() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [testReports, setTestReports] = useState<TestReport[]>([]);
  const [dealerReports, setDealerReports] = useState<DealerReport[]>([]);
  const [revenueReport, setRevenueReport] = useState<RevenueReport | null>(null);

  const fetchTestReports = async (filters: ReportFilters) => {
    try {
      setLoading(true);
      const data = await ReportsService.getTestReports(filters);
      setTestReports(data);
      setError(null);
    } catch (err) {
      setError('Test raporları alınırken bir hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  const fetchDealerReports = async (filters: ReportFilters) => {
    try {
      setLoading(true);
      const data = await ReportsService.getDealerReports(filters);
      setDealerReports(data);
      setError(null);
    } catch (err) {
      setError('Bayi raporları alınırken bir hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  const fetchRevenueReport = async (filters: ReportFilters) => {
    try {
      setLoading(true);
      const data = await ReportsService.getRevenueReport(filters);
      setRevenueReport(data);
      setError(null);
    } catch (err) {
      setError('Gelir raporu alınırken bir hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  const exportReport = async (reportType: string, filters: ReportFilters) => {
    try {
      setLoading(true);
      const blob = await ReportsService.exportToExcel(reportType, filters);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${reportType}-report.xlsx`;
      a.click();
      window.URL.revokeObjectURL(url);
      setError(null);
    } catch (err) {
      setError('Rapor dışa aktarılırken bir hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    error,
    testReports,
    dealerReports,
    revenueReport,
    fetchTestReports,
    fetchDealerReports,
    fetchRevenueReport,
    exportReport
  };
}