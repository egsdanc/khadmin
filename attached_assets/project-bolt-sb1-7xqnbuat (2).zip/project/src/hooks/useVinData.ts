import { useState, useEffect } from 'react';

// VIN test verilerini oluşturan yardımcı fonksiyon
const generateVinData = () => {
  const data = [];
  const startDate = new Date('2024-01-01');
  
  for (let i = 0; i < 25; i++) {
    const date = new Date(startDate);
    date.setDate(date.getDate() + i);
    
    data.push({
      id: i + 1,
      plaka: `34 ABC ${123 + i}`,
      sase: `ZFA19900000${533645 + i}`,
      motor: 'Q',
      paket: 'Vin Hacker Paketi',
      ucret: 500,
      aciklama: 'VIN test başarılı',
      kontrolmod: 'FIAT',
      vin1: `ZFA19900000${533645 + i}`,
      vin2: `ZFA19900000${533645 + i}`,
      vin3: '',
      userid: 6,
      tarih: date.toISOString(),
      details: [
        { id: i * 10 + 1, moduleName: 'EOBD Engine Control Module', value: `ZFA19900000${533645 + i}`, value2: `ZFA19900000${533645 + i}` },
        { id: i * 10 + 2, moduleName: 'Powertrain Control Module', value: `ZFA19900000${533645 + i}`, value2: `ZFA19900000${533645 + i}` },
        { id: i * 10 + 3, moduleName: 'Body Control Module', value: `ZFA19900000${533645 + i}`, value2: `ZFA19900000${533645 + i}` }
      ]
    });
  }
  
  return data;
};

export function useVinData() {
  const [vinData, setVinData] = useState(generateVinData());

  useEffect(() => {
    // İleride gerçek API çağrısı yapılacak
    setVinData(generateVinData());
  }, []);

  return {
    vinData
  };
}