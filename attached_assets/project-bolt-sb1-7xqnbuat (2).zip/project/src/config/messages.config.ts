export const API_MESSAGES = {
  NETWORK_ERROR: 'Ağ bağlantısı hatası. Lütfen internet bağlantınızı kontrol edin.',
  SERVER_UNREACHABLE: 'API sunucusuna bağlanılamıyor. Lütfen sunucunun çalıştığından emin olun.',
  SESSION_EXPIRED: 'Oturum süreniz doldu. Lütfen tekrar giriş yapın.',
  GENERIC_ERROR: 'Bir hata oluştu. Lütfen tekrar deneyin.',
  DEALER: {
    CREATE_SUCCESS: 'Bayi başarıyla eklendi',
    CREATE_ERROR: 'Bayi eklenirken bir hata oluştu',
    FETCH_ERROR: 'Bayiler alınırken bir hata oluştu',
    UPDATE_SUCCESS: 'Bayi başarıyla güncellendi',
    UPDATE_ERROR: 'Bayi güncellenirken bir hata oluştu',
    DELETE_SUCCESS: 'Bayi başarıyla silindi',
    DELETE_ERROR: 'Bayi silinirken bir hata oluştu'
  }
} as const;