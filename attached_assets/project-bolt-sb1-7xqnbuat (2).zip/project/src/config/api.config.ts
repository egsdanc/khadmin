export const API_CONFIG = {
  baseURL: 'http://149.202.76.5/api',
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  }
} as const;

export const API_MESSAGES = {
  NETWORK_ERROR: 'Ağ bağlantısı hatası. Lütfen internet bağlantınızı kontrol edin.',
  SERVER_UNREACHABLE: 'API sunucusuna bağlanılamıyor. Lütfen sunucunun çalıştığından emin olun.',
  SESSION_EXPIRED: 'Oturum süreniz doldu. Lütfen tekrar giriş yapın.',
  GENERIC_ERROR: 'Bir hata oluştu. Lütfen tekrar deneyin.'
} as const;