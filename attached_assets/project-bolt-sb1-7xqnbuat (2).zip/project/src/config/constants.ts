export const APP_CONFIG = {
  APP_NAME: 'Kilometre Hacker',
  VERSION: '1.0.0'
} as const;

export const AUTH_MESSAGES = {
  LOGIN_SUCCESS: 'Giriş başarılı',
  LOGIN_FAILED: 'Giriş başarısız',
  LOGOUT_SUCCESS: 'Çıkış başarılı'
} as const;

export const TEST_FEE = 500; // Test ücreti (TL)