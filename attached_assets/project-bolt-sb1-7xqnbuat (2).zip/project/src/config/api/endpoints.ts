export const ENDPOINTS = {
  AUTH: {
    LOGIN: '/auth/login',
    LOGOUT: '/auth/logout',
    REFRESH: '/auth/refresh'
  },
  DEALERS: '/dealers',
  HEALTH: '/health',
  TESTS: '/tests',
  BALANCE: '/balance'
} as const;