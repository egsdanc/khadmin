export const API_CONFIG = {
  baseURL: 'http://149.202.76.5/api',
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  }
} as const;