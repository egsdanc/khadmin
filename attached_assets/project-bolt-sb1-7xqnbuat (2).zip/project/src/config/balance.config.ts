export const BALANCE_CONFIG = {
  TEST_FEE: 500,           // Sabit test ücreti
  COMPANY_SHARE_RATE: 0.10, // %10 firma payı
  KDV_RATE: 0.20,         // %20 KDV
  ADMIN_SHARE_RATE: 0.02,  // %2 admin payı
  DEALER_SHARE_RATE: 0.90  // %90 bayi payı
} as const;

export const BALANCE_MESSAGES = {
  INSUFFICIENT_BALANCE: 'Yetersiz bakiye',
  DEDUCTION_FAILED: 'Bakiye düşme işlemi başarısız',
  BALANCE_FETCH_FAILED: 'Bayi bakiyesi alınamadı',
  TRANSACTION_FAILED: 'İşlem gerçekleştirilemedi'
} as const;