import React from 'react';
import { useProgramKullaniciForm } from '../../hooks/useProgramKullaniciForm';
import { ProgramKullaniciForm } from '../ProgramKullaniciForm';
import { ProgramKullaniciFormActions } from './ProgramKullaniciFormActions';

export function ProgramKullaniciAdd() {
  const { formData, handleChange, handleSubmit, loading } = useProgramKullaniciForm();

  return (
    <div className="space-y-10">
      <form className="bg-white shadow-sm ring-1 ring-gray-900/5 rounded-xl" onSubmit={handleSubmit}>
        <div className="px-4 py-6 sm:p-8">
          <ProgramKullaniciForm
            formData={formData}
            onChange={handleChange}
          />
        </div>
        
        <ProgramKullaniciFormActions loading={loading} />
      </form>
    </div>
  );
}