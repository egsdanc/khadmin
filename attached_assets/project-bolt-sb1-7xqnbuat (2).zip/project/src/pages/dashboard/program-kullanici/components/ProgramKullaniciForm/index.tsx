import React from 'react';
import { Input } from '../../../../../components/ui/Input';
import { Select } from '../../../../../components/ui/Select';
import { ProgramKullaniciFormProps } from '../../types/program-kullanici.types';

export function ProgramKullaniciForm({ formData, onChange }: ProgramKullaniciFormProps) {
  return (
    <div className="space-y-6">
      <div className="bg-yellow-50 p-4 rounded-md">
        <p className="text-sm text-yellow-700">
          Lütfen program kullanıcı bilgilerini eksiksiz ve doğru doldurunuz. Program kullanıcısı eklerken First Login 
          Pasif olmalıdır. MAC adresini "ASDFGHJK" olarak giriniz. Bayi programda ilk giriş yaptığında MAC adresi 
          otomatik olarak güncellenecek ve First Login de Aktif durumuna gelecektir.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-x-6 gap-y-8">
        <div className="col-span-full">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Input
              label="İsim"
              name="isim"
              required
              placeholder="Kullanıcı ismini giriniz"
              value={formData.isim}
              onChange={onChange}
            />
            <Input
              label="Şifre"
              name="sifre"
              type="password"
              required
              placeholder="Şifre giriniz"
              value={formData.sifre}
              onChange={onChange}
            />
            <Input
              label="MAC Adresi"
              name="macAddress"
              required
              value="ASDFGHJK"
              readOnly
              onChange={onChange}
            />
            <Select
              label="First Login"
              name="firstLogin"
              required
              value="0"
              disabled
              onChange={onChange}
            >
              <option value="1">Aktif</option>
              <option value="0">Pasif</option>
            </Select>
            <Select
              label="Firma"
              name="firma"
              required
              value={formData.firma}
              onChange={onChange}
            >
              <option value="">Firma Seçiniz</option>
              <option value="1">Garantili Arabam</option>
              <option value="2">General Oto Ekspertiz</option>
              <option value="3">Dynobil</option>
            </Select>
            <Select
              label="Bayi"
              name="bayi"
              value={formData.bayi}
              onChange={onChange}
            >
              <option value="">Bayi Seçiniz</option>
              <option value="1">Ankara / Yenimahalle</option>
              <option value="2">İstanbul / Kadıköy</option>
              <option value="3">İzmir / Karşıyaka</option>
            </Select>
          </div>
        </div>
      </div>
    </div>
  );
}