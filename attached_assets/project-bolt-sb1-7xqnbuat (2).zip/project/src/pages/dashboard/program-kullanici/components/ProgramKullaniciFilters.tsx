import React from 'react';
import { Search } from 'lucide-react';
import { Input } from '../../../../components/ui/Input';
import { Select } from '../../../../components/ui/Select';

interface ProgramKullaniciFiltersProps {
  filters: {
    search: string;
    firstLogin: string;
  };
  onChange: (key: string, value: string) => void;
}

export function ProgramKullaniciFilters({ filters, onChange }: ProgramKullaniciFiltersProps) {
  return (
    <div className="bg-white shadow sm:rounded-lg mb-6">
      <div className="px-4 py-5 sm:p-6">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Input
            label="Arama"
            name="search"
            value={filters.search}
            onChange={(e) => onChange('search', e.target.value)}
            placeholder="Kullanıcı adı veya MAC adresi"
            icon={Search}
          />

          <Select
            label="First Login Durumu"
            value={filters.firstLogin}
            onChange={(e) => onChange('firstLogin', e.target.value)}
          >
            <option value="">Tümü</option>
            <option value="true">Aktif</option>
            <option value="false">Pasif</option>
          </Select>
        </div>
      </div>
    </div>
  );
}