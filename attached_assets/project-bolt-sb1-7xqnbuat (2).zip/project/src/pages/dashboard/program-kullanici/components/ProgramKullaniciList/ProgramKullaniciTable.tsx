import React from 'react';
import { Badge } from '../../../../../components/ui/Badge';
import { Button } from '../../../../../components/ui/Button';
import { ProgramKullanici } from '../../../../../types/program-kullanici.types';
import { Edit2, Trash2 } from 'lucide-react';

interface ProgramKullaniciTableProps {
  users: ProgramKullanici[];
  onEdit: (user: ProgramKullanici) => void;
  onDelete: (user: ProgramKullanici) => void;
}

export function ProgramKullaniciTable({ users, onEdit, onDelete }: ProgramKullaniciTableProps) {
  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                İsim
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                MAC Adresi
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                First Login
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Firma
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Bayi
              </th>
              <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                İşlemler
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {users.map((user) => (
              <tr key={user.id} className="hover:bg-gray-50 transition-colors">
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {user.isim}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 font-mono">
                  {user.macAddress}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm">
                  <Badge 
                    variant={user.firstLogin ? 'success' : 'secondary'}
                    className="capitalize"
                  >
                    {user.firstLogin ? 'Aktif' : 'Pasif'}
                  </Badge>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {user.firma ? getFirmaName(user.firma) : '-'}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {user.bayi ? getBayiName(user.bayi) : '-'}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <Button
                    onClick={() => onEdit(user)}
                    variant="secondary"
                    className="mr-2 inline-flex items-center"
                    size="sm"
                  >
                    <Edit2 className="h-4 w-4 mr-1" />
                    Düzenle
                  </Button>
                  <Button
                    onClick={() => onDelete(user)}
                    variant="danger"
                    className="inline-flex items-center"
                    size="sm"
                  >
                    <Trash2 className="h-4 w-4 mr-1" />
                    Sil
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// Yardımcı fonksiyonlar
function getFirmaName(firmaId: number): string {
  const firmalar: Record<number, string> = {
    1: 'Garantili Arabam',
    2: 'General Oto Ekspertiz',
    3: 'Dynobil'
  };
  return firmalar[firmaId] || 'Bilinmiyor';
}

function getBayiName(bayiId: number): string {
  const bayiler: Record<number, string> = {
    1: 'Ankara / Yenimahalle',
    2: 'İstanbul / Kadıköy',
    3: 'İzmir / Karşıyaka'
  };
  return bayiler[bayiId] || 'Bilinmiyor';
}