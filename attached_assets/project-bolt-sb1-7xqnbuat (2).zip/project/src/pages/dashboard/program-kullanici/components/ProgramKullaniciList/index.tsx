import React, { useState } from 'react';
import { ProgramKullaniciTable } from './ProgramKullaniciTable';
import { ProgramKullaniciFilters } from '../ProgramKullaniciFilters';
import { ProgramKullaniciEdit } from '../ProgramKullaniciEdit';
import { ProgramKullaniciDelete } from '../ProgramKullaniciDelete';
import { useProgramUserFilters } from '../../../../../hooks/program-user/useProgramUserFilters';
import { ProgramKullanici } from '../../../../../types/program-kullanici.types';
import toast from 'react-hot-toast';

export function ProgramKullaniciList() {
  const { filters, filteredUsers, handleFilterChange } = useProgramUserFilters();
  const [editingUser, setEditingUser] = useState<ProgramKullanici | null>(null);
  const [deletingUser, setDeletingUser] = useState<ProgramKullanici | null>(null);
  const [deleteLoading, setDeleteLoading] = useState(false);

  const handleDelete = async () => {
    if (!deletingUser) return;

    setDeleteLoading(true);
    try {
      // API çağrısı yapılacak
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success('Program kullanıcısı başarıyla silindi');
      setDeletingUser(null);
    } catch (error) {
      toast.error('Program kullanıcısı silinirken bir hata oluştu');
    } finally {
      setDeleteLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <ProgramKullaniciFilters 
        filters={filters}
        onChange={handleFilterChange}
      />

      <ProgramKullaniciTable 
        users={filteredUsers}
        onEdit={setEditingUser}
        onDelete={setDeletingUser}
      />

      {editingUser && (
        <ProgramKullaniciEdit 
          user={editingUser}
          onClose={() => setEditingUser(null)}
        />
      )}

      <ProgramKullaniciDelete
        isOpen={!!deletingUser}
        onClose={() => setDeletingUser(null)}
        onConfirm={handleDelete}
        userName={deletingUser?.isim || ''}
        loading={deleteLoading}
      />
    </div>
  );
}