import React from 'react';
import { Plus } from 'lucide-react';
import { Button } from '../../../../components/ui/Button';
import { useNavigate } from 'react-router-dom';

export function AddProgramUserButton() {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate('/dashboard/program-kullanicilar/ekle');
  };

  return (
    <Button
      onClick={handleClick}
      className="inline-flex items-center"
    >
      <Plus className="h-4 w-4 mr-2" />
      Kullanıcı Ekle
    </Button>
  );
}