import React from 'react';
import { Button } from '../../../../../components/ui/Button';

interface ProgramKullaniciFormActionsProps {
  loading: boolean;
}

export function ProgramKullaniciFormActions({ loading }: ProgramKullaniciFormActionsProps) {
  return (
    <div className="flex flex-col gap-4 border-t border-gray-900/10 px-4 py-4 sm:px-8">
      <p className="text-sm text-gray-600">
        Lütfen program kullanıcı bilgilerini eksiksiz doldurunuz.
      </p>
      <div className="flex justify-end">
        <Button
          type="submit"
          loading={loading}
          className="w-full sm:w-auto"
        >
          Program Kullanıcı Ekle
        </Button>
      </div>
    </div>
  );
}