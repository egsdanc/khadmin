export interface ProgramKullanici {
  id: number;
  isim: string;
  sifre: string;
  macAddress: string;
  firstLogin: boolean;
}

export interface ProgramKullaniciFormData {
  isim: string;
  sifre: string;
  macAddress: string;
  firstLogin: string;
}

export interface ProgramKullaniciFormProps {
  formData: ProgramKullaniciFormData;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
}