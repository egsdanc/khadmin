import React, { useState } from 'react';
import { UserCog } from 'lucide-react';
import { ProgramKullaniciTabs } from './components/ProgramKullaniciTabs';
import { ProgramKullaniciList } from './components/ProgramKullaniciList';
import { ProgramKullaniciAdd } from './components/ProgramKullaniciAdd';

export function ProgramKullaniciPage() {
  const [activeTab, setActiveTab] = useState('list');

  return (
    <div>
      <div className="sm:flex sm:items-center">
        <div className="sm:flex-auto">
          <div className="flex items-center gap-2">
            <UserCog className="h-6 w-6 text-indigo-600" />
            <h1 className="text-2xl font-semibold text-gray-900">Program Kullanıcıları</h1>
          </div>
          <p className="mt-2 text-sm text-gray-700">
            Sistemde kayıtlı tüm program kullanıcılarının listesi ve yönetimi
          </p>
        </div>
      </div>

      <div className="mt-6">
        <ProgramKullaniciTabs activeTab={activeTab} onTabChange={setActiveTab} />
        
        <div className="mt-6">
          {activeTab === 'list' ? <ProgramKullaniciList /> : <ProgramKullaniciAdd />}
        </div>
      </div>
    </div>
  );
}