import { useState } from 'react';
import toast from 'react-hot-toast';
import { ProgramKullaniciFormData } from '../types/program-kullanici.types';

const initialFormData: ProgramKullaniciFormData = {
  isim: '',
  sifre: '',
  macAddress: 'ASDFGHJK',
  firstLogin: '0'
};

export function useProgramKullaniciForm(initialData?: Partial<ProgramKullaniciFormData>) {
  const [formData, setFormData] = useState<ProgramKullaniciFormData>({
    ...initialFormData,
    ...initialData
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    // Prevent changing MAC address and firstLogin for new users
    if (!initialData && (name === 'macAddress' || name === 'firstLogin')) {
      return;
    }
    
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const validateForm = (): boolean => {
    if (!formData.isim) {
      toast.error('İsim alanı zorunludur');
      return false;
    }
    if (!formData.sifre) {
      toast.error('Şifre alanı zorunludur');
      return false;
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setLoading(true);

    try {
      // API call will be implemented here
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
      toast.success(initialData ? 'Program kullanıcı başarıyla güncellendi' : 'Program kullanıcı başarıyla eklendi');
      if (!initialData) {
        setFormData(initialFormData);
      }
    } catch (error) {
      toast.error(initialData ? 'Program kullanıcı güncellenirken bir hata oluştu' : 'Program kullanıcı eklenirken bir hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  return {
    formData,
    handleChange,
    handleSubmit,
    loading
  };
}