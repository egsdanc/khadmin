import React from 'react';
import { BayiForm } from './BayiForm';
import { DealerFormData } from '../../../../types/dealer.types';

const initialFormData: DealerFormData = {
  ad: '',
  firma: 1,
  aktif: true,
  il: '',
  ilce: '',
  adres: '',
  sabit_ip: null,
  yuzde_oran: 10,
  tel: '',
  mail: ''
};

export function BayiAdd() {
  const [formData] = React.useState<DealerFormData>(initialFormData);
  const [loading] = React.useState(false);

  const handleChange = () => {
    // Form değişiklik işlemleri
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Form gönderim işlemleri
  };

  return (
    <div className="bg-white shadow-sm ring-1 ring-gray-900/5 sm:rounded-xl">
      <div className="px-4 py-6 sm:p-8">
        <BayiForm
          formData={formData}
          onChange={handleChange}
          onSubmit={handleSubmit}
          loading={loading}
        />
      </div>
    </div>
  );
}