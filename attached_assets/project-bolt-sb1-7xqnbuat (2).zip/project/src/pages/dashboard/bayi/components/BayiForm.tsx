import React from 'react';
import { Input } from '../../../../components/ui/Input';
import { Select } from '../../../../components/ui/Select';
import { Button } from '../../../../components/ui/Button';
import { DealerFormData } from '../../../../types/dealer.types';

interface BayiFormProps {
  formData: DealerFormData;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
  onSubmit: (e: React.FormEvent) => void;
  loading?: boolean;
  isEdit?: boolean;
}

export function BayiForm({ formData, onChange, onSubmit, loading, isEdit }: BayiFormProps) {
  return (
    <form onSubmit={onSubmit} className="space-y-6">
      <div className="grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-2">
        <Input
          label="Bayi Adı"
          name="ad"
          value={formData.ad}
          onChange={onChange}
          required
        />

        <Select
          label="Firma"
          name="firma"
          value={formData.firma.toString()}
          onChange={onChange}
          required
        >
          <option value="">Firma Seçiniz</option>
          <option value="1">Firma 1</option>
          <option value="2">Firma 2</option>
        </Select>

        <Input
          label="İl"
          name="il"
          value={formData.il}
          onChange={onChange}
          required
        />

        <Input
          label="İlçe"
          name="ilce"
          value={formData.ilce}
          onChange={onChange}
          required
        />

        <div className="sm:col-span-2">
          <Input
            label="Adres"
            name="adres"
            value={formData.adres}
            onChange={onChange}
            required
          />
        </div>

        <Input
          label="Telefon"
          name="tel"
          value={formData.tel}
          onChange={onChange}
          required
        />

        <Input
          label="E-posta"
          name="mail"
          type="email"
          value={formData.mail}
          onChange={onChange}
          required
        />

        <Input
          label="Sabit IP"
          name="sabit_ip"
          value={formData.sabit_ip || ''}
          onChange={onChange}
          placeholder="Opsiyonel"
        />

        <Input
          label="Yüzde Oran (%)"
          name="yuzde_oran"
          type="number"
          min="0"
          max="100"
          step="0.01"
          value={formData.yuzde_oran.toString()}
          onChange={onChange}
          required
        />

        <Select
          label="Durum"
          name="aktif"
          value={formData.aktif ? '1' : '0'}
          onChange={onChange}
          required
        >
          <option value="1">Aktif</option>
          <option value="0">Pasif</option>
        </Select>
      </div>

      <div className="flex justify-end gap-4">
        <Button
          type="submit"
          loading={loading}
        >
          {isEdit ? 'Güncelle' : 'Kaydet'}
        </Button>
      </div>
    </form>
  );
}