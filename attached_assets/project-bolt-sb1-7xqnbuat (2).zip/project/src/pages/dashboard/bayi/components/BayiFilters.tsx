import React from 'react';
import { Search } from 'lucide-react';
import { Input } from '../../../../components/ui/Input';
import { Select } from '../../../../components/ui/Select';
import { dealerApi } from '../../../../services/api/dealer.api';

interface BayiFiltersProps {
  filters: {
    search: string;
    firma: string;
    il: string;
    aktif: string;
  };
  onChange: (key: string, value: string) => void;
}

export function BayiFilters({ filters, onChange }: BayiFiltersProps) {
  return (
    <div className="bg-white shadow sm:rounded-lg mb-6">
      <div className="px-4 py-5 sm:p-6">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-4">
          <Input
            label="Arama"
            name="search"
            value={filters.search}
            onChange={(e) => onChange('search', e.target.value)}
            placeholder="Bayi adı, telefon veya e-posta"
            icon={Search}
          />

          <Select
            label="Firma"
            value={filters.firma}
            onChange={(e) => onChange('firma', e.target.value)}
          >
            <option value="">Tüm Firmalar</option>
            <option value="1">Garantili Arabam</option>
            <option value="2">General Oto Ekspertiz</option>
            <option value="3">Dynobil</option>
          </Select>

          <Select
            label="İl"
            value={filters.il}
            onChange={(e) => onChange('il', e.target.value)}
          >
            <option value="">Tüm İller</option>
            <option value="Ankara">Ankara</option>
            <option value="İstanbul">İstanbul</option>
            <option value="İzmir">İzmir</option>
            <option value="Bursa">Bursa</option>
          </Select>

          <Select
            label="Durum"
            value={filters.aktif}
            onChange={(e) => onChange('aktif', e.target.value)}
          >
            <option value="">Tümü</option>
            <option value="true">Aktif</option>
            <option value="false">Pasif</option>
          </Select>
        </div>
      </div>
    </div>
  );
}