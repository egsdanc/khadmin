import React from 'react';
import { Input } from '../../../../components/ui/Input';

interface BayiFormFieldsProps {
  formData: Record<string, string>;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export function BayiFormFields({ formData, onChange }: BayiFormFieldsProps) {
  return (
    <div className="grid grid-cols-1 gap-x-6 gap-y-8">
      <div className="col-span-full">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Input
            label="Bayi Adı"
            name="ad"
            required
            placeholder="Bayi adını giriniz"
            value={formData.ad}
            onChange={onChange}
          />

          <Input
            label="E-posta"
            name="email"
            type="email"
            required
            placeholder="E-posta adresini giriniz"
            value={formData.email}
            onChange={onChange}
          />

          <Input
            label="Telefon"
            name="telefon"
            required
            placeholder="Telefon numarası giriniz"
            value={formData.telefon}
            onChange={onChange}
          />

          <Input
            label="İl"
            name="il"
            required
            placeholder="İl giriniz"
            value={formData.il}
            onChange={onChange}
          />

          <Input
            label="İlçe"
            name="ilce"
            required
            placeholder="İlçe giriniz"
            value={formData.ilce}
            onChange={onChange}
          />

          <div className="sm:col-span-2">
            <Input
              label="Adres"
              name="adres"
              required
              placeholder="Açık adres giriniz"
              value={formData.adres}
              onChange={onChange}
            />
          </div>

          <Input
            label="Sabit IP"
            name="sabit_ip"
            placeholder="Sabit IP adresini giriniz"
            value={formData.sabit_ip}
            onChange={onChange}
          />

          <Input
            label="Firma Pay Oranı (%)"
            name="yuzde_oran"
            type="number"
            min="0"
            max="100"
            step="0.01"
            required
            placeholder="Firma pay oranını giriniz"
            value={formData.yuzde_oran}
            onChange={onChange}
          />
        </div>
      </div>
    </div>
  );
}