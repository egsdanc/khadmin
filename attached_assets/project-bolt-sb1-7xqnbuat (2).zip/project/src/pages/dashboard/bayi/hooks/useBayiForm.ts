import { useState } from 'react';
import toast from 'react-hot-toast';
import { useAuthStore } from '../../../../store/auth.store';

interface BayiFormData {
  ad: string;
  email: string;
  telefon: string;
  il: string;
  ilce: string;
  adres: string;
  sabit_ip: string;
  yuzde_oran: string;
}

const initialFormData: BayiFormData = {
  ad: '',
  email: '',
  telefon: '',
  il: '',
  ilce: '',
  adres: '',
  sabit_ip: '',
  yuzde_oran: '10.00', // Varsayılan olarak %10
};

export function useBayiForm() {
  const [formData, setFormData] = useState<BayiFormData>(initialFormData);
  const [loading, setLoading] = useState(false);
  const user = useAuthStore(state => state.user);

  const validateForm = () => {
    if (!formData.ad || !formData.email || !formData.telefon || 
        !formData.il || !formData.ilce || !formData.adres || !formData.yuzde_oran) {
      toast.error('Lütfen zorunlu alanları doldurunuz');
      return false;
    }

    const yuzdeOran = parseFloat(formData.yuzde_oran);
    if (isNaN(yuzdeOran) || yuzdeOran < 0 || yuzdeOran > 100) {
      toast.error('Firma pay oranı 0-100 arasında olmalıdır');
      return false;
    }

    return true;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setLoading(true);

    try {
      // API çağrısında firma ID'si otomatik olarak gönderilecek
      const bayiData = {
        ...formData,
        firma: user?.firma // Giriş yapan kullanıcının firma ID'si
      };

      // API call will be implemented here
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success('Bayi başarıyla eklendi');
      setFormData(initialFormData);
    } catch (error) {
      toast.error('Bayi eklenirken bir hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  return {
    formData,
    handleChange,
    handleSubmit,
    loading
  };
}