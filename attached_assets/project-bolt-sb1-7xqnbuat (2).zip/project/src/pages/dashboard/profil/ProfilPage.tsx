import React, { useState } from 'react';
import { User } from 'lucide-react';
import { useAuthStore } from '../../../store/auth.store';
import { ProfileEditModal } from './components/ProfileEditModal';

export function ProfilPage() {
  const user = useAuthStore(state => state.user);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  return (
    <div>
      <div className="sm:flex sm:items-center">
        <div className="sm:flex-auto">
          <div className="flex items-center gap-2">
            <User className="h-6 w-6 text-indigo-600" />
            <h1 className="text-2xl font-semibold text-gray-900">Profil</h1>
          </div>
          <p className="mt-2 text-sm text-gray-700">
            Profil bilgilerinizi görüntüleyebilir ve düzenleyebilirsiniz
          </p>
        </div>
      </div>

      <div className="mt-8">
        <div className="overflow-hidden bg-white shadow sm:rounded-lg">
          <div className="px-4 py-6 sm:px-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-medium leading-6 text-gray-900">
                Profil Bilgileri
              </h3>
              <button
                onClick={() => setIsEditModalOpen(true)}
                className="rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500"
              >
                Düzenle
              </button>
            </div>
          </div>
          <div className="border-t border-gray-200 px-4 py-5 sm:px-6">
            <dl className="grid grid-cols-1 gap-x-4 gap-y-8 sm:grid-cols-2">
              <div>
                <dt className="text-sm font-medium text-gray-500">Ad</dt>
                <dd className="mt-1 text-sm text-gray-900">{user?.ad}</dd>
              </div>
              <div>
                <dt className="text-sm font-medium text-gray-500">E-posta</dt>
                <dd className="mt-1 text-sm text-gray-900">{user?.email}</dd>
              </div>
              <div>
                <dt className="text-sm font-medium text-gray-500">Rol</dt>
                <dd className="mt-1 text-sm text-gray-900">
                  {user?.role === 1 ? 'Super Admin' : 'Kullanıcı'}
                </dd>
              </div>
              <div>
                <dt className="text-sm font-medium text-gray-500">Firma</dt>
                <dd className="mt-1 text-sm text-gray-900">
                  {user?.firma === 0 ? 'Merkez' : `Firma ${user?.firma}`}
                </dd>
              </div>
              {user?.bayi && (
                <div>
                  <dt className="text-sm font-medium text-gray-500">Bayi</dt>
                  <dd className="mt-1 text-sm text-gray-900">
                    Bayi {user.bayi}
                  </dd>
                </div>
              )}
            </dl>
          </div>
        </div>
      </div>

      <ProfileEditModal 
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
      />
    </div>
  );
}