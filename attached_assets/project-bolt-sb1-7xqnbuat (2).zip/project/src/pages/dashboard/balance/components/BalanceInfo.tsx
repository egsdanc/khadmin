import React from 'react';
import { formatCurrency } from '../../../../utils/format';
import { BALANCE_CONFIG } from '../../../../config/balance.config';

export function BalanceInfo() {
  const { TEST_FEE, COMPANY_SHARE_RATE, KDV_RATE, ADMIN_SHARE_RATE } = BALANCE_CONFIG;

  const companies = [
    {
      id: 1,
      name: 'Garantili Arabam',
      totalTests: 450,
      dealerRevenue: 450 * TEST_FEE * 0.90, // %90 bayi payı
      companyRevenue: 450 * TEST_FEE * COMPANY_SHARE_RATE, // %10 firma payı
      companyKdv: 450 * TEST_FEE * COMPANY_SHARE_RATE * KDV_RATE, // Firma KDV'si
      superAdminShare: 450 * TEST_FEE * ADMIN_SHARE_RATE, // %2 Super Admin payı
      superAdminKdv: 450 * TEST_FEE * ADMIN_SHARE_RATE * KDV_RATE // Super Admin KDV'si
    },
    {
      id: 2,
      name: 'General Oto Ekspertiz',
      totalTests: 420,
      dealerRevenue: 420 * TEST_FEE * 0.90,
      companyRevenue: 420 * TEST_FEE * COMPANY_SHARE_RATE,
      companyKdv: 420 * TEST_FEE * COMPANY_SHARE_RATE * KDV_RATE,
      superAdminShare: 420 * TEST_FEE * ADMIN_SHARE_RATE,
      superAdminKdv: 420 * TEST_FEE * ADMIN_SHARE_RATE * KDV_RATE
    },
    {
      id: 3,
      name: 'Dynobil',
      totalTests: 400,
      dealerRevenue: 400 * TEST_FEE * 0.90,
      companyRevenue: 400 * TEST_FEE * COMPANY_SHARE_RATE,
      companyKdv: 400 * TEST_FEE * COMPANY_SHARE_RATE * KDV_RATE,
      superAdminShare: 400 * TEST_FEE * ADMIN_SHARE_RATE,
      superAdminKdv: 400 * TEST_FEE * ADMIN_SHARE_RATE * KDV_RATE
    }
  ];

  const totalSuperAdminRevenue = companies.reduce((sum, company) => 
    sum + company.superAdminShare + company.superAdminKdv, 0
  );

  return (
    <div className="space-y-6">
      <div className="bg-white shadow rounded-lg">
        <div className="p-6">
          <h3 className="text-base font-semibold text-gray-900 mb-4">
            Firma Gelirleri
          </h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            {companies.map((company) => (
              <div key={company.id} className="rounded-lg border border-gray-200 p-4">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm font-medium text-gray-900">{company.name}</p>
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between items-center">
                    <p className="text-sm text-gray-500">Test Sayısı:</p>
                    <p className="text-sm font-medium text-gray-900">{company.totalTests}</p>
                  </div>
                  <div className="flex justify-between items-center">
                    <p className="text-sm text-gray-500">Bayi Geliri (%90):</p>
                    <p className="text-sm font-medium text-green-600">
                      {formatCurrency(company.dealerRevenue)}
                    </p>
                  </div>
                  <div className="flex justify-between items-center">
                    <p className="text-sm text-gray-500">Firma Geliri (%10):</p>
                    <p className="text-sm font-medium text-indigo-600">
                      {formatCurrency(company.companyRevenue)}
                    </p>
                  </div>
                  <div className="flex justify-between items-center">
                    <p className="text-sm text-gray-500">Firma KDV:</p>
                    <p className="text-sm font-medium text-indigo-600">
                      {formatCurrency(company.companyKdv)}
                    </p>
                  </div>
                  <div className="flex justify-between items-center">
                    <p className="text-sm text-gray-500">Super Admin Payı (%2):</p>
                    <p className="text-sm font-medium text-indigo-600">
                      {formatCurrency(company.superAdminShare)}
                    </p>
                  </div>
                  <div className="flex justify-between items-center">
                    <p className="text-sm text-gray-500">Super Admin KDV:</p>
                    <p className="text-sm font-medium text-indigo-600">
                      {formatCurrency(company.superAdminKdv)}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white shadow rounded-lg">
        <div className="p-6">
          <h3 className="text-base font-semibold text-gray-900 mb-4">
            Super Admin Geliri (Emre Söken)
          </h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="rounded-lg border border-gray-200 p-4 bg-indigo-50">
              <p className="text-sm font-medium text-gray-500">Toplam Super Admin Geliri (%2 + KDV)</p>
              <p className="mt-2 text-3xl font-semibold text-indigo-600">
                {formatCurrency(totalSuperAdminRevenue)}
              </p>
              <p className="mt-1 text-sm text-gray-500">
                Tüm firmalardan elde edilen toplam Super Admin geliri
              </p>
            </div>
            <div className="rounded-lg border border-gray-200 p-4">
              <div className="space-y-4">
                {companies.map((company) => (
                  <div key={company.id} className="flex justify-between items-center">
                    <p className="text-sm text-gray-500">{company.name}:</p>
                    <p className="text-sm font-medium text-indigo-600">
                      {formatCurrency(company.superAdminShare + company.superAdminKdv)}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}