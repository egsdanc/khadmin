import React from 'react';
import { Calendar } from 'lucide-react';
import { Input } from '../../../../components/ui/Input';
import { Select } from '../../../../components/ui/Select';

interface TransactionFiltersProps {
  filters: {
    startDate: string;
    endDate: string;
    type: string;
  };
  onChange: (key: string, value: string) => void;
}

export function TransactionFilters({ filters, onChange }: TransactionFiltersProps) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
      <Input
        type="date"
        label="Başlangıç Tarihi"
        name="startDate"
        value={filters.startDate}
        onChange={(e) => onChange('startDate', e.target.value)}
        icon={Calendar}
      />
      
      <Input
        type="date"
        label="Bitiş Tarihi"
        name="endDate"
        value={filters.endDate}
        onChange={(e) => onChange('endDate', e.target.value)}
        icon={Calendar}
      />

      <Select
        label="İşlem Tipi"
        value={filters.type}
        onChange={(e) => onChange('type', e.target.value)}
      >
        <option value="">Tümü</option>
        <option value="DEPOSIT">Yükleme</option>
        <option value="DEDUCTION">Kesinti</option>
      </Select>
    </div>
  );
}