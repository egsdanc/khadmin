import React from 'react';
import { Wallet, History, PlusCircle } from 'lucide-react';
import { cn } from '../../../../utils/cn';

interface BalanceTabsProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function BalanceTabs({ activeTab, onTabChange }: BalanceTabsProps) {
  const tabs = [
    { id: 'info', name: 'Bakiye Bilgileri', icon: Wallet },
    { id: 'history', name: 'İşlem Geçmişi', icon: History },
    { id: 'deposit', name: 'Bakiye Yükle', icon: PlusCircle }
  ];

  return (
    <div className="border-b border-gray-200">
      <nav className="-mb-px flex space-x-8" aria-label="Tabs">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={cn(
              'group inline-flex items-center border-b-2 py-4 px-1',
              'font-medium text-sm',
              activeTab === tab.id
                ? 'border-indigo-500 text-indigo-600'
                : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
            )}
          >
            <tab.icon
              className={cn(
                'h-5 w-5 mr-2',
                activeTab === tab.id
                  ? 'text-indigo-500'
                  : 'text-gray-400 group-hover:text-gray-500'
              )}
            />
            {tab.name}
          </button>
        ))}
      </nav>
    </div>
  );
}