import React, { useState } from 'react';
import { PlusCircle } from 'lucide-react';
import { Input } from '../../../../components/ui/Input';
import { Select } from '../../../../components/ui/Select';
import { Button } from '../../../../components/ui/Button';
import toast from 'react-hot-toast';

export function BalanceDeposit() {
  const [formData, setFormData] = useState({
    amount: '',
    firma: '',
    bayi: ''
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // API çağrısı simülasyonu
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success('Bakiye yükleme işlemi başarılı');
      setFormData({ amount: '', firma: '', bayi: '' });
    } catch (error) {
      toast.error('Bakiye yükleme işlemi başarısız');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white shadow rounded-lg">
      <div className="p-6">
        <h3 className="text-base font-semibold text-gray-900 mb-4">
          Bakiye Yükle
        </h3>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <Select
            label="Firma"
            name="firma"
            value={formData.firma}
            onChange={handleChange}
            required
          >
            <option value="">Firma Seçiniz</option>
            <option value="1">Garantili Arabam</option>
            <option value="2">General Oto Ekspertiz</option>
            <option value="3">Dynobil</option>
          </Select>

          <Select
            label="Bayi"
            name="bayi"
            value={formData.bayi}
            onChange={handleChange}
            required
          >
            <option value="">Bayi Seçiniz</option>
            <option value="1">Ankara / Yenimahalle</option>
            <option value="2">İstanbul / Kadıköy</option>
            <option value="3">İzmir / Karşıyaka</option>
          </Select>

          <Input
            label="Yüklenecek Tutar"
            type="number"
            name="amount"
            value={formData.amount}
            onChange={handleChange}
            min="1"
            required
            placeholder="Tutar giriniz"
          />
          
          <Button
            type="submit"
            loading={loading}
            className="w-full"
          >
            <PlusCircle className="h-4 w-4 mr-2" />
            Bakiye Yükle
          </Button>
        </form>
      </div>
    </div>
  );
}