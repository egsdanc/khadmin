import React, { useState } from 'react';
import { Wallet } from 'lucide-react';
import { BalanceTabs } from './components/BalanceTabs';
import { BalanceInfo } from './components/BalanceInfo';
import { TransactionHistory } from './components/TransactionHistory';
import { BalanceDeposit } from './components/BalanceDeposit';

export function BalanceManagementPage() {
  const [activeTab, setActiveTab] = useState('info');

  return (
    <div>
      <div className="sm:flex sm:items-center">
        <div className="sm:flex-auto">
          <div className="flex items-center gap-2">
            <Wallet className="h-6 w-6 text-indigo-600" />
            <h1 className="text-2xl font-semibold text-gray-900">Bakiye Yönetimi</h1>
          </div>
          <p className="mt-2 text-sm text-gray-700">
            Sistem bakiye yönetimi ve gelir dağılımı
          </p>
        </div>
      </div>

      <div className="mt-6">
        <BalanceTabs activeTab={activeTab} onTabChange={setActiveTab} />
        
        <div className="mt-6">
          {activeTab === 'info' && <BalanceInfo />}
          {activeTab === 'history' && <TransactionHistory />}
          {activeTab === 'deposit' && <BalanceDeposit />}
        </div>
      </div>
    </div>
  );
}