import React from 'react';
import { useRolForm } from '../hooks/useRolForm';
import { RolFormFields } from './RolFormFields';
import { RolFormActions } from './RolFormActions';

export function RolAdd() {
  const { formData, handleChange, handleSubmit, loading } = useRolForm();

  return (
    <div className="space-y-10">
      <form className="bg-white shadow-sm ring-1 ring-gray-900/5 rounded-xl" onSubmit={handleSubmit}>
        <div className="px-4 py-6 sm:p-8">
          <RolFormFields
            formData={formData}
            onChange={handleChange}
          />
        </div>
        
        <RolFormActions loading={loading} />
      </form>
    </div>
  );
}