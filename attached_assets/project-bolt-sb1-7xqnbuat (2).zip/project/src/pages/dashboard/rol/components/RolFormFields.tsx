import React from 'react';
import { Input } from '../../../../components/ui/Input';

interface RolFormFieldsProps {
  formData: Record<string, string>;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export function RolFormFields({ formData, onChange }: RolFormFieldsProps) {
  return (
    <div className="grid grid-cols-1 gap-x-6 gap-y-8">
      <div className="col-span-full">
        <div className="grid grid-cols-1 gap-4">
          <Input
            label="Rol Adı (name)"
            name="name"
            required
            placeholder="Rol adını giriniz"
            value={formData.name}
            onChange={onChange}
          />
          <Input
            label="Slug"
            name="slug"
            required
            placeholder="Rol slug değerini giriniz"
            value={formData.slug}
            onChange={onChange}
          />
        </div>
      </div>
    </div>
  );
}