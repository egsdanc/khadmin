import React, { useState } from 'react';
import { Shield } from 'lucide-react';
import { RolTabs } from './components/RolTabs';
import { RolList } from './components/RolList';
import { RolAdd } from './components/RolAdd';

export function RolListPage() {
  const [activeTab, setActiveTab] = useState('list');

  return (
    <div>
      <div className="sm:flex sm:items-center">
        <div className="sm:flex-auto">
          <div className="flex items-center gap-2">
            <Shield className="h-6 w-6 text-indigo-600" />
            <h1 className="text-2xl font-semibold text-gray-900">Roller</h1>
          </div>
          <p className="mt-2 text-sm text-gray-700">
            Sistemde kayıtlı tüm rollerin listesi ve yönetimi
          </p>
        </div>
      </div>

      <div className="mt-6">
        <RolTabs activeTab={activeTab} onTabChange={setActiveTab} />
        
        <div className="mt-6">
          {activeTab === 'list' ? <RolList /> : <RolAdd />}
        </div>
      </div>
    </div>
  );
}