import { useState } from 'react';
import toast from 'react-hot-toast';

interface RolFormData {
  name: string;
  slug: string;
}

const initialFormData: RolFormData = {
  name: '',
  slug: ''
};

export function useRolForm() {
  const [formData, setFormData] = useState<RolFormData>(initialFormData);
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // API call will be implemented here
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
      toast.success('Rol başarıyla eklendi');
    } catch (error) {
      toast.error('Rol eklenirken bir hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  return {
    formData,
    handleChange,
    handleSubmit,
    loading
  };
}