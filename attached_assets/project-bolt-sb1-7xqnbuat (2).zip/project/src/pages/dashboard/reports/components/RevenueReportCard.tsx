import React from 'react';
import { formatCurrency } from '../../../../utils/format';
import type { RevenueReport } from '../../../../types/reports.types';

interface RevenueReportCardProps {
  data: RevenueReport;
  loading: boolean;
}

export function RevenueReportCard({ data, loading }: RevenueReportCardProps) {
  if (loading) {
    return (
      <div className="text-center py-8">
        <div className="text-gray-500">Yükleniyor...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Toplam Gelir Kartı */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Gelir Özeti</h3>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          <div className="bg-indigo-50 p-4 rounded-lg">
            <p className="text-sm text-indigo-600 font-medium">Toplam Gelir</p>
            <p className="mt-2 text-2xl font-semibold text-indigo-900">
              {formatCurrency(data.totalRevenue)}
            </p>
          </div>

          <div className="bg-green-50 p-4 rounded-lg">
            <p className="text-sm text-green-600 font-medium">Bayi Payı</p>
            <p className="mt-2 text-2xl font-semibold text-green-900">
              {formatCurrency(data.dealerShare)}
            </p>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg">
            <p className="text-sm text-blue-600 font-medium">Sistem Payı</p>
            <p className="mt-2 text-2xl font-semibold text-blue-900">
              {formatCurrency(data.systemShare)}
            </p>
          </div>

          <div className="bg-purple-50 p-4 rounded-lg">
            <p className="text-sm text-purple-600 font-medium">Net Gelir</p>
            <p className="mt-2 text-2xl font-semibold text-purple-900">
              {formatCurrency(data.netRevenue)}
            </p>
          </div>
        </div>
      </div>

      {/* KDV ve Detaylar */}
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">Detaylı Bilgiler</h3>
        <div className="space-y-4">
          <div className="flex justify-between items-center py-2 border-b">
            <span className="text-gray-600">KDV Tutarı</span>
            <span className="font-medium text-gray-900">{formatCurrency(data.kdvAmount)}</span>
          </div>
          <div className="flex justify-between items-center py-2 border-b">
            <span className="text-gray-600">Dönem Başlangıcı</span>
            <span className="font-medium text-gray-900">
              {new Date(data.periodStart).toLocaleDateString('tr-TR')}
            </span>
          </div>
          <div className="flex justify-between items-center py-2">
            <span className="text-gray-600">Dönem Bitişi</span>
            <span className="font-medium text-gray-900">
              {new Date(data.periodEnd).toLocaleDateString('tr-TR')}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}