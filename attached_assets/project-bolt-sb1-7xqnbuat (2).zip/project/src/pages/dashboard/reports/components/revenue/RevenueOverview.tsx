import React from 'react';
import { formatCurrency } from '../../../../../utils/format';
import { RevenueReport } from '../../../../../types/reports.types';
import { TrendingUp, Wallet, Receipt, Calculator } from 'lucide-react';

interface RevenueOverviewProps {
  data: RevenueReport;
}

export function RevenueOverview({ data }: RevenueOverviewProps) {
  const stats = [
    { name: 'Toplam Gelir', value: data.totalRevenue, icon: TrendingUp, color: 'bg-indigo-50 text-indigo-700' },
    { name: 'Bayi Payı', value: data.dealerShare, icon: Wallet, color: 'bg-green-50 text-green-700' },
    { name: 'Sistem Payı', value: data.systemShare, icon: Receipt, color: 'bg-blue-50 text-blue-700' },
    { name: 'KDV', value: data.kdvAmount, icon: Calculator, color: 'bg-purple-50 text-purple-700' }
  ];

  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <div key={stat.name} className={`${stat.color} overflow-hidden rounded-lg p-6`}>
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <stat.icon className="h-6 w-6" />
            </div>
            <div className="ml-4 w-full">
              <p className="truncate text-sm font-medium">{stat.name}</p>
              <p className="mt-1 text-xl font-semibold">{formatCurrency(stat.value)}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}