import React from 'react';
import { RevenueOverview } from './RevenueOverview';
import { RevenueByCompany } from './RevenueByCompany';
import { RevenuePeriodInfo } from './RevenuePeriodInfo';
import { RevenueReport } from '../../../../../types/reports.types';

interface RevenueReportContentProps {
  data: RevenueReport;
}

export function RevenueReportContent({ data }: RevenueReportContentProps) {
  return (
    <div className="space-y-6">
      <RevenueOverview data={data} />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <RevenueByCompany companies={data.companies} />
        </div>
        <div>
          <RevenuePeriodInfo 
            startDate={data.periodStart} 
            endDate={data.periodEnd} 
          />
        </div>
      </div>
    </div>
  );
}