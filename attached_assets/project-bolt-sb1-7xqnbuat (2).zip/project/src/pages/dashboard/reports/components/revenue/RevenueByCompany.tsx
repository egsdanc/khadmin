import React from 'react';
import { formatCurrency } from '../../../../../utils/format';

interface CompanyRevenue {
  id: number;
  name: string;
  totalTests: number;
  revenue: number;
  systemShare: number;
  kdvAmount: number;
}

interface RevenueByCompanyProps {
  companies: CompanyRevenue[];
}

export function RevenueByCompany({ companies }: RevenueByCompanyProps) {
  return (
    <div className="bg-white rounded-lg shadow">
      <div className="px-4 py-5 sm:p-6">
        <h3 className="text-base font-semibold leading-6 text-gray-900 mb-4">Firma Bazlı Gelirler</h3>
        <div className="mt-4 flow-root">
          <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
            <div className="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
              <table className="min-w-full divide-y divide-gray-300">
                <thead>
                  <tr>
                    <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Firma</th>
                    <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Test Sayısı</th>
                    <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Toplam Gelir</th>
                    <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">Sistem Payı</th>
                    <th className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">KDV</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {companies.map((company) => (
                    <tr key={company.id}>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-900">{company.name}</td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{company.totalTests}</td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm font-medium text-green-600">
                        {formatCurrency(company.revenue)}
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                        {formatCurrency(company.systemShare)}
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                        {formatCurrency(company.kdvAmount)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}