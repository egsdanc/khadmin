import React from 'react';
import { FileText, Users, Wallet, Calendar, Search } from 'lucide-react';
import { Input } from '../../../../components/ui/Input';
import { Select } from '../../../../components/ui/Select';
import { Button } from '../../../../components/ui/Button';
import { cn } from '../../../../utils/cn';
import type { ReportFilters as ReportFiltersType } from '../../../../types/reports.types';

interface ReportFiltersProps {
  filters: ReportFiltersType;
  onChange: (filters: ReportFiltersType) => void;
  onTabChange: (tab: 'tests' | 'dealers' | 'revenue') => void;
  activeTab: string;
}

const tabs = [
  { id: 'tests', name: 'Test Raporları', icon: FileText },
  { id: 'dealers', name: 'Bayi Raporları', icon: Users },
  { id: 'revenue', name: 'Gelir Raporu', icon: Wallet }
];

const periods = [
  { value: 'daily', label: 'Günlük' },
  { value: 'weekly', label: 'Haftalık' },
  { value: 'monthly', label: 'Aylık' },
  { value: 'yearly', label: 'Yıllık' },
  { value: 'custom', label: 'Özel' }
];

const companies = [
  { value: '', label: 'Tüm Firmalar' },
  { value: '1', label: 'Garantili Arabam' },
  { value: '2', label: 'General Oto Ekspertiz' },
  { value: '3', label: 'Dynobil' }
];

export function ReportFilters({ filters, onChange, onTabChange, activeTab }: ReportFiltersProps) {
  const handleFilterChange = (key: keyof ReportFiltersType, value: string) => {
    onChange({ ...filters, [key]: value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Trigger search/filter
  };

  return (
    <div className="space-y-4">
      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id as any)}
                className={cn(
                  'group inline-flex items-center border-b-2 py-4 px-1',
                  'font-medium text-sm',
                  activeTab === tab.id
                    ? 'border-indigo-500 text-indigo-600'
                    : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
                )}
              >
                <Icon className={cn(
                  'h-5 w-5 mr-2',
                  activeTab === tab.id
                    ? 'text-indigo-500'
                    : 'text-gray-400 group-hover:text-gray-500'
                )} />
                {tab.name}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-lg shadow">
        <form onSubmit={handleSubmit} className="grid grid-cols-1 gap-4 sm:grid-cols-5 items-end">
          <Select
            label="Dönem"
            value={filters.period}
            onChange={(e) => handleFilterChange('period', e.target.value)}
          >
            {periods.map((period) => (
              <option key={period.value} value={period.value}>
                {period.label}
              </option>
            ))}
          </Select>

          {filters.period === 'custom' && (
            <>
              <Input
                type="date"
                label="Başlangıç Tarihi"
                icon={Calendar}
                value={filters.startDate}
                onChange={(e) => handleFilterChange('startDate', e.target.value)}
              />
              <Input
                type="date"
                label="Bitiş Tarihi"
                icon={Calendar}
                value={filters.endDate}
                onChange={(e) => handleFilterChange('endDate', e.target.value)}
              />
            </>
          )}

          <Select
            label="Firma"
            value={filters.company || ''}
            onChange={(e) => handleFilterChange('company', e.target.value)}
          >
            {companies.map((company) => (
              <option key={company.value} value={company.value}>
                {company.label}
              </option>
            ))}
          </Select>

          {activeTab === 'tests' && (
            <Select
              label="Test Tipi"
              value={filters.testType}
              onChange={(e) => handleFilterChange('testType', e.target.value)}
            >
              <option value="all">Tümü</option>
              <option value="kilometer">Kilometre</option>
              <option value="vin">VIN</option>
            </Select>
          )}

          <Button 
            type="submit"
            className="w-[140px] h-10 flex items-center justify-center gap-2"
          >
            <Search className="h-4 w-4" />
            Filtrele
          </Button>
        </form>
      </div>
    </div>
  );
}