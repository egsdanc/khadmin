import React, { useState } from 'react';
import { FileSpreadsheet, Download } from 'lucide-react';
import { useReports } from '../../../hooks/reports/useReports';
import { Button } from '../../../components/ui/Button';
import { ReportFilters } from './components/ReportFilters';
import { TestReportsTable } from './components/TestReportsTable';
import { DealerReportsTable } from './components/DealerReportsTable';
import { RevenueReportCard } from './components/RevenueReportCard';
import type { ReportFilters as ReportFiltersType } from '../../../types/reports.types';

export function ReportsPage() {
  const [activeTab, setActiveTab] = useState<'tests' | 'dealers' | 'revenue'>('tests');
  const [filters, setFilters] = useState<ReportFiltersType>({
    period: 'monthly',
    testType: 'all',
    startDate: '',
    endDate: ''
  });

  const {
    loading,
    testReports,
    dealerReports,
    revenueReport,
    fetchTestReports,
    fetchDealerReports,
    fetchRevenueReport,
    exportReport
  } = useReports();

  const handleFilterChange = (newFilters: ReportFiltersType) => {
    setFilters(newFilters);
    switch (activeTab) {
      case 'tests':
        fetchTestReports(newFilters);
        break;
      case 'dealers':
        fetchDealerReports(newFilters);
        break;
      case 'revenue':
        fetchRevenueReport(newFilters);
        break;
    }
  };

  const handleExport = () => {
    exportReport(activeTab, filters);
  };

  return (
    <div>
      <div className="sm:flex sm:items-center sm:justify-between">
        <div className="sm:flex-auto">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="h-6 w-6 text-indigo-600" />
            <h1 className="text-2xl font-semibold text-gray-900">Raporlar</h1>
          </div>
          <p className="mt-2 text-sm text-gray-700">
            Sistem genelindeki test ve gelir raporlarını görüntüleyin
          </p>
        </div>
        <div className="mt-4 sm:ml-16 sm:mt-0">
          <Button
            onClick={handleExport}
            variant="secondary"
            className="w-[140px] h-10 flex items-center justify-center gap-2"
          >
            <Download className="h-4 w-4" />
            Excel'e Aktar
          </Button>
        </div>
      </div>

      <div className="mt-8">
        <ReportFilters
          filters={filters}
          onChange={handleFilterChange}
          onTabChange={setActiveTab}
          activeTab={activeTab}
        />

        <div className="mt-6">
          {activeTab === 'tests' && (
            <TestReportsTable data={testReports} loading={loading} />
          )}
          {activeTab === 'dealers' && (
            <DealerReportsTable data={dealerReports} loading={loading} />
          )}
          {activeTab === 'revenue' && revenueReport && (
            <RevenueReportCard data={revenueReport} loading={loading} />
          )}
        </div>
      </div>
    </div>
  );
}