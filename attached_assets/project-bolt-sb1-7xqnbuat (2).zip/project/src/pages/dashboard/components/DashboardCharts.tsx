import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line
} from 'recharts';

const COLORS = ['#4F46E5', '#10B981', '#6366F1', '#8B5CF6'];

export const DashboardCharts = {
  // Test Sayıları Grafiği
  TestCountChart: ({ testData, vinData }: any) => {
    const data = testData.map((test: any, index: number) => ({
      date: new Date(test.tarih).toLocaleDateString('tr-TR'),
      'Kilometre Test': 1,
      'VIN Test': vinData[index] ? 1 : 0
    }));

    return (
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="date" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Bar dataKey="Kilometre Test" fill="#4F46E5" />
          <Bar dataKey="VIN Test" fill="#10B981" />
        </BarChart>
      </ResponsiveContainer>
    );
  },

  // Firma Bazlı Dağılım Grafiği
  CompanyDistributionChart: ({ data }: any) => {
    return (
      <ResponsiveContainer width="100%" height={300}>
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            labelLine={false}
            label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
            outerRadius={100}
            fill="#8884d8"
            dataKey="tests"
          >
            {data.map((entry: any, index: number) => (
              <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip />
        </PieChart>
      </ResponsiveContainer>
    );
  },

  // Gelir Grafiği
  RevenueChart: ({ data }: any) => {
    return (
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis />
          <Tooltip />
          <Legend />
          <Line 
            type="monotone" 
            dataKey="revenue" 
            stroke="#4F46E5" 
            name="Gelir"
            strokeWidth={2}
          />
        </LineChart>
      </ResponsiveContainer>
    );
  }
};