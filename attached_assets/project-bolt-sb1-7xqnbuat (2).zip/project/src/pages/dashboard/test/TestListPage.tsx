import React, { useState, useMemo } from 'react';
import { Gauge } from 'lucide-react';
import { TestTable } from './components/TestTable';
import { TestDateFilters } from './components/TestDateFilters';
import { useTestData } from './hooks/useTestData';
import { usePagination } from '../../../hooks/usePagination';
import { useSorting } from '../../../hooks/useSorting';

export function TestListPage() {
  const { testData } = useTestData();
  const [filters, setFilters] = useState({
    startDate: '',
    endDate: '',
    plateNumber: ''
  });

  // Filtrelenmiş test verilerini hesapla
  const filteredTests = useMemo(() => {
    return testData.filter(test => {
      const testDate = new Date(test.tarih);
      
      // Plaka filtresi
      if (filters.plateNumber && !test.plaka.toLowerCase().includes(filters.plateNumber.toLowerCase())) {
        return false;
      }
      
      // Başlangıç tarihi kontrolü
      if (filters.startDate) {
        const startDate = new Date(filters.startDate);
        startDate.setHours(0, 0, 0, 0);
        if (testDate < startDate) return false;
      }
      
      // Bitiş tarihi kontrolü
      if (filters.endDate) {
        const endDate = new Date(filters.endDate);
        endDate.setHours(23, 59, 59, 999);
        if (testDate > endDate) return false;
      }

      return true;
    });
  }, [testData, filters]);

  // Sıralama hook'u
  const { sortedData, sortField, sortDirection, handleSort } = useSorting({
    data: filteredTests,
    defaultSortField: 'tarih',
    defaultDirection: 'desc'
  });

  // Sayfalama hook'u
  const { 
    currentPage, 
    totalPages, 
    paginatedData, 
    handlePageChange 
  } = usePagination({
    data: sortedData,
    itemsPerPage: 10
  });

  const handleSearch = () => {
    // Filtreleme otomatik olarak yapılıyor
    // İleride API çağrısı yapılacaksa burada yapılabilir
  };

  return (
    <div>
      <div className="sm:flex sm:items-center">
        <div className="sm:flex-auto">
          <div className="flex items-center gap-2">
            <Gauge className="h-6 w-6 text-indigo-600" />
            <h1 className="text-2xl font-semibold text-gray-900">Kilometre Hacker</h1>
          </div>
          <p className="mt-2 text-sm text-gray-700">
            Sistemde kayıtlı tüm kilometre hacker işlemlerinin listesi
          </p>
        </div>
      </div>

      <div className="mt-8">
        <TestDateFilters
          startDate={filters.startDate}
          endDate={filters.endDate}
          plateNumber={filters.plateNumber}
          onStartDateChange={(value) => setFilters(prev => ({ ...prev, startDate: value }))}
          onEndDateChange={(value) => setFilters(prev => ({ ...prev, endDate: value }))}
          onPlateNumberChange={(value) => setFilters(prev => ({ ...prev, plateNumber: value }))}
          onSearch={handleSearch}
        />

        <TestTable 
          data={paginatedData}
          sortField={sortField}
          sortDirection={sortDirection}
          onSort={handleSort}
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={handlePageChange}
        />
      </div>
    </div>
  );
}