import { useState } from 'react';

export function useVinFilters() {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const filterVinData = (data: any[], searchQuery: string) => {
    return data.filter((item) => {
      // Search by VIN or license plate
      const matchesSearch = searchQuery
        ? item.plaka.toLowerCase().includes(searchQuery.toLowerCase()) ||
          item.vin1.toLowerCase().includes(searchQuery.toLowerCase())
        : true;
      
      // Filter by date range
      const itemDate = new Date(item.tarih);
      const matchesStartDate = startDate ? itemDate >= new Date(startDate) : true;
      const matchesEndDate = endDate ? itemDate <= new Date(endDate) : true;

      return matchesSearch && matchesStartDate && matchesEndDate;
    });
  };

  return {
    startDate,
    endDate,
    setStartDate,
    setEndDate,
    filterVinData
  };
}