import { useState, useEffect } from 'react';

const sampleData = [
  {
    id: 6126,
    plaka: '01CIS46',
    sase: 'ZFA199000005336453',
    motor: 'Q',
    paket: 'Vin Hacker Paketi',
    ucret: 500,
    aciklama: 'Q',
    kontrolmod: 'FIAT',
    vin1: 'ZFA199000005336453',
    vin2: 'ZFA199000005336453',
    vin3: '',
    userid: 6,
    tarih: '2022-12-14 10:42:34',
    details: [
      { id: 6126, moduleName: 'EOBD Engine Control Module', value: 'ZFA199000005336453', value2: 'ZFA199000005336453' },
      { id: 6127, moduleName: 'Powertrain Control Module', value: 'ZFA199000005336453', value2: 'ZFA199000005336453' },
      { id: 6128, moduleName: 'Body Control Module', value: 'ZFA199000005336453', value2: 'ZFA199000005336453' },
      { id: 6129, moduleName: 'Transmission Control Module', value: 'ZFA199000005336453', value2: 'ZFA199000005336453' },
      { id: 6130, moduleName: 'Anti-Lock Braking System', value: 'ZFA199000005336453', value2: 'ZFA199000005336453' },
      { id: 6131, moduleName: 'Electronic Power Steering', value: 'ZFA199000005336453', value2: 'ZFA199000005336453' }
    ]
  }
];

export function useVinData() {
  const [vinData, setVinData] = useState(sampleData);

  useEffect(() => {
    // In the future, we can fetch real data here
    setVinData(sampleData);
  }, []);

  return {
    vinData
  };
}