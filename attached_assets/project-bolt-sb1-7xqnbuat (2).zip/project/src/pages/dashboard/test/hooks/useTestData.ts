import { useState, useEffect } from 'react';

const sampleData = [
  {
    id: 1,
    plaka: '34 FL 2346',
    markaModel: 'FIAT',
    saseNo: 'NM422500006873975',
    motorNo: '199A90005542258',
    kontrolMod: 'OBD',
    km: '176.673',
    ucret: 500,
    aciklama: 'Test başarılı',
    tarih: '2024-05-10T10:31:39',
    details: [
      { id: 61421, moduleName: 'Powertrain Control Module 1', value: '176673', time: '2024-05-10 10:31:39' },
      { id: 61419, moduleName: 'Engine Control Module DPF ReGen', value: '833', time: '2024-05-10 10:31:38' },
      { id: 61420, moduleName: 'Engine Control Module KM value at last Flash write', value: '0', time: '2024-05-10 10:31:38' },
      { id: 61416, moduleName: 'Engine Control Module', value: '329095 Minutes', time: '2024-05-10 10:31:37' },
      { id: 61415, moduleName: 'Engine Control Module EEPROM', value: '329089 Minutes', time: '2024-05-10 10:31:37' },
      { id: 61418, moduleName: 'Engine Control Module 2', value: '176673', time: '2024-05-10 10:31:37' },
      { id: 61417, moduleName: 'Engine Control Module 1', value: '8901', time: '2024-05-10 10:31:37' },
      { id: 61413, moduleName: 'Body Control Module EEPROM', value: '442660 Minutes', time: '2024-05-10 10:31:36' },
      { id: 61414, moduleName: 'Body Control Module', value: '442660 Minutes', time: '2024-05-10 10:31:36' },
      { id: 61412, moduleName: 'ESP', value: '305004 Minutes', time: '2024-05-10 10:31:36' },
      { id: 61411, moduleName: 'ESP EEPROM', value: '304998 Minutes', time: '2024-05-10 10:31:35' }
    ]
  }
];

export function useTestData() {
  const [testData, setTestData] = useState(sampleData);

  useEffect(() => {
    // In the future, we can fetch real data here
    setTestData(sampleData);
  }, []);

  return {
    testData
  };
}