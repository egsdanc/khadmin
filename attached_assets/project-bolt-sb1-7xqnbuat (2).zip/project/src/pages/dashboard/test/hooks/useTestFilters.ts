import { useState } from 'react';

export function useTestFilters() {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const filterTestData = (data: any[], searchQuery: string) => {
    return data.filter((item) => {
      // Search by license plate
      const matchesSearch = searchQuery
        ? (item.plaka || '').toLowerCase().includes(searchQuery.toLowerCase())
        : true;
      
      // Filter by date range
      const itemDate = new Date(item.tarih);
      const matchesStartDate = startDate ? itemDate >= new Date(startDate) : true;
      const matchesEndDate = endDate ? itemDate <= new Date(endDate) : true;

      return matchesSearch && matchesStartDate && matchesEndDate;
    });
  };

  return {
    startDate,
    endDate,
    setStartDate,
    setEndDate,
    filterTestData
  };
}