import { useRef, forwardRef } from 'react';
import { useReactToPrint } from 'react-to-print';

interface PrintContainerProps {
  children: React.ReactNode;
}

export function usePrintTest() {
  const componentRef = useRef<HTMLDivElement>(null);

  const PrintContainer = forwardRef<HTMLDivElement, PrintContainerProps>(
    ({ children }, ref) => (
      <div ref={ref} className="print-content">
        {children}
      </div>
    )
  );

  PrintContainer.displayName = 'PrintContainer';

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
    documentTitle: 'Test Raporu',
    removeAfterPrint: true,
    pageStyle: `
      @page {
        size: A4;
        margin: 20mm;
      }
      @media print {
        body {
          margin: 0;
          padding: 0;
        }
      }
    `,
    suppressErrors: true
  });

  return {
    PrintContainer,
    componentRef,
    handlePrint
  };
}