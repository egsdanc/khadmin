import { useRef } from 'react';
import { useReactToPrint } from 'react-to-print';
import { PrintContainer } from '../../../../components/PrintContainer';

export function usePrintTest() {
  const componentRef = useRef<HTMLDivElement>(null);

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
    documentTitle: 'Test Raporu',
    removeAfterPrint: true,
    pageStyle: `
      @page {
        size: A4;
        margin: 20mm;
      }
      @media print {
        body {
          margin: 0;
          padding: 0;
        }
      }
    `,
    suppressErrors: true
  });

  return {
    PrintContainer,
    componentRef,
    handlePrint
  };
}