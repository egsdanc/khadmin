export interface TestDetail {
  plaka: string;
  markaModel: string;
  saseNo: string;
  motorNo: string;
  kontrolMod: string;
  km: string;
  ucret: number;
  tarih: string;
  details: Array<{
    id: number;
    moduleName: string;
    value: string;
    time: string;
  }>;
}

export interface TestSearchFilters {
  plaka: string;
  startDate: string;
  endDate: string;
}