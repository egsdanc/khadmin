import React, { useState, useMemo } from 'react';
import { CarFront } from 'lucide-react';
import { VinHackerTable } from './components/VinHackerTable';
import { VinSearchFilters } from './components/VinSearchFilters';
import { useVinData } from './hooks/useVinData';
import { usePagination } from '../../../hooks/usePagination';
import { useSorting } from '../../../hooks/useSorting';

export function VinReaderPage() {
  const { vinData } = useVinData();
  const [filters, setFilters] = useState({
    startDate: '',
    endDate: '',
    searchQuery: ''
  });

  // Filtrelenmiş verileri hesapla
  const filteredData = useMemo(() => {
    return vinData.filter(record => {
      const recordDate = new Date(record.tarih);
      
      // Arama filtresi
      if (filters.searchQuery) {
        const searchLower = filters.searchQuery.toLowerCase();
        const matchesSearch = 
          record.plaka.toLowerCase().includes(searchLower) ||
          record.vin1.toLowerCase().includes(searchLower) ||
          record.vin2.toLowerCase().includes(searchLower);
        
        if (!matchesSearch) return false;
      }
      
      // Tarih aralığı kontrolü
      if (filters.startDate) {
        const startDate = new Date(filters.startDate);
        startDate.setHours(0, 0, 0, 0);
        if (recordDate < startDate) return false;
      }
      
      if (filters.endDate) {
        const endDate = new Date(filters.endDate);
        endDate.setHours(23, 59, 59, 999);
        if (recordDate > endDate) return false;
      }

      return true;
    });
  }, [vinData, filters]);

  // Sıralama hook'u
  const { sortedData, sortField, sortDirection, handleSort } = useSorting({
    data: filteredData,
    defaultSortField: 'tarih',
    defaultDirection: 'desc'
  });

  // Sayfalama hook'u
  const { 
    currentPage, 
    totalPages, 
    paginatedData, 
    handlePageChange 
  } = usePagination({
    data: sortedData,
    itemsPerPage: 10
  });

  const handleSearch = () => {
    // Filtreleme otomatik olarak yapılıyor
  };

  return (
    <div>
      <div className="sm:flex sm:items-center">
        <div className="sm:flex-auto">
          <div className="flex items-center gap-2">
            <CarFront className="h-6 w-6 text-indigo-600" />
            <h1 className="text-2xl font-semibold text-gray-900">VIN Hacker</h1>
          </div>
          <p className="mt-2 text-sm text-gray-700">
            Sistemde kayıtlı tüm VIN hacker işlemlerinin listesi
          </p>
        </div>
      </div>

      <div className="mt-8">
        <VinSearchFilters
          startDate={filters.startDate}
          endDate={filters.endDate}
          searchQuery={filters.searchQuery}
          onStartDateChange={(value) => setFilters(prev => ({ ...prev, startDate: value }))}
          onEndDateChange={(value) => setFilters(prev => ({ ...prev, endDate: value }))}
          onSearchQueryChange={(value) => setFilters(prev => ({ ...prev, searchQuery: value }))}
          onSearch={handleSearch}
        />

        <VinHackerTable 
          data={paginatedData}
          sortField={sortField}
          sortDirection={sortDirection}
          onSort={handleSort}
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={handlePageChange}
        />
      </div>
    </div>
  );
}