import React from 'react';
import { TestDetail } from '../../types/test.types';

interface TestResultsProps {
  details: TestDetail['details'];
}

export function TestResults({ details }: TestResultsProps) {
  return (
    <div>
      <h2 className="text-base font-semibold mb-4">Test Sonuçları</h2>
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b">
            <th className="text-left py-2 px-2 w-[40%]">Modül</th>
            <th className="text-left py-2 px-2 w-[30%]">Değer</th>
            <th className="text-left py-2 px-2 w-[30%]">Zaman</th>
          </tr>
        </thead>
        <tbody>
          {details.map((detail) => (
            <tr key={detail.id} className="border-b">
              <td className="py-2 px-2">
                <div className="truncate" title={detail.moduleName}>
                  {detail.moduleName}
                </div>
              </td>
              <td className="py-2 px-2">
                <div className="truncate" title={detail.value}>
                  {detail.value}
                </div>
              </td>
              <td className="py-2 px-2">
                {new Date(detail.time).toLocaleString('tr-TR')}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}