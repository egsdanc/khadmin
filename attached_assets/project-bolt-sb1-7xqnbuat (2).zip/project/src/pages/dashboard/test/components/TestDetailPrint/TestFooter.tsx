import React from 'react';
import { formatCurrency } from '../../../../../utils/format';
import { TestDetail } from '../../types/test.types';

interface TestFooterProps {
  test: TestDetail;
}

export function TestFooter({ test }: TestFooterProps) {
  return (
    <div className="mt-8 pt-4 border-t">
      <div className="flex justify-between items-center">
        <div>
          <p className="text-sm text-gray-600">Test Ücreti</p>
          <p className="font-medium text-lg">{formatCurrency(test.ucret)}</p>
        </div>
        <div className="text-right">
          <p className="text-sm text-gray-600">Rapor Tarihi</p>
          <p className="font-medium">{new Date().toLocaleDateString('tr-TR')}</p>
        </div>
      </div>
    </div>
  );
}