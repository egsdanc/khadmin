import React from 'react';
import { Calendar } from 'lucide-react';
import { Input } from '../../../../components/ui/Input';

interface VinDateFilterProps {
  startDate: string;
  endDate: string;
  onStartDateChange: (value: string) => void;
  onEndDateChange: (value: string) => void;
}

export function VinDateFilter({
  startDate,
  endDate,
  onStartDateChange,
  onEndDateChange
}: VinDateFilterProps) {
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
      <Input
        type="date"
        label="Başlangıç Tarihi"
        name="startDate"
        value={startDate}
        onChange={(e) => onStartDateChange(e.target.value)}
        icon={Calendar}
      />
      <Input
        type="date"
        label="Bitiş Tarihi"
        name="endDate"
        value={endDate}
        onChange={(e) => onEndDateChange(e.target.value)}
        icon={Calendar}
      />
    </div>
  );
}