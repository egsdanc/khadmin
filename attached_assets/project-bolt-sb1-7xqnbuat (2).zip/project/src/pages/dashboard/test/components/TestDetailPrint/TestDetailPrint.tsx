import React from 'react';
import { TestHeader } from './TestHeader';
import { VehicleInfo } from './VehicleInfo';
import { TestResults } from './TestResults';
import { TestFooter } from './TestFooter';
import { TestDetail } from '../../types/test.types';

interface TestDetailPrintProps {
  test: TestDetail;
}

export function TestDetailPrint({ test }: TestDetailPrintProps) {
  return (
    <div className="space-y-6">
      <TestHeader date={test.tarih} />
      <VehicleInfo test={test} />
      <TestResults details={test.details} />
      <TestFooter test={test} />
    </div>
  );
}