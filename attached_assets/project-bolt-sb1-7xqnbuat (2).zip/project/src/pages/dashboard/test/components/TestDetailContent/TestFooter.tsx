import React from 'react';
import { formatCurrency } from '../../../../../utils/format';
import { TestDetail } from '../../types/test.types';

interface TestFooterProps {
  test: TestDetail;
}

export function TestFooter({ test }: TestFooterProps) {
  return (
    <div className="border-t border-gray-200 pt-4">
      <div className="flex justify-between">
        <div>
          <p className="text-sm text-gray-500">Test Ücreti</p>
          <p className="mt-1 text-lg font-medium text-gray-900">{formatCurrency(test.ucret)}</p>
        </div>
        <div className="text-right">
          <p className="text-sm text-gray-500">Test Tarihi</p>
          <p className="mt-1 text-sm font-medium text-gray-900">
            {new Date(test.tarih).toLocaleString('tr-TR')}
          </p>
        </div>
      </div>
    </div>
  );
}