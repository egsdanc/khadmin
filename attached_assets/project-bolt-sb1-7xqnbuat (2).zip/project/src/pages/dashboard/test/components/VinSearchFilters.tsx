import React from 'react';
import { Calendar, Search } from 'lucide-react';
import { Input } from '../../../../components/ui/Input';
import { Button } from '../../../../components/ui/Button';

interface VinSearchFiltersProps {
  startDate: string;
  endDate: string;
  searchQuery: string;
  onStartDateChange: (value: string) => void;
  onEndDateChange: (value: string) => void;
  onSearchQueryChange: (value: string) => void;
  onSearch: () => void;
}

export function VinSearchFilters({
  startDate,
  endDate,
  searchQuery,
  onStartDateChange,
  onEndDateChange,
  onSearchQueryChange,
  onSearch
}: VinSearchFiltersProps) {
  return (
    <div className="bg-white p-6 rounded-lg shadow mb-6">
      <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-end">
        <div className="sm:col-span-3">
          <Input
            label="VIN/Plaka"
            value={searchQuery}
            onChange={(e) => onSearchQueryChange(e.target.value)}
            placeholder="VIN numarası veya plaka"
            icon={Search}
          />
        </div>
        <div className="sm:col-span-4">
          <Input
            type="date"
            label="Başlangıç Tarihi"
            value={startDate}
            onChange={(e) => onStartDateChange(e.target.value)}
            icon={Calendar}
          />
        </div>
        <div className="sm:col-span-3">
          <Input
            type="date"
            label="Bitiş Tarihi"
            value={endDate}
            onChange={(e) => onEndDateChange(e.target.value)}
            icon={Calendar}
          />
        </div>
        <div className="sm:col-span-2">
          <Button
            onClick={onSearch}
            className="w-full flex items-center justify-center gap-2"
          >
            <Search className="h-4 w-4" />
            Sorgula
          </Button>
        </div>
      </div>
    </div>
  );
}