import React, { useState } from 'react';
import { Badge } from '../../../../components/ui/Badge';
import { Button } from '../../../../components/ui/Button';
import { Pagination } from '../../../../components/ui/Pagination';
import { formatCurrency } from '../../../../utils/format';
import { VinDetailModal } from './VinDetailModal';
import { Eye, Download, ArrowUp, ArrowDown } from 'lucide-react';
import { VinPrintService } from '../../../../services/print/vin-print.service';

interface VinHackerRecord {
  id: number;
  plaka: string;
  sase: string;
  motor: string;
  paket: string;
  ucret: number;
  aciklama: string;
  kontrolmod: string;
  vin1: string;
  vin2: string;
  vin3: string;
  userid: number;
  tarih: string;
  details: Array<{
    id: number;
    moduleName: string;
    value: string;
    value2?: string;
  }>;
}

interface VinHackerTableProps {
  data: VinHackerRecord[];
  sortField?: keyof VinHackerRecord;
  sortDirection?: 'asc' | 'desc';
  onSort: (field: keyof VinHackerRecord) => void;
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

export function VinHackerTable({ 
  data,
  sortField,
  sortDirection,
  onSort,
  currentPage,
  totalPages,
  onPageChange
}: VinHackerTableProps) {
  const [selectedRecord, setSelectedRecord] = useState<VinHackerRecord | null>(null);

  const renderSortIcon = (field: keyof VinHackerRecord) => {
    if (sortField !== field) return null;
    return sortDirection === 'asc' ? 
      <ArrowUp className="h-4 w-4" /> : 
      <ArrowDown className="h-4 w-4" />;
  };

  return (
    <>
      <div className="mt-8 flow-root">
        <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
          <div className="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
            <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 sm:rounded-lg">
              <table className="min-w-full divide-y divide-gray-300">
                <thead className="bg-gray-50">
                  <tr>
                    {[
                      { field: 'tarih', label: 'Tarih' },
                      { field: 'plaka', label: 'Plaka' },
                      { field: 'sase', label: 'Şase No' },
                      { field: 'motor', label: 'Motor No' },
                      { field: 'vin1', label: 'VIN 1' },
                      { field: 'vin2', label: 'VIN 2' },
                      { field: 'vin3', label: 'VIN 3' },
                      { field: 'ucret', label: 'Ücret' }
                    ].map(({ field, label }) => (
                      <th 
                        key={field}
                        scope="col" 
                        className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900"
                        onClick={() => onSort(field as keyof VinHackerRecord)}
                        style={{ cursor: 'pointer' }}
                      >
                        <div className="flex items-center gap-2">
                          {label}
                          {renderSortIcon(field as keyof VinHackerRecord)}
                        </div>
                      </th>
                    ))}
                    <th scope="col" className="relative py-3.5 pl-3 pr-4 sm:pr-6">
                      <span className="sr-only">İşlemler</span>
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200 bg-white">
                  {data.map((record) => (
                    <tr key={record.id}>
                      <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm text-gray-900 sm:pl-6">
                        {new Date(record.tarih).toLocaleString('tr-TR')}
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm font-medium text-gray-900">
                        {record.plaka}
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                        {record.sase}
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                        {record.motor}
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                        {record.vin1}
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                        {record.vin2}
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                        {record.vin3}
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm font-medium text-green-600">
                        {formatCurrency(record.ucret)}
                      </td>
                      <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium sm:pr-6">
                        <div className="flex items-center justify-end space-x-2">
                          <Button
                            onClick={() => setSelectedRecord(record)}
                            variant="secondary"
                            size="sm"
                            className="inline-flex items-center gap-2"
                          >
                            <Eye className="h-4 w-4" />
                            Detay
                          </Button>
                          <Button
                            onClick={() => VinPrintService.generatePDF(record)}
                            variant="secondary"
                            size="sm"
                            className="inline-flex items-center gap-2"
                          >
                            <Download className="h-4 w-4" />
                            PDF
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {totalPages > 1 && (
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={onPageChange}
        />
      )}

      {selectedRecord && (
        <VinDetailModal
          isOpen={!!selectedRecord}
          onClose={() => setSelectedRecord(null)}
          vin={selectedRecord}
        />
      )}
    </>
  );
}