import React from 'react';
import { TestDetail } from '../../types/test.types';

interface TestResultsProps {
  details: TestDetail['details'];
}

export function TestResults({ details }: TestResultsProps) {
  return (
    <div>
      <h4 className="text-sm font-medium text-gray-900 mb-4">Modül</h4>
      <div className="mt-4 flow-root">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-300">
            <thead>
              <tr>
                <th scope="col" className="py-2 pl-2 pr-2 text-left text-sm font-semibold text-gray-900 w-[50%]">
                  Modül
                </th>
                <th scope="col" className="px-2 py-2 text-left text-sm font-semibold text-gray-900 w-[50%]">
                  Kilometre
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {details.map((detail) => (
                <tr key={detail.id}>
                  <td className="py-2 pl-2 pr-2 text-sm text-gray-900 text-left">
                    <div className="break-all" title={detail.moduleName}>
                      {detail.moduleName}
                    </div>
                  </td>
                  <td className="px-2 py-2 text-sm text-gray-500 text-left">
                    <div className="break-all" title={detail.value}>
                      {detail.value}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}