import React from 'react';
import { formatCurrency } from '../../../../utils/format';
import { TestDetail } from '../types/test.types';

interface TestDetailContentProps {
  test: TestDetail;
}

export function TestDetailContent({ test }: TestDetailContentProps) {
  return (
    <div className="space-y-8">
      {/* Vehicle Information */}
      <div>
        <h4 className="text-sm font-medium text-gray-900 mb-4">Araç Bilgileri</h4>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-gray-500">Plaka</p>
            <p className="mt-1 text-sm font-medium text-gray-900">{test.plaka}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Marka/Model</p>
            <p className="mt-1 text-sm font-medium text-gray-900">{test.markaModel}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Şase No</p>
            <p className="mt-1 text-sm font-medium text-gray-900">{test.saseNo}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Motor No</p>
            <p className="mt-1 text-sm font-medium text-gray-900">{test.motorNo}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Kontrol Mod</p>
            <p className="mt-1 text-sm font-medium text-gray-900">{test.kontrolMod}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Kilometre</p>
            <p className="mt-1 text-sm font-medium text-gray-900">{test.km}</p>
          </div>
        </div>
      </div>

      {/* Test Results */}
      <div>
        <h4 className="text-sm font-medium text-gray-900 mb-4">Test Sonuçları</h4>
        <div className="mt-4 flow-root">
          <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
            <div className="inline-block min-w-full py-2 align-middle">
              <table className="min-w-full divide-y divide-gray-300">
                <thead>
                  <tr>
                    <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-0">
                      Modül
                    </th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                      Değer
                    </th>
                    <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                      Zaman
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {test.details.map((detail) => (
                    <tr key={detail.id}>
                      <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm text-gray-900 sm:pl-0">
                        {detail.moduleName}
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                        {detail.value}
                      </td>
                      <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                        {new Date(detail.time).toLocaleString('tr-TR')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="border-t border-gray-200 pt-4">
        <div className="flex justify-between">
          <div>
            <p className="text-sm text-gray-500">Test Ücreti</p>
            <p className="mt-1 text-lg font-medium text-gray-900">{formatCurrency(test.ucret)}</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-500">Test Tarihi</p>
            <p className="mt-1 text-sm font-medium text-gray-900">
              {new Date(test.tarih).toLocaleString('tr-TR')}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}