import React from 'react';

interface TestHeaderProps {
  date: string;
}

export function TestHeader({ date }: TestHeaderProps) {
  return (
    <div className="text-center mb-8">
      <h1 className="text-2xl font-bold">Kilometre Hacker</h1>
      <p className="text-gray-500 text-sm">
        {new Date(date).toLocaleString('tr-TR')}
      </p>
    </div>
  );
}