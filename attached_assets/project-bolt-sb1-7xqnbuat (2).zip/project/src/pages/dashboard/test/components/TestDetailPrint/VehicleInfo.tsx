import React from 'react';
import { TestDetail } from '../../types/test.types';

interface VehicleInfoProps {
  test: TestDetail;
}

export function VehicleInfo({ test }: VehicleInfoProps) {
  return (
    <div className="mb-8">
      <h2 className="text-lg font-semibold border-b pb-2 mb-4">Araç Bilgileri</h2>
      <div className="grid grid-cols-2 gap-4">
        <InfoItem label="Plaka" value={test.plaka} />
        <InfoItem label="Marka/Model" value={test.markaModel} />
        <InfoItem label="Şase No" value={test.saseNo} />
        <InfoItem label="Motor No" value={test.motorNo} />
        <InfoItem label="Kontrol Mod" value={test.kontrolMod} />
        <InfoItem label="Kilometre" value={test.km} />
      </div>
    </div>
  );
}

interface InfoItemProps {
  label: string;
  value: string;
}

function InfoItem({ label, value }: InfoItemProps) {
  return (
    <div>
      <p className="text-sm text-gray-600">{label}</p>
      <p className="font-medium">{value}</p>
    </div>
  );
}