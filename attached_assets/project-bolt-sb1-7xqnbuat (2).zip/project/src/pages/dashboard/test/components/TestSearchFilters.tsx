import React from 'react';
import { Search, Calendar } from 'lucide-react';
import { Input } from '../../../../components/ui/Input';
import { Button } from '../../../../components/ui/Button';

interface TestSearchFiltersProps {
  plaka: string;
  startDate: string;
  endDate: string;
  onPlakaChange: (value: string) => void;
  onStartDateChange: (value: string) => void;
  onEndDateChange: (value: string) => void;
  onSearch: () => void;
}

export function TestSearchFilters({
  plaka,
  startDate,
  endDate,
  onPlakaChange,
  onStartDateChange,
  onEndDateChange,
  onSearch
}: TestSearchFiltersProps) {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch();
  };

  return (
    <div className="bg-white shadow sm:rounded-lg mb-6">
      <form onSubmit={handleSubmit} className="px-4 py-5 sm:p-6">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-end">
          <div className="sm:col-span-4">
            <Input
              label="Plaka"
              name="search"
              value={plaka}
              onChange={(e) => onPlakaChange(e.target.value)}
              placeholder="Plaka numarası giriniz"
              icon={Search}
            />
          </div>
          <div className="sm:col-span-3">
            <Input
              type="date"
              label="Başlangıç Tarihi"
              name="startDate"
              value={startDate}
              onChange={(e) => onStartDateChange(e.target.value)}
              icon={Calendar}
            />
          </div>
          <div className="sm:col-span-3">
            <Input
              type="date"
              label="Bitiş Tarihi"
              name="endDate"
              value={endDate}
              onChange={(e) => onEndDateChange(e.target.value)}
              icon={Calendar}
            />
          </div>
          <div className="sm:col-span-2">
            <Button type="submit" className="w-full inline-flex items-center justify-center gap-2">
              <Search className="h-4 w-4" />
              Ara
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
}