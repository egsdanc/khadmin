import React from 'react';
import { VehicleInfo } from './VehicleInfo';
import { TestResults } from './TestResults';
import { TestFooter } from './TestFooter';
import { TestDetail } from '../../types/test.types';

interface TestDetailContentProps {
  test: TestDetail;
}

export function TestDetailContent({ test }: TestDetailContentProps) {
  return (
    <div className="space-y-8">
      <VehicleInfo test={test} />
      <TestResults details={test.details} />
      <TestFooter test={test} />
    </div>
  );
}