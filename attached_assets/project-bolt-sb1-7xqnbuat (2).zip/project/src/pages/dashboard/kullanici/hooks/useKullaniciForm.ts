import { useState } from 'react';
import toast from 'react-hot-toast';

interface KullaniciFormData {
  ad: string;
  email: string;
  password: string;
  firma: string;
  role: string;
  bayi: string;
}

const initialFormData: KullaniciFormData = {
  ad: '',
  email: '',
  password: '',
  firma: '',
  role: '',
  bayi: ''
};

export function useKullaniciForm(initialData?: Partial<KullaniciFormData>) {
  const [formData, setFormData] = useState<KullaniciFormData>({
    ...initialFormData,
    ...initialData
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const validateForm = (): boolean => {
    if (!formData.ad) {
      toast.error('Ad alanı zorunludur');
      return false;
    }
    if (!formData.email) {
      toast.error('E-posta alanı zorunludur');
      return false;
    }
    if (!initialData && !formData.password) {
      toast.error('Şifre alanı zorunludur');
      return false;
    }
    if (!formData.firma) {
      toast.error('Firma seçimi zorunludur');
      return false;
    }
    if (!formData.role) {
      toast.error('Rol seçimi zorunludur');
      return false;
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setLoading(true);

    try {
      // API call will be implemented here
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
      toast.success(initialData ? 'Kullanıcı başarıyla güncellendi' : 'Kullanıcı başarıyla eklendi');
      if (!initialData) {
        setFormData(initialFormData);
      }
    } catch (error) {
      toast.error(initialData ? 'Kullanıcı güncellenirken bir hata oluştu' : 'Kullanıcı eklenirken bir hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  return {
    formData,
    handleChange,
    handleSubmit,
    loading
  };
}