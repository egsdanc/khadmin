import React, { useState } from 'react';
import { Users } from 'lucide-react';
import { KullaniciTabs } from './components/KullaniciTabs';
import { KullaniciList } from './components/KullaniciList';
import { KullaniciAdd } from './components/KullaniciAdd';

export function KullaniciListPage() {
  const [activeTab, setActiveTab] = useState('list');

  return (
    <div>
      <div className="sm:flex sm:items-center">
        <div className="sm:flex-auto">
          <div className="flex items-center gap-2">
            <Users className="h-6 w-6 text-indigo-600" />
            <h1 className="text-2xl font-semibold text-gray-900">Panel Kullanıcıları</h1>
          </div>
          <p className="mt-2 text-sm text-gray-700">
            Sistemde kayıtlı tüm panel kullanıcılarının listesi ve yönetimi
          </p>
        </div>
      </div>

      <div className="mt-6">
        <KullaniciTabs activeTab={activeTab} onTabChange={setActiveTab} />
        
        <div className="mt-6">
          {activeTab === 'list' ? <KullaniciList /> : <KullaniciAdd />}
        </div>
      </div>
    </div>
  );
}