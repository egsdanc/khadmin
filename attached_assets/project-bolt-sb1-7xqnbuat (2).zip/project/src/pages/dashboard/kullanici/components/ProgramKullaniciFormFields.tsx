import React from 'react';
import { Input } from '../../../../components/ui/Input';
import { Select } from '../../../../components/ui/Select';

interface ProgramKullaniciFormFieldsProps {
  formData: Record<string, string>;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
}

export function ProgramKullaniciFormFields({ formData, onChange }: ProgramKullaniciFormFieldsProps) {
  return (
    <div className="grid grid-cols-1 gap-x-6 gap-y-8">
      <div className="col-span-full">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Input
            label="İsim"
            name="isim"
            required
            placeholder="Kullanıcı ismini giriniz"
            value={formData.isim}
            onChange={onChange}
          />
          <Input
            label="Şifre"
            name="sifre"
            type="password"
            required
            placeholder="Şifre giriniz"
            value={formData.sifre}
            onChange={onChange}
          />
          <Input
            label="MAC Adresi"
            name="macAddress"
            required
            placeholder="MAC adresini giriniz"
            value={formData.macAddress}
            onChange={onChange}
          />
          <Select
            label="First Login"
            name="firstLogin"
            required
            value={formData.firstLogin}
            onChange={onChange}
          >
            <option value="">Seçiniz</option>
            <option value="1">Aktif</option>
            <option value="0">Pasif</option>
          </Select>
        </div>
      </div>
    </div>
  );
}