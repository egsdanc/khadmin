import React from 'react';
import { ListFilter, Plus } from 'lucide-react';
import { cn } from '../../../../utils/cn';

interface KullaniciTabsProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function KullaniciTabs({ activeTab, onTabChange }: KullaniciTabsProps) {
  const tabs = [
    { id: 'list', name: 'Kullanıcı Listesi', icon: ListFilter },
    { id: 'add', name: 'Kullanıcı Ekle', icon: Plus }
  ];

  return (
    <div className="border-b border-gray-200">
      <nav className="-mb-px flex space-x-8" aria-label="Tabs">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={cn(
              'group inline-flex items-center border-b-2 py-4 px-1',
              'font-medium text-sm',
              activeTab === tab.id
                ? 'border-indigo-500 text-indigo-600'
                : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700'
            )}
          >
            <tab.icon
              className={cn(
                'h-5 w-5 mr-2',
                activeTab === tab.id
                  ? 'text-indigo-500'
                  : 'text-gray-400 group-hover:text-gray-500'
              )}
            />
            {tab.name}
          </button>
        ))}
      </nav>
    </div>
  );
}