import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Badge } from '../../../../components/ui/Badge';
import { Button } from '../../../../components/ui/Button';
import { Plus } from 'lucide-react';
import { KullaniciFilters } from './KullaniciFilters';
import { useUserFilters } from '../../../../hooks/user/useUserFilters';

// Mock user data
const mockUsers = [
  {
    id: 1,
    ad: 'Super Admin',
    email: 'admin@example.com',
    firma: 0,
    role: 1,
    aktif: true
  },
  {
    id: 2,
    ad: 'Garantili Arabam Admin',
    email: 'admin@garantiliarabam.com',
    firma: 1,
    role: 2,
    aktif: true
  },
  {
    id: 3,
    ad: 'General Oto Admin',
    email: 'admin@generaloto.com',
    firma: 2,
    role: 2,
    aktif: true
  },
  {
    id: 4,
    ad: 'Dynobil Admin',
    email: 'admin@dynobil.com',
    firma: 3,
    role: 2,
    aktif: false
  }
];

export function KullaniciList() {
  const navigate = useNavigate();
  const { filters, filteredUsers, handleFilterChange } = useUserFilters(mockUsers);
  const [editingUser, setEditingUser] = useState(null);

  const getRoleName = (role: number) => {
    switch (role) {
      case 1: return 'Super Admin';
      case 2: return 'Admin';
      case 3: return 'Kullanıcı';
      default: return 'Bilinmiyor';
    }
  };

  const getFirmaName = (firma: number) => {
    switch (firma) {
      case 0: return 'Merkez';
      case 1: return 'Garantili Arabam';
      case 2: return 'General Oto Ekspertiz';
      case 3: return 'Dynobil';
      default: return 'Bilinmiyor';
    }
  };

  return (
    <div>
      <KullaniciFilters 
        filters={filters}
        onChange={handleFilterChange}
      />

      {filteredUsers.length === 0 ? (
        <div className="text-center py-12 bg-white shadow-sm rounded-lg">
          <svg
            className="mx-auto h-12 w-12 text-gray-400"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"
            />
          </svg>
          <h3 className="mt-2 text-sm font-medium text-gray-900">Kullanıcı bulunamadı</h3>
          <p className="mt-1 text-sm text-gray-500">Yeni kullanıcı ekleyerek başlayın veya filtreleri değiştirin.</p>
          <div className="mt-6">
            <Button
              onClick={() => navigate('/dashboard/kullanicilar/ekle')}
              className="inline-flex items-center gap-2"
            >
              <Plus className="h-4 w-4" />
              Yeni Kullanıcı Ekle
            </Button>
          </div>
        </div>
      ) : (
        <div className="mt-4">
          <div className="overflow-x-auto">
            <div className="inline-block min-w-full align-middle">
              <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 sm:rounded-lg">
                <table className="min-w-full divide-y divide-gray-300">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900">
                        Ad
                      </th>
                      <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                        E-posta
                      </th>
                      <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                        Firma
                      </th>
                      <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                        Rol
                      </th>
                      <th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">
                        Durum
                      </th>
                      <th scope="col" className="relative py-3.5 pl-3 pr-4 sm:pr-6">
                        <span className="sr-only">İşlemler</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 bg-white">
                    {filteredUsers.map((user) => (
                      <tr key={user.id}>
                        <td className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900">
                          {user.ad}
                        </td>
                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                          {user.email}
                        </td>
                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                          {getFirmaName(user.firma)}
                        </td>
                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                          <Badge variant={user.role === 1 ? 'success' : 'secondary'}>
                            {getRoleName(user.role)}
                          </Badge>
                        </td>
                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                          <Badge variant={user.aktif ? 'success' : 'danger'}>
                            {user.aktif ? 'Aktif' : 'Pasif'}
                          </Badge>
                        </td>
                        <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium">
                          <button
                            onClick={() => setEditingUser(user)}
                            className="text-indigo-600 hover:text-indigo-900 mr-4"
                          >
                            Düzenle
                          </button>
                          <button
                            onClick={() => {}}
                            className="text-red-600 hover:text-red-900"
                          >
                            Sil
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}