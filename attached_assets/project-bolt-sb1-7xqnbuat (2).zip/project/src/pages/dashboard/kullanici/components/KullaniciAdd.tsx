import React from 'react';
import { useKullaniciForm } from '../hooks/useKullaniciForm';
import { KullaniciFormFields } from './KullaniciFormFields';
import { KullaniciFormActions } from './KullaniciFormActions';

export function KullaniciAdd() {
  const { formData, handleChange, handleSubmit, loading } = useKullaniciForm();

  return (
    <div className="space-y-10">
      <form className="bg-white shadow-sm ring-1 ring-gray-900/5 rounded-xl" onSubmit={handleSubmit}>
        <div className="px-4 py-6 sm:p-8">
          <KullaniciFormFields
            formData={formData}
            onChange={handleChange}
          />
        </div>
        
        <KullaniciFormActions loading={loading} />
      </form>
    </div>
  );
}