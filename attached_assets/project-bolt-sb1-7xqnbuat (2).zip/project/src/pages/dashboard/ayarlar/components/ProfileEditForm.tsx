import React from 'react';
import { Input } from '../../../../components/ui/Input';
import { Button } from '../../../../components/ui/Button';

interface ProfileEditFormProps {
  formData: {
    username: string;
    email: string;
    currentPassword: string;
    newPassword: string;
    confirmPassword: string;
  };
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onSubmit: (e: React.FormEvent) => Promise<void>;
  loading: boolean;
}

export function ProfileEditForm({ formData, onChange, onSubmit, loading }: ProfileEditFormProps) {
  return (
    <form onSubmit={onSubmit} className="space-y-6">
      <Input
        label="Kullanıcı Adı"
        name="username"
        value={formData.username}
        onChange={onChange}
        required
      />
      
      <Input
        label="E-posta"
        name="email"
        type="email"
        value={formData.email}
        onChange={onChange}
        required
      />

      <div className="border-t border-gray-200 pt-6">
        <h4 className="text-sm font-medium text-gray-900 mb-4">Şifre Değiştir</h4>
        
        <div className="space-y-4">
          <Input
            label="Mevcut Şifre"
            name="currentPassword"
            type="password"
            value={formData.currentPassword}
            onChange={onChange}
          />
          
          <Input
            label="Yeni Şifre"
            name="newPassword"
            type="password"
            value={formData.newPassword}
            onChange={onChange}
          />
          
          <Input
            label="Yeni Şifre (Tekrar)"
            name="confirmPassword"
            type="password"
            value={formData.confirmPassword}
            onChange={onChange}
          />
        </div>
      </div>

      <div className="mt-5 sm:mt-4 sm:flex sm:flex-row-reverse">
        <Button
          type="submit"
          loading={loading}
          className="w-full sm:ml-3 sm:w-auto"
        >
          Kaydet
        </Button>
        <Button
          type="button"
          variant="secondary"
          onClick={() => window.location.reload()}
          className="mt-3 w-full sm:mt-0 sm:w-auto"
        >
          İptal
        </Button>
      </div>
    </form>
  );
}