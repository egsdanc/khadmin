import { useState } from 'react';
import toast from 'react-hot-toast';
import { useAuthStore } from '../../../../store/auth.store';

interface ProfileFormData {
  username: string;
  email: string;
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
}

export function useProfileEdit(onSuccess?: () => void) {
  const user = useAuthStore(state => state.user);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<ProfileFormData>({
    username: user?.ad || '',
    email: user?.email || '',
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const validateForm = (): boolean => {
    if (!formData.username || !formData.email) {
      toast.error('Kullanıcı adı ve e-posta alanları zorunludur');
      return false;
    }

    if (formData.newPassword || formData.confirmPassword) {
      if (!formData.currentPassword) {
        toast.error('Mevcut şifrenizi girmelisiniz');
        return false;
      }
      
      if (formData.newPassword !== formData.confirmPassword) {
        toast.error('Yeni şifreler eşleşmiyor');
        return false;
      }
    }

    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setLoading(true);

    try {
      // API call will be implemented here
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success('Profil başarıyla güncellendi');
      onSuccess?.();
    } catch (error) {
      toast.error('Profil güncellenirken bir hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  return {
    formData,
    handleChange,
    handleSubmit,
    loading
  };
}