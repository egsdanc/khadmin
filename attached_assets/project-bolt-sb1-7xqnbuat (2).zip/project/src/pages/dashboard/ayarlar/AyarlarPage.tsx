import React, { useState } from 'react';
import { Settings } from 'lucide-react';
import { ProfileEditModal } from './components/ProfileEditModal';

export function AyarlarPage() {
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  return (
    <div>
      <div className="sm:flex sm:items-center">
        <div className="sm:flex-auto">
          <h1 className="text-2xl font-semibold text-gray-900">Ayarlar</h1>
          <p className="mt-2 text-sm text-gray-700">
            Sistem ayarlarını buradan yönetebilirsiniz
          </p>
        </div>
      </div>

      <div className="mt-8">
        <div className="divide-y divide-gray-200 overflow-hidden rounded-lg bg-white shadow">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-base font-semibold leading-6 text-gray-900">
              Profil Ayarları
            </h3>
            <div className="mt-2 max-w-xl text-sm text-gray-500">
              <p>Profil bilgilerinizi ve şifrenizi güncelleyebilirsiniz.</p>
            </div>
            <div className="mt-5">
              <button
                type="button"
                onClick={() => setIsEditModalOpen(true)}
                className="rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
              >
                Profili Düzenle
              </button>
            </div>
          </div>
          
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-base font-semibold leading-6 text-gray-900">
              Sistem Ayarları
            </h3>
            <div className="mt-2 max-w-xl text-sm text-gray-500">
              <p>Genel sistem ayarlarını yapılandırabilirsiniz.</p>
            </div>
            <div className="mt-5">
              <button
                type="button"
                className="rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
              >
                Ayarları Düzenle
              </button>
            </div>
          </div>
        </div>
      </div>

      <ProfileEditModal 
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
      />
    </div>
  );
}