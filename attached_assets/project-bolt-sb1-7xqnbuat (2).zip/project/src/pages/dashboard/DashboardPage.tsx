import React from 'react';
import { DashboardCharts } from './components/DashboardCharts';
import { RevenueCards } from '../../components/dashboard/RevenueCards';
import { CompanyRevenueList } from '../../components/dashboard/CompanyRevenueList';
import { MonthlyRevenueChart } from '../../components/dashboard/MonthlyRevenueChart';
import { useTestData } from './test/hooks/useTestData';
import { useVinData } from './test/hooks/useVinData';
import { calculateTotalRevenues } from '../../utils/revenue';

export function DashboardPage() {
  const { testData } = useTestData();
  const { vinData } = useVinData();

  // Son 7 günlük test sayıları
  const last7DaysTests = testData.slice(-7);
  const last7DaysVins = vinData.slice(-7);

  // Firma bazlı test dağılımı ve gelir hesaplaması
  const companyStats = calculateTotalRevenues([
    { name: 'Garantili Arabam', totalTests: 450 },
    { name: 'General Oto Ekspertiz', totalTests: 420 },
    { name: 'Dynobil', totalTests: 400 }
  ]);

  return (
    <div className="space-y-6">
      {/* Gelir Kartları */}
      <RevenueCards data={{ companies: companyStats }} />

      {/* Aylık Gelir Grafiği */}
      <MonthlyRevenueChart />

      {/* Firma Bazlı Gelirler Tablosu */}
      <CompanyRevenueList companies={companyStats} />

      {/* Grafikler */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Test Sayıları Grafiği */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-base font-semibold text-gray-900 mb-4">
            Son 7 Gün Test Sayıları
          </h3>
          <DashboardCharts.TestCountChart 
            testData={last7DaysTests}
            vinData={last7DaysVins}
          />
        </div>

        {/* Firma Bazlı Dağılım */}
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-base font-semibold text-gray-900 mb-4">
            Firma Bazlı Test Dağılımı
          </h3>
          <DashboardCharts.CompanyDistributionChart 
            data={companyStats}
          />
        </div>
      </div>
    </div>
  );
}