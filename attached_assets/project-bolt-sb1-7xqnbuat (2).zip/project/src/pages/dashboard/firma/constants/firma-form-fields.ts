import { FormField } from '../types/firma-form.types';

export function getTemelBilgilerFields(): FormField[] {
  return [
    { 
      name: 'name',
      label: 'Firma Adı (name)',
      required: true,
      placeholder: 'Firma adını giriniz'
    },
    { 
      name: 'legalCompanyTitle',
      label: 'Şirket Ünvanı (legalCompanyTitle)',
      required: true,
      placeholder: 'Şirket ünvanını giriniz'
    },
    { 
      name: 'email',
      label: 'E-posta (email)',
      type: 'email',
      required: true,
      placeholder: 'ornek@firma.com'
    },
    { 
      name: 'gsmNumber',
      label: 'GSM Numarası (gsmNumber)',
      required: true,
      placeholder: '05XX XXX XX XX'
    },
    { 
      name: 'address',
      label: 'Adres (address)',
      required: true,
      placeholder: 'Firma adresini giriniz'
    }
  ];
}

export function getVergiBilgileriFields(): FormField[] {
  return [
    { 
      name: 'taxOffice',
      label: 'Vergi Dairesi (taxOffice)',
      required: true,
      placeholder: 'Vergi dairesini giriniz'
    },
    { 
      name: 'taxNumber',
      label: 'Vergi Numarası (taxNumber)',
      placeholder: 'Vergi numarasını giriniz'
    },
    { 
      name: 'identityNumber',
      label: 'Kimlik Numarası (identityNumber)',
      placeholder: 'TC Kimlik numarasını giriniz'
    }
  ];
}

export function getBankaBilgileriFields(): FormField[] {
  return [
    { 
      name: 'iban',
      label: 'IBAN (iban)',
      required: true,
      placeholder: 'TR XX XXXX XXXX XXXX XXXX XXXX XX'
    }
  ];
}

export function getSubMerchantFields(): FormField[] {
  return [
    { 
      name: 'subMerchantExternalId',
      label: 'Sub Merchant External ID (subMerchantExternalId)',
      placeholder: 'External ID giriniz'
    },
    { 
      name: 'subMerchantType',
      label: 'Sub Merchant Type (subMerchantType)',
      placeholder: 'Type değerini giriniz'
    },
    { 
      name: 'subMerchantKey',
      label: 'Sub Merchant Key (subMerchantKey)',
      placeholder: 'Key değerini giriniz'
    }
  ];
}