import React, { useState } from 'react';
import { Building2 } from 'lucide-react';
import { FirmaTabs } from './components/FirmaTabs';
import { FirmaList } from './components/FirmaList';
import { FirmaAdd } from './components/FirmaAdd';

export function FirmaListPage() {
  const [activeTab, setActiveTab] = useState('list');

  return (
    <div>
      <div className="sm:flex sm:items-center">
        <div className="sm:flex-auto">
          <div className="flex items-center gap-2">
            <Building2 className="h-6 w-6 text-indigo-600" />
            <h1 className="text-2xl font-semibold text-gray-900">Firmalar</h1>
          </div>
          <p className="mt-2 text-sm text-gray-700">
            Sistemde kayıtlı tüm firmaların listesi ve yönetimi
          </p>
        </div>
      </div>

      <div className="mt-6">
        <FirmaTabs activeTab={activeTab} onTabChange={setActiveTab} />
        
        <div className="mt-6">
          {activeTab === 'list' ? <FirmaList /> : <FirmaAdd />}
        </div>
      </div>
    </div>
  );
}