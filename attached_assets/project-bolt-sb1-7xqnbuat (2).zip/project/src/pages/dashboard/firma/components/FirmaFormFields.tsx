import React from 'react';
import { FirmaFormSection } from './FirmaFormSection';
import { 
  getTemelBilgilerFields,
  getVergiBilgileriFields,
  getBankaBilgileriFields,
  getSubMerchantFields
} from '../constants/firma-form-fields';

interface FirmaFormFieldsProps {
  formData: Record<string, string>;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export function FirmaFormFields({ formData, onChange }: FirmaFormFieldsProps) {
  return (
    <div className="grid grid-cols-1 gap-x-6 gap-y-8 sm:grid-cols-6">
      <FirmaFormSection
        title="Firma Temel Bilgileri"
        fields={getTemelBilgilerFields()}
        values={formData}
        onChange={onChange}
      />

      <FirmaFormSection
        title="Vergi Bilgileri"
        fields={getVergiBilgileriFields()}
        values={formData}
        onChange={onChange}
      />

      <FirmaFormSection
        title="Banka Bilgileri"
        fields={getBankaBilgileriFields()}
        values={formData}
        onChange={onChange}
      />

      <FirmaFormSection
        title="Sub Merchant Bilgileri"
        fields={getSubMerchantFields()}
        values={formData}
        onChange={onChange}
      />
    </div>
  );
}