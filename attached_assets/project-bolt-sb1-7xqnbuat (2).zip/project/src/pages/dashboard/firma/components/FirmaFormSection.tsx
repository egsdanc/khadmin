import React from 'react';
import { Input } from '../../../../components/ui/Input';

interface Field {
  name: string;
  label: string;
  type?: string;
  required?: boolean;
  placeholder?: string;
}

interface FirmaFormSectionProps {
  title: string;
  description?: string;
  fields: Field[];
  values: Record<string, string>;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export function FirmaFormSection({ 
  title, 
  description, 
  fields, 
  values, 
  onChange 
}: FirmaFormSectionProps) {
  return (
    <div className="col-span-full">
      <div className="mb-4">
        <h3 className="text-sm font-medium leading-6 text-gray-900">{title}</h3>
        {description && (
          <p className="mt-1 text-sm text-gray-500">{description}</p>
        )}
      </div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        {fields.map((field) => (
          <Input
            key={field.name}
            label={field.label}
            name={field.name}
            type={field.type || 'text'}
            required={field.required}
            placeholder={field.placeholder}
            value={values[field.name]}
            onChange={onChange}
          />
        ))}
      </div>
    </div>
  );
}