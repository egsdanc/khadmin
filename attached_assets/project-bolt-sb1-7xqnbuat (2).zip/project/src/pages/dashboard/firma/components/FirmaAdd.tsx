import React from 'react';
import { useFirmaForm } from '../hooks/useFirmaForm';
import { FirmaFormFields } from './FirmaFormFields';
import { FirmaFormActions } from './FirmaFormActions';

export function FirmaAdd() {
  const { formData, handleChange, handleSubmit, loading } = useFirmaForm();

  return (
    <div className="space-y-10">
      <form className="bg-white shadow-sm ring-1 ring-gray-900/5 rounded-xl" onSubmit={handleSubmit}>
        <div className="px-4 py-6 sm:p-8">
          <FirmaFormFields
            formData={formData}
            onChange={handleChange}
          />
        </div>
        
        <FirmaFormActions loading={loading} />
      </form>
    </div>
  );
}