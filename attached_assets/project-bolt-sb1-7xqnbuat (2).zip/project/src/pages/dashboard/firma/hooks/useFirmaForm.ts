import { useState } from 'react';
import toast from 'react-hot-toast';

interface FirmaFormData {
  name: string;
  gsmNumber: string;
  taxOffice: string;
  legalCompanyTitle: string;
  email: string;
  address: string;
  iban: string;
  subMerchantExternalId: string;
  identityNumber: string;
  subMerchantType: string;
  subMerchantKey: string;
  taxNumber: string;
}

const initialFormData: FirmaFormData = {
  name: '',
  gsmNumber: '',
  taxOffice: '',
  legalCompanyTitle: '',
  email: '',
  address: '',
  iban: '',
  subMerchantExternalId: '',
  identityNumber: '',
  subMerchantType: '',
  subMerchantKey: '',
  taxNumber: ''
};

export function useFirmaForm(onSuccess?: () => void) {
  const [formData, setFormData] = useState<FirmaFormData>(initialFormData);
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // API call will be implemented here
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
      toast.success('Firma başarıyla eklendi');
      onSuccess?.();
    } catch (error) {
      toast.error('Firma eklenirken bir hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  return {
    formData,
    handleChange,
    handleSubmit,
    loading
  };
}