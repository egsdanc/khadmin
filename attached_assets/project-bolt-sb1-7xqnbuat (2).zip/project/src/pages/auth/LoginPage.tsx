import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield } from 'lucide-react';
import { Input } from '../../components/ui/Input';
import { Button } from '../../components/ui/Button';
import { AuthService } from '../../services/auth/auth.service';
import { useAuthStore } from '../../store/auth.store';
import toast from 'react-hot-toast';

export function LoginPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const setAuth = useAuthStore(state => state.setAuth);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await AuthService.login({ username, password });
      setAuth(response.user, response.token);
      toast.success('Giriş başarılı');
      navigate('/dashboard');
    } catch (error) {
      toast.error('Giriş başarısız');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-50 to-blue-50">
      <div className="max-w-md w-full px-4">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-6">
            <Shield className="h-12 w-12 text-indigo-600" />
          </div>
          <h2 className="text-3xl font-extrabold text-gray-900 mb-2">
            Kilometre Hacker Paneli
          </h2>
          <p className="text-gray-600">
            Kilometre Hacker: Aracınızın Aklını Alır!
          </p>
        </div>

        <div className="bg-white py-8 px-4 shadow-lg sm:rounded-lg sm:px-10">
          <form className="space-y-6" onSubmit={handleSubmit}>
            <Input
              name="username"
              type="text"
              required
              placeholder="Kullanıcı adı"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />

            <Input
              name="password"
              type="password" 
              required
              placeholder="Şifre"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />

            <Button
              type="submit"
              loading={loading}
              className="w-full"
            >
              Giriş Yap
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}