import { create } from 'zustand';
import { Dealer, DealerFormData } from '../types/dealer.types';
import { dealerApi } from '../services/api/dealer.api';
import { API_MESSAGES } from '../config/api/messages';

interface DealerState {
  dealers: Dealer[];
  loading: boolean;
  error: string | null;
  fetchDealers: () => Promise<void>;
  createDealer: (data: DealerFormData) => Promise<void>;
}

export const useDealerStore = create<DealerState>((set) => ({
  dealers: [],
  loading: false,
  error: null,

  fetchDealers: async () => {
    try {
      set({ loading: true, error: null });
      const dealers = await dealerApi.getAllDealers();
      set({ dealers, loading: false });
    } catch (error) {
      set({ error: API_MESSAGES.DEALER.FETCH_ERROR, loading: false });
      throw error;
    }
  },

  createDealer: async (data: DealerFormData) => {
    try {
      set({ loading: true, error: null });
      const newDealer = await dealerApi.createDealer(data);
      set(state => ({
        dealers: [newDealer, ...state.dealers],
        loading: false
      }));
    } catch (error) {
      set({ error: API_MESSAGES.DEALER.CREATE_ERROR, loading: false });
      throw error;
    }
  }
}));