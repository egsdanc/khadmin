export type NotificationType = 'info' | 'success' | 'warning' | 'error';

export interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  timestamp: number;
  read: boolean;
}

export interface NotificationThresholds {
  balanceWarning: number;  // Bakiye uyarı eşiği
  balanceCritical: number; // Kritik bakiye eşiği
}