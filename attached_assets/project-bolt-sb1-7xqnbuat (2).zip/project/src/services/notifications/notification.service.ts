import { useNotificationStore } from './notification.store';
import { NotificationThresholds } from './notification.types';
import { Logger } from '../logger';

const THRESHOLDS: NotificationThresholds = {
  balanceWarning: 1000, // 1000 TL altında uyarı
  balanceCritical: 500, // 500 TL altında kritik uyarı
};

export class NotificationService {
  static checkBalanceThreshold(balance: number): void {
    if (balance <= THRESHOLDS.balanceCritical) {
      this.sendBalanceAlert('error', 'Kritik Bakiye Uyarısı', 
        `Bakiyeniz kritik seviyede (${balance} TL). Lütfen bakiye yükleyin.`);
    } else if (balance <= THRESHOLDS.balanceWarning) {
      this.sendBalanceAlert('warning', 'Bakiye Uyarısı', 
        `Bakiyeniz azalmakta (${balance} TL). Yakında yeni bakiye yüklemeniz gerekebilir.`);
    }
  }

  static sendBalanceAlert(type: 'warning' | 'error', title: string, message: string): void {
    useNotificationStore.getState().addNotification({
      type,
      title,
      message
    });

    Logger.warn('Balance notification sent', { type, title, message });
  }

  static sendSystemNotification(message: string): void {
    useNotificationStore.getState().addNotification({
      type: 'info',
      title: 'Sistem Bildirimi',
      message
    });

    Logger.info('System notification sent', { message });
  }

  static sendOperationNotification(title: string, message: string, type: 'success' | 'error'): void {
    useNotificationStore.getState().addNotification({
      type,
      title,
      message
    });

    Logger.info('Operation notification sent', { title, message, type });
  }
}