import { AxiosError, InternalAxiosRequestConfig } from 'axios';
import { TokenService } from '../auth/token.service';

export const requestInterceptor = (config: InternalAxiosRequestConfig) => {
  const token = TokenService.getToken();
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
};

export const requestErrorInterceptor = (error: AxiosError) => {
  console.error('Request Error:', error);
  return Promise.reject(error);
};