import { AxiosInstance } from 'axios';
import { requestInterceptor, requestErrorInterceptor } from './request.interceptor';
import { responseInterceptor, responseErrorInterceptor } from './response.interceptor';

export const setupInterceptors = (api: AxiosInstance): void => {
  api.interceptors.request.use(requestInterceptor, requestErrorInterceptor);
  api.interceptors.response.use(responseInterceptor, responseErrorInterceptor);
};