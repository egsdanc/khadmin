import { AxiosError, AxiosResponse } from 'axios';
import { ErrorService } from '../error/error.service';

export const responseInterceptor = (response: AxiosResponse) => {
  return response;
};

export const responseErrorInterceptor = async (error: AxiosError) => {
  const errorMessage = await ErrorService.handleApiError(error);
  return Promise.reject(errorMessage);
};