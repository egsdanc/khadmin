import { jsPDF } from 'jspdf';
import { formatCurrency } from '../../utils/format';
import { TestDetail } from '../../types/test.types';
import { PDF_CONFIG } from './pdf/constants';
import { drawHeader } from './pdf/sections/header';
import { drawVehicleInfo } from './pdf/sections/vehicle-info';
import { drawTestResults } from './pdf/sections/test-results';
import { drawFooter } from './pdf/sections/footer';
import { formatDate } from './pdf/utils/format';

export class TestPrintService {
  static generatePDF(test: TestDetail): void {
    const doc = new jsPDF(PDF_CONFIG.orientation, PDF_CONFIG.unit, PDF_CONFIG.format);
    const pageWidth = doc.internal.pageSize.width;
    const contentWidth = pageWidth - (PDF_CONFIG.margin * 2);
    
    // Set default font
    doc.setFont(PDF_CONFIG.font);
    
    // Draw header
    let currentY = drawHeader(doc, 'KILOMETRE HACKER', 'Test Raporu');
    
    // Draw date and location
    currentY += 15;
    doc.setFontSize(PDF_CONFIG.fontSize.normal);
    doc.text(`Tarih: ${formatDate(test.tarih)}`, PDF_CONFIG.margin, currentY);
    doc.text('Ankara / Yenimahalle', pageWidth - PDF_CONFIG.margin, currentY, { align: 'right' });
    
    // Draw vehicle info
    currentY += 10;
    currentY = drawVehicleInfo(doc, test, currentY);
    
    // Draw test results
    currentY += 15;
    currentY = drawTestResults(doc, test, currentY);
    
    // Draw test fee
    currentY += 15;
    doc.setFontSize(PDF_CONFIG.fontSize.normal);
    doc.setTextColor(...PDF_CONFIG.colors.text.primary);
    
    const testFeeLabel = 'Test Ucreti:';
    const testFeeValue = formatCurrency(test.ucret);
    
    const labelWidth = doc.getTextWidth(testFeeLabel);
    const valueWidth = doc.getTextWidth(testFeeValue);
    const totalWidth = labelWidth + 5 + valueWidth;
    
    const startX = pageWidth - PDF_CONFIG.margin - totalWidth;
    doc.text(testFeeLabel, startX, currentY);
    doc.text(testFeeValue, startX + labelWidth + 5, currentY);
    
    // Draw footer
    drawFooter(doc, contentWidth);
    
    // Save PDF
    const fileName = `kilometre-hacker-${test.plaka}-${new Date().toISOString().split('T')[0]}.pdf`;
    doc.save(fileName);
  }
}