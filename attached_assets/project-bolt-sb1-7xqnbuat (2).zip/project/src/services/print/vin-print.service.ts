import { jsPDF } from 'jspdf';
import { formatCurrency } from '../../utils/format';
import { PDF_CONFIG } from './pdf/constants';
import { drawHeader } from './pdf/sections/header';
import { drawFooter } from './pdf/sections/footer';
import { formatDate } from './pdf/utils/format';

export class VinPrintService {
  static generatePDF(vin: any): void {
    const doc = new jsPDF(PDF_CONFIG.orientation, PDF_CONFIG.unit, PDF_CONFIG.format);
    const pageWidth = doc.internal.pageSize.width;
    const contentWidth = pageWidth - (PDF_CONFIG.margin * 2);
    
    // Set default font
    doc.setFont(PDF_CONFIG.font);
    
    // Draw header
    let currentY = drawHeader(doc, 'VIN HACKER', 'Test Raporu');
    
    // Draw date and location
    currentY += 15;
    doc.setFontSize(PDF_CONFIG.fontSize.normal);
    doc.text(`Tarih: ${formatDate(vin.tarih)}`, PDF_CONFIG.margin, currentY);
    doc.text('Ankara / Yenimahalle', pageWidth - PDF_CONFIG.margin, currentY, { align: 'right' });
    
    // Draw vehicle info
    currentY += 20;
    doc.setFillColor(...PDF_CONFIG.colors.background.light);
    doc.rect(PDF_CONFIG.margin, currentY, contentWidth, 50, 'F');

    const vehicleInfo = [
      ['Plaka', vin.plaka],
      ['Sase No', vin.sase],
      ['Motor No', vin.motor],
      ['Paket', vin.paket],
      ['Kontrol Mod', vin.kontrolmod],
      ['Aciklama', vin.aciklama]
    ];

    let y = currentY + 10;
    const colWidth = contentWidth / 2;

    vehicleInfo.forEach(([label, value], index) => {
      const x = PDF_CONFIG.margin + 5 + (index % 2 * colWidth);
      if (index % 2 === 0 && index > 0) y += 10;
      
      doc.setFontSize(PDF_CONFIG.fontSize.small);
      doc.setTextColor(...PDF_CONFIG.colors.text.secondary);
      doc.text(label, x, y);
      
      doc.setFontSize(PDF_CONFIG.fontSize.normal);
      doc.setTextColor(...PDF_CONFIG.colors.text.primary);
      doc.text(value || '-', x, y + 5);
    });

    // Draw VIN details
    currentY += 70;
    doc.setFontSize(PDF_CONFIG.fontSize.normal);
    doc.setTextColor(...PDF_CONFIG.colors.text.primary);
    doc.setFont(PDF_CONFIG.font, 'bold');
    
    // Table headers
    doc.text('Modul', PDF_CONFIG.margin + 5, currentY);
    doc.text('VIN 1', PDF_CONFIG.margin + contentWidth/3, currentY);
    doc.text('VIN 2', PDF_CONFIG.margin + (contentWidth/3 * 2), currentY);

    // Table content
    doc.setFont(PDF_CONFIG.font, 'normal');
    currentY += 10;

    vin.details.forEach((detail: any, index: number) => {
      if (currentY > 250) {
        doc.addPage();
        currentY = 20;
      }

      if (index % 2 === 0) {
        doc.setFillColor(250, 250, 250);
        doc.rect(PDF_CONFIG.margin, currentY, contentWidth, 8, 'F');
      }

      doc.text(detail.moduleName, PDF_CONFIG.margin + 5, currentY + 5);
      doc.text(detail.value || '-', PDF_CONFIG.margin + contentWidth/3, currentY + 5);
      doc.text(detail.value2 || '-', PDF_CONFIG.margin + (contentWidth/3 * 2), currentY + 5);
      
      currentY += 8;
    });

    // Draw test fee
    currentY += 15;
    doc.setFontSize(PDF_CONFIG.fontSize.normal);
    doc.setTextColor(...PDF_CONFIG.colors.text.primary);
    
    const testFeeLabel = 'Test Ucreti:';
    const testFeeValue = formatCurrency(vin.ucret);
    
    const labelWidth = doc.getTextWidth(testFeeLabel);
    const valueWidth = doc.getTextWidth(testFeeValue);
    const totalWidth = labelWidth + 5 + valueWidth;
    
    const startX = pageWidth - PDF_CONFIG.margin - totalWidth;
    doc.text(testFeeLabel, startX, currentY);
    doc.text(testFeeValue, startX + labelWidth + 5, currentY);
    
    // Draw footer
    drawFooter(doc, contentWidth);
    
    // Save PDF
    const fileName = `vin-hacker-${vin.plaka}-${new Date().toISOString().split('T')[0]}.pdf`;
    doc.save(fileName);
  }
}