export const PDF_CONFIG = {
  format: 'a4',
  orientation: 'p',
  unit: 'mm',
  font: 'helvetica',
  margin: 20,
  fontSize: {
    title: 24,
    subtitle: 12,
    heading: 14,
    normal: 10,
    small: 9,
    footer: 8
  },
  colors: {
    text: {
      primary: [0, 0, 0],
      secondary: [100, 100, 100],
      muted: [120, 120, 120]
    },
    background: {
      light: [245, 245, 245]
    }
  }
} as const;