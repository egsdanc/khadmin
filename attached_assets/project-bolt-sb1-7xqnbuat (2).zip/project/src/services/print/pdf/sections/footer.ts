import { jsPDF } from 'jspdf';
import { PDF_CONFIG } from '../constants';

export function drawFooter(doc: jsPDF, contentWidth: number) {
  const pageWidth = doc.internal.pageSize.width;
  
  doc.setFontSize(PDF_CONFIG.fontSize.footer);
  doc.setTextColor(...PDF_CONFIG.colors.text.muted);

  const footerText = 'Kilometre verileri, aracin beyinlerinden ve sensörlerinden alinan anlik verilerdir. Detayli bilgi için e-Devlet veya TRAMER üzerinden sorgulama yapabilirsiniz.';

  const footerLines = doc.splitTextToSize(footerText, contentWidth);
  doc.text(footerLines, pageWidth/2, 285, { align: 'center' });
}