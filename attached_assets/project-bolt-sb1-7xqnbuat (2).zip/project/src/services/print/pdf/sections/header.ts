import { jsPDF } from 'jspdf';
import { PDF_CONFIG } from '../constants';

export function drawHeader(doc: jsPDF, title: string, subtitle: string): number {
  const pageWidth = doc.internal.pageSize.width;
  const startY = 40;
  
  doc.setFontSize(PDF_CONFIG.fontSize.title);
  doc.setTextColor(...PDF_CONFIG.colors.text.primary);
  doc.text(title, pageWidth / 2, startY, { align: 'center' });
  
  doc.setFontSize(PDF_CONFIG.fontSize.subtitle);
  doc.text(subtitle, pageWidth / 2, startY + 8, { align: 'center' });
  
  return startY + 16; // Return next Y position
}