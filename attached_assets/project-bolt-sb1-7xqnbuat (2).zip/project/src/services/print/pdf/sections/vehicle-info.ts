import { jsPDF } from 'jspdf';
import { PDF_CONFIG } from '../constants';
import { TestDetail } from '../../../../types/test.types';

export function drawVehicleInfo(doc: jsPDF, test: TestDetail, startY: number) {
  const pageWidth = doc.internal.pageSize.width;
  const contentWidth = pageWidth - (PDF_CONFIG.margin * 2);
  
  // Background
  doc.setFillColor(...PDF_CONFIG.colors.background.light);
  doc.rect(PDF_CONFIG.margin, startY, contentWidth, 50, 'F');

  // Vehicle details grid
  const vehicleInfo = [
    ['Plaka', test.plaka],
    ['Marka/Model', test.markaModel],
    ['Sase No', test.saseNo],
    ['Motor No', test.motorNo],
    ['Kontrol Mod', test.kontrolMod],
    ['Kilometre', test.km]
  ];

  let y = startY + 10;
  const colWidth = contentWidth / 2;

  vehicleInfo.forEach(([label, value], index) => {
    const x = PDF_CONFIG.margin + 5 + (index % 2 * colWidth);
    if (index % 2 === 0 && index > 0) y += 10;
    
    doc.setFontSize(PDF_CONFIG.fontSize.small);
    doc.setTextColor(...PDF_CONFIG.colors.text.secondary);
    doc.text(label, x, y);
    
    doc.setFontSize(PDF_CONFIG.fontSize.normal);
    doc.setTextColor(...PDF_CONFIG.colors.text.primary);
    doc.text(value, x, y + 5);
  });

  return startY + 50; // Return next Y position
}