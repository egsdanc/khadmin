import { jsPDF } from 'jspdf';
import { PDF_CONFIG } from '../constants';
import { TestDetail } from '../../../../types/test.types';

export function drawTestResults(doc: jsPDF, test: TestDetail, startY: number): number {
  const pageWidth = doc.internal.pageSize.width;
  const contentWidth = pageWidth - (PDF_CONFIG.margin * 2);
  let currentY = startY;

  // Table headers with bold font
  doc.setFontSize(PDF_CONFIG.fontSize.normal);
  doc.setTextColor(...PDF_CONFIG.colors.text.primary);
  doc.setFont(PDF_CONFIG.font, 'bold');
  doc.text('Modul', PDF_CONFIG.margin + 5, currentY + 5.5);
  doc.text('Kilometre', PDF_CONFIG.margin + contentWidth/2, currentY + 5.5);

  // Table content
  doc.setFont(PDF_CONFIG.font, 'normal');
  currentY += 8;

  test.details.forEach((detail, index) => {
    if (currentY > 250) {
      doc.addPage();
      currentY = 20;
    }

    // Add light gray background for alternate rows
    if (index % 2 === 0) {
      doc.setFillColor(250, 250, 250);
      doc.rect(PDF_CONFIG.margin, currentY, contentWidth, 8, 'F');
    }

    doc.text(detail.moduleName, PDF_CONFIG.margin + 5, currentY + 5.5);
    doc.text(detail.value, PDF_CONFIG.margin + contentWidth/2, currentY + 5.5);
    
    currentY += 8;
  });

  return currentY;
}