import { LoginCredentials, AuthResponse } from '../../types/auth';
import toast from 'react-hot-toast';

const MOCK_USER = {
  id: 1,
  ad: 'Admin',
  email: 'admin@example.com',
  firma: 0,
  role: 1,
  kullanici_id: 1
};

export class AuthService {
  static async login(credentials: LoginCredentials): Promise<AuthResponse> {
    // Mock login for development
    if (credentials.username === 'admin' && credentials.password === '1') {
      return {
        user: MOCK_USER,
        token: 'mock-token'
      };
    }
    
    toast.error('Giriş başarısız');
    throw new Error('Invalid credentials');
  }

  static async logout(): Promise<void> {
    localStorage.removeItem('auth-token');
  }

  static isAuthenticated(): boolean {
    return !!localStorage.getItem('auth-token');
  }
}