import { User } from '../../types/auth';

export interface AuthState {
  user: User | null;
  token: string | null;
  setAuth: (user: User, token: string) => void;
  logout: () => void;
  isSuperAdmin: () => boolean;
}

export interface TokenServiceInterface {
  getToken(): string | null;
  setToken(token: string): void;
  removeToken(): void;
  hasToken(): boolean;
}