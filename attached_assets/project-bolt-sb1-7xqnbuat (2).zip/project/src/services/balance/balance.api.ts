import { api } from '../api';
import { DealerBalance, BalanceTransaction } from '../../types/balance.types';
import { Logger } from '../logger';

export const balanceApi = {
  getBalance: async (dealerId: number): Promise<DealerBalance> => {
    try {
      const response = await api.get(`/balance/${dealerId}`);
      Logger.info('Balance API: Retrieved balance', {
        dealerId,
        balance: response.data.availableBalance
      });
      return response.data;
    } catch (error) {
      Logger.error('Balance API: Failed to get balance', {
        dealerId,
        error: error instanceof Error ? error.message : 'Unknown error'
      });
      throw new Error('Bayi bakiyesi alınamadı');
    }
  },

  deductBalance: async (dealerId: number, amount: number): Promise<BalanceTransaction> => {
    try {
      Logger.info('Balance API: Initiating balance deduction', {
        dealerId,
        amount
      });

      const response = await api.post('/balance/deduct', {
        dealerId,
        amount,
        type: 'DEDUCTION',
        description: 'Test ücreti kesintisi'
      });

      Logger.info('Balance API: Deduction successful', {
        dealerId,
        amount,
        transactionId: response.data.id
      });

      return response.data;
    } catch (error) {
      Logger.error('Balance API: Deduction failed', {
        dealerId,
        amount,
        error: error instanceof Error ? error.message : 'Unknown error'
      });
      throw new Error('Bakiye düşme işlemi başarısız');
    }
  },

  depositBalance: async (dealerId: number, amount: number): Promise<BalanceTransaction> => {
    try {
      Logger.info('Balance API: Initiating balance deposit', {
        dealerId,
        amount
      });

      const response = await api.post('/balance/deposit', {
        dealerId,
        amount,
        type: 'DEPOSIT',
        description: 'Bakiye yükleme'
      });

      Logger.info('Balance API: Deposit successful', {
        dealerId,
        amount,
        transactionId: response.data.id
      });

      return response.data;
    } catch (error) {
      Logger.error('Balance API: Deposit failed', {
        dealerId,
        amount,
        error: error instanceof Error ? error.message : 'Unknown error'
      });
      throw new Error('Bakiye yükleme işlemi başarısız');
    }
  },

  getTransactions: async (dealerId: number): Promise<BalanceTransaction[]> => {
    try {
      Logger.info('Balance API: Retrieving transactions', { dealerId });
      const response = await api.get(`/balance/${dealerId}/transactions`);
      
      Logger.info('Balance API: Retrieved transactions', {
        dealerId,
        transactionCount: response.data.length
      });

      return response.data;
    } catch (error) {
      Logger.error('Balance API: Failed to get transactions', {
        dealerId,
        error: error instanceof Error ? error.message : 'Unknown error'
      });
      throw new Error('İşlem geçmişi alınamadı');
    }
  }
};