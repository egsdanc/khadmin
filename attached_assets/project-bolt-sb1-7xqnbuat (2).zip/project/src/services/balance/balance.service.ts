import { BALANCE_CONFIG, BALANCE_MESSAGES } from '../../config/balance.config';
import { TestFeeCalculation, DealerBalance, BalanceTransaction } from '../../types/balance.types';
import { balanceApi } from './balance.api';
import { Logger } from '../logger';

export class BalanceService {
  static calculateTestFee(): TestFeeCalculation {
    const { TEST_FEE, SYSTEM_SHARE_RATE, KDV_RATE } = BALANCE_CONFIG;
    
    const systemShare = TEST_FEE * SYSTEM_SHARE_RATE;
    const kdv = systemShare * KDV_RATE;
    const totalDeduction = systemShare + kdv;
    const dealerBalance = TEST_FEE - totalDeduction;

    return {
      testFee: TEST_FEE,
      systemShare,
      kdv,
      totalDeduction,
      dealerBalance
    };
  }

  static async validateBalance(dealerId: number): Promise<boolean> {
    try {
      const balance = await this.getDealerBalance(dealerId);
      const calculation = this.calculateTestFee();
      
      Logger.info('Balance validation check', {
        dealerId,
        currentBalance: balance.availableBalance,
        requiredBalance: calculation.totalDeduction
      });

      return balance.availableBalance >= calculation.totalDeduction;
    } catch (error) {
      Logger.error('Balance validation failed', {
        dealerId,
        error: error instanceof Error ? error.message : 'Unknown error'
      });
      throw new Error(BALANCE_MESSAGES.BALANCE_FETCH_FAILED);
    }
  }

  static async deductFromBalance(dealerId: number): Promise<void> {
    try {
      const hasBalance = await this.validateBalance(dealerId);
      if (!hasBalance) {
        Logger.warn('Insufficient balance for deduction', { dealerId });
        throw new Error(BALANCE_MESSAGES.INSUFFICIENT_BALANCE);
      }

      const calculation = this.calculateTestFee();
      await balanceApi.deductBalance(dealerId, calculation.totalDeduction);
      
      Logger.info('Balance deduction successful', {
        dealerId,
        amount: calculation.totalDeduction,
        type: 'DEDUCTION'
      });
    } catch (error) {
      Logger.error('Balance deduction failed', {
        dealerId,
        error: error instanceof Error ? error.message : 'Unknown error'
      });
      throw new Error(BALANCE_MESSAGES.DEDUCTION_FAILED);
    }
  }

  static async getDealerBalance(dealerId: number): Promise<DealerBalance> {
    try {
      const balance = await balanceApi.getBalance(dealerId);
      Logger.info('Balance retrieved successfully', {
        dealerId,
        balance: balance.availableBalance
      });
      return balance;
    } catch (error) {
      Logger.error('Failed to retrieve dealer balance', {
        dealerId,
        error: error instanceof Error ? error.message : 'Unknown error'
      });
      throw new Error(BALANCE_MESSAGES.BALANCE_FETCH_FAILED);
    }
  }
}