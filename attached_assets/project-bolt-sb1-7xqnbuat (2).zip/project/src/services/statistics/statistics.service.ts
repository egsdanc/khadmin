import { api } from '../api';

const TEST_FEE = 500; // 500 TL per test
const COMPANY_SHARE_PERCENTAGE = 0.90; // 90%
const ADMIN_SHARE_PERCENTAGE = 0.02; // 2%
const KDV_RATE = 0.20; // 20% KDV

export interface CompanyRevenue {
  id: number;
  name: string;
  totalTests: number;
  revenue: number; // 90% of test fee
  adminShare: number; // 2% + KDV
}

export interface TestStatistics {
  daily: {
    kilometerTests: number;
    vinTests: number;
    totalTests: number;
  };
  monthly: {
    kilometerTests: number;
    vinTests: number;
    totalTests: number;
    totalRevenue: number;
    companies: CompanyRevenue[];
    adminTotalRevenue: number;
  };
}

export class StatisticsService {
  static calculateCompanyRevenue(totalTests: number): number {
    return totalTests * TEST_FEE * COMPANY_SHARE_PERCENTAGE;
  }

  static calculateAdminShare(totalTests: number): number {
    const baseShare = totalTests * TEST_FEE * ADMIN_SHARE_PERCENTAGE;
    const kdv = baseShare * KDV_RATE;
    return baseShare + kdv;
  }

  static async getTestStatistics(): Promise<TestStatistics> {
    try {
      const response = await api.get('/statistics/tests');
      return response.data;
    } catch (error) {
      // Mock data for development
      const mockData = {
        daily: {
          kilometerTests: 25,
          vinTests: 18,
          totalTests: 43
        },
        monthly: {
          kilometerTests: 750,
          vinTests: 520,
          totalTests: 1270,
          totalRevenue: 1270 * TEST_FEE, // Total revenue from all tests
          companies: [
            {
              id: 1,
              name: 'Garantili Arabam',
              totalTests: 450,
              revenue: this.calculateCompanyRevenue(450),
              adminShare: this.calculateAdminShare(450)
            },
            {
              id: 2,
              name: 'General Oto Ekspertiz',
              totalTests: 420,
              revenue: this.calculateCompanyRevenue(420),
              adminShare: this.calculateAdminShare(420)
            },
            {
              id: 3,
              name: 'Dynobil Ekspertiz',
              totalTests: 400,
              revenue: this.calculateCompanyRevenue(400),
              adminShare: this.calculateAdminShare(400)
            }
          ],
          adminTotalRevenue: 0 // Will be calculated below
        }
      };

      // Calculate total admin revenue
      mockData.monthly.adminTotalRevenue = mockData.monthly.companies.reduce(
        (total, company) => total + company.adminShare,
        0
      );

      return mockData;
    }
  }
}