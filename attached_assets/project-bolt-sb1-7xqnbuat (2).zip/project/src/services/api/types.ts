import { AxiosError, AxiosResponse, InternalAxiosRequestConfig } from 'axios';

export interface ApiInterceptors {
  request: (config: InternalAxiosRequestConfig) => InternalAxiosRequestConfig | Promise<InternalAxiosRequestConfig>;
  requestError: (error: AxiosError) => Promise<never>;
  response: (response: AxiosResponse) => AxiosResponse;
  responseError: (error: AxiosError) => Promise<never>;
}

export interface ApiServiceConfig {
  baseURL: string;
  timeout: number;
  headers: Record<string, string>;
}