import { AxiosError } from 'axios';
import { API_MESSAGES } from '../../config/messages.config';

export class ErrorService {
  static handleApiError(error: AxiosError): string {
    if (!error.response) {
      return API_MESSAGES.NETWORK_ERROR;
    }

    switch (error.response.status) {
      case 401:
        return API_MESSAGES.SESSION_EXPIRED;
      case 404:
        return 'İstek yapılan kaynak bulunamadı';
      case 500:
        return 'Sunucu hatası oluştu';
      default:
        return error.response.data?.message || API_MESSAGES.GENERIC_ERROR;
    }
  }
}