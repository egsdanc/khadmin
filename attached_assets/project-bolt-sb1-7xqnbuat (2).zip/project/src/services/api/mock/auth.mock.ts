import { AuthResponse, LoginCredentials, UserRoles } from '../../../types/auth';

const MOCK_CREDENTIALS = {
  username: 'admin',
  password: '1'
};

const MOCK_USER = {
  id: 1,
  ad: 'Super Admin',
  email: 'admin@example.com',
  firma: 0,
  role: UserRoles.SUPER_ADMIN,
  kullanici_id: 1
};

export const mockAuthApi = {
  login: async (credentials: LoginCredentials): Promise<AuthResponse> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));

    if (
      credentials.username === MOCK_CREDENTIALS.username && 
      credentials.password === MOCK_CREDENTIALS.password
    ) {
      return {
        user: MOCK_USER,
        token: 'mock-jwt-token'
      };
    }

    throw new Error('Invalid credentials');
  }
};