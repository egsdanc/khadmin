export interface HealthCheckResponse {
  status: 'healthy' | 'unhealthy';
  database: boolean;
  message: string;
}

export interface HealthCheckOptions {
  timeout?: number;
  retryAttempts?: number;
  retryDelay?: number;
}

export interface HealthStatus {
  isHealthy: boolean;
  message: string;
  database: boolean;
  lastCheck: Date;
}