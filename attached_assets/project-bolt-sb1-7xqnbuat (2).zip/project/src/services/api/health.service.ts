import api from '../api.client';
import { API_CONFIG } from '../../config/api.config';

export class HealthService {
  private static isChecking = false;
  private static healthCheckInterval: NodeJS.Timeout | null = null;

  static async checkApiHealth(): Promise<boolean> {
    if (this.isChecking) return false;
    
    try {
      this.isChecking = true;
      await api.get('/health');
      return true;
    } catch (error) {
      return false;
    } finally {
      this.isChecking = false;
    }
  }

  static startHealthCheck(callback: (isHealthy: boolean) => void): void {
    if (this.healthCheckInterval) return;

    this.healthCheckInterval = setInterval(async () => {
      const isHealthy = await this.checkApiHealth();
      callback(isHealthy);
    }, 30000); // Her 30 saniyede bir kontrol et
  }

  static stopHealthCheck(): void {
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
      this.healthCheckInterval = null;
    }
  }

  static getApiUrl(): string {
    return API_CONFIG.baseURL;
  }
}