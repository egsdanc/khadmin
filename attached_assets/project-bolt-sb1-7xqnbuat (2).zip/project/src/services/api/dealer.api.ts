import { Dealer, DealerFormData } from '../../types/dealer.types';

// Mock dealer data
const mockDealers: Dealer[] = [
  {
    id: 1,
    ad: 'Ankara / Yenimahalle',
    firma: 1, // Garantili Arabam
    aktif: true,
    created_at: '2024-01-15T10:00:00',
    updated_at: '2024-01-15T10:00:00',
    il: 'Ankara',
    ilce: 'Yenimahalle',
    adres: 'İstanbul Caddesi No:123',
    sabit_ip: '192.168.1.100',
    yuzde_oran: 10,
    tel: '0312 123 45 67',
    mail: 'yenimahalle@garantiliarabam.com'
  },
  {
    id: 2,
    ad: 'İstanbul / Kadıköy',
    firma: 1, // Garantili Arabam
    aktif: true,
    created_at: '2024-01-10T15:30:00',
    updated_at: '2024-01-10T15:30:00',
    il: 'İstanbul',
    ilce: 'Kadıköy',
    adres: 'Bağdat Caddesi No:45',
    sabit_ip: '192.168.1.101',
    yuzde_oran: 10,
    tel: '0216 987 65 43',
    mail: 'kadikoy@garantiliarabam.com'
  },
  {
    id: 3,
    ad: 'İzmir / Karşıyaka',
    firma: 2, // General Oto Ekspertiz
    aktif: true,
    created_at: '2024-01-05T09:15:00',
    updated_at: '2024-01-05T09:15:00',
    il: 'İzmir',
    ilce: 'Karşıyaka',
    adres: 'Girne Bulvarı No:78',
    sabit_ip: null,
    yuzde_oran: 10,
    tel: '0232 345 67 89',
    mail: 'karsiyaka@generaloto.com'
  },
  {
    id: 4,
    ad: 'Bursa / Nilüfer',
    firma: 3, // Dynobil
    aktif: false,
    created_at: '2024-01-03T14:20:00',
    updated_at: '2024-01-03T14:20:00',
    il: 'Bursa',
    ilce: 'Nilüfer',
    adres: 'FSM Bulvarı No:55',
    sabit_ip: '192.168.1.103',
    yuzde_oran: 10,
    tel: '0224 789 12 34',
    mail: 'nilufer@dynobil.com'
  }
];

// Firma listesi
const companies = {
  1: 'Garantili Arabam',
  2: 'General Oto Ekspertiz',
  3: 'Dynobil'
};

export const dealerApi = {
  async getAllDealers(): Promise<Dealer[]> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    return mockDealers;
  },

  async createDealer(dealer: DealerFormData): Promise<Dealer> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const newDealer: Dealer = {
      id: mockDealers.length + 1,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      ...dealer
    };

    mockDealers.push(newDealer);
    return newDealer;
  },

  getCompanyName(firmaId: number): string {
    return companies[firmaId as keyof typeof companies] || 'Bilinmeyen Firma';
  },

  async checkHealth(): Promise<boolean> {
    return true;
  }
};