import axios from 'axios';
import { API_CONFIG } from '../../config/api/config';
import { setupInterceptors } from '../interceptors';

const api = axios.create({
  ...API_CONFIG,
  withCredentials: false
});

setupInterceptors(api);

export default api;