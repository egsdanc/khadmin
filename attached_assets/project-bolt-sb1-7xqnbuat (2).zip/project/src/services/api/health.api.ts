// Mock sağlık kontrolü servisi
export interface HealthCheckResponse {
  status: 'healthy' | 'unhealthy';
  database: boolean;
  message: string;
}

class HealthApi {
  check(): HealthCheckResponse {
    return {
      status: 'healthy',
      database: true,
      message: 'Sistem çalışıyor'
    };
  }

  startHealthCheck(callback: (status: HealthCheckResponse) => void): void {
    callback(this.check());
  }

  stopHealthCheck(): void {
    // Mock cleanup
  }
}

export const healthApi = new HealthApi();