import { useState, useEffect, useCallback } from 'react';
import { healthService } from '../health.service';
import type { HealthStatus } from '../types';

export function useHealthCheck() {
  const [status, setStatus] = useState<HealthStatus | null>(null);

  const handleStatusUpdate = useCallback((newStatus: HealthStatus) => {
    setStatus(newStatus);
  }, []);

  useEffect(() => {
    healthService.startMonitoring(handleStatusUpdate);
    return () => {
      healthService.stopMonitoring();
    };
  }, [handleStatusUpdate]);

  return status;
}