export interface HealthStatus {
  isHealthy: boolean;
  message: string;
  database: boolean;
  timestamp: number;
}

export interface HealthCheckResponse {
  status: 'healthy' | 'unhealthy';
  database: boolean;
  message: string;
}