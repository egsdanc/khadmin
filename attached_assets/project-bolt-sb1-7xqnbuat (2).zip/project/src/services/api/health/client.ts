import axios from 'axios';
import { API_CONFIG } from '../../../config/api.config';
import { HEALTH_CHECK_CONFIG } from './constants';

export const healthClient = axios.create({
  baseURL: API_CONFIG.baseURL,
  timeout: HEALTH_CHECK_CONFIG.timeout,
  headers: {
    ...API_CONFIG.headers,
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache'
  }
});