import { healthClient } from './client';
import { HEALTH_CHECK_CONFIG } from './constants';
import type { HealthStatus, HealthCheckResponse } from './types';

class HealthService {
  private checkInterval: number | null = null;
  private lastStatus: HealthStatus | null = null;
  private isChecking = false;

  private async check(): Promise<HealthStatus> {
    if (this.isChecking) {
      return this.getDefaultStatus();
    }

    try {
      this.isChecking = true;
      const response = await healthClient.get<HealthCheckResponse>('/health');
      return this.createStatus(response.data);
    } catch (error) {
      return this.createErrorStatus();
    } finally {
      this.isChecking = false;
    }
  }

  private getDefaultStatus(): HealthStatus {
    return this.lastStatus || {
      isHealthy: false,
      database: false,
      message: HEALTH_CHECK_CONFIG.messages.checking,
      timestamp: Date.now()
    };
  }

  private createStatus(data: HealthCheckResponse): HealthStatus {
    return {
      isHealthy: data.status === 'healthy',
      database: data.database,
      message: data.message,
      timestamp: Date.now()
    };
  }

  private createErrorStatus(): HealthStatus {
    return {
      isHealthy: false,
      database: false,
      message: HEALTH_CHECK_CONFIG.messages.unhealthy,
      timestamp: Date.now()
    };
  }

  public async startMonitoring(callback: (status: HealthStatus) => void): Promise<void> {
    if (this.checkInterval) {
      this.stopMonitoring();
    }

    const status = await this.check();
    callback(status);

    this.checkInterval = window.setInterval(async () => {
      const newStatus = await this.check();
      callback(newStatus);
    }, HEALTH_CHECK_CONFIG.interval);
  }

  public stopMonitoring(): void {
    if (this.checkInterval) {
      window.clearInterval(this.checkInterval);
      this.checkInterval = null;
    }
  }
}

export const healthService = new HealthService();