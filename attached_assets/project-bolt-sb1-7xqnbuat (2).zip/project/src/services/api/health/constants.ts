export const HEALTH_CHECK_CONFIG = {
  interval: 30000, // 30 saniye
  timeout: 5000,   // 5 saniye
  messages: {
    healthy: 'Sistem çalışıyor',
    unhealthy: 'Sunucuya erişilemiyor',
    checking: 'Sistem kontrol ediliyor'
  }
} as const;