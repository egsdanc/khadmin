import { LoginCredentials, AuthResponse } from '../../types/auth';
import { ENDPOINTS } from '../../config/api/endpoints';
import api from './base.api';

export const AuthApi = {
  login: async (credentials: LoginCredentials): Promise<AuthResponse> => {
    const response = await api.post<AuthResponse>(ENDPOINTS.AUTH.LOGIN, credentials);
    return response.data;
  },

  logout: async (): Promise<void> => {
    await api.post(ENDPOINTS.AUTH.LOGOUT);
  },

  refreshToken: async (): Promise<AuthResponse> => {
    const response = await api.post<AuthResponse>(ENDPOINTS.AUTH.REFRESH);
    return response.data;
  }
};