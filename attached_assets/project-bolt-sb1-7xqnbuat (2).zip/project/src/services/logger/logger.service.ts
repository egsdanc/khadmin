import winston from 'winston';
import { LOG_CONFIG } from './logger.config';

const { combine, timestamp, printf, colorize } = winston.format;

// Log formatı
const logFormat = printf(({ level, message, timestamp, ...metadata }) => {
  let msg = `${timestamp} [${level}]: ${message}`;
  
  if (Object.keys(metadata).length > 0) {
    msg += ` ${JSON.stringify(metadata)}`;
  }
  
  return msg;
});

// Logger instance'ı oluştur
const logger = winston.createLogger({
  levels: LOG_CONFIG.levels,
  format: combine(
    timestamp({ format: LOG_CONFIG.dateFormat }),
    logFormat
  ),
  transports: [
    // Konsol transport'u
    new winston.transports.Console({
      format: combine(
        colorize(),
        logFormat
      ),
    }),
    // Dosya transport'u - error seviyesi
    new winston.transports.File({ 
      filename: 'logs/error.log',
      level: 'error',
    }),
    // Dosya transport'u - tüm loglar
    new winston.transports.File({ 
      filename: 'logs/combined.log' 
    }),
  ],
});

// Development ortamında renkli konsolda göster
if (process.env.NODE_ENV !== 'production') {
  winston.addColors(LOG_CONFIG.colors);
}

export const Logger = {
  error: (message: string, meta?: any) => {
    logger.error(message, meta);
  },

  warn: (message: string, meta?: any) => {
    logger.warn(message, meta);
  },

  info: (message: string, meta?: any) => {
    logger.info(message, meta);
  },

  http: (message: string, meta?: any) => {
    logger.http(message, meta);
  },

  debug: (message: string, meta?: any) => {
    logger.debug(message, meta);
  },
};