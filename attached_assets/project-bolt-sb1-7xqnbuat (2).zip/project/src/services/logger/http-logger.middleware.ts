import { Logger } from './logger.service';

export function httpLogger(req: any, res: any, next: () => void) {
  const start = Date.now();
  
  res.on('finish', () => {
    const duration = Date.now() - start;
    
    Logger.http(`${req.method} ${req.url}`, {
      method: req.method,
      url: req.url,
      status: res.statusCode,
      duration: `${duration}ms`,
      userAgent: req.get('user-agent'),
      ip: req.ip
    });
  });

  next();
}