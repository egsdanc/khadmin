import { Logger } from './logger.service';

export function errorLogger(error: any, req: any, res: any, next: () => void) {
  Logger.error('Application Error', {
    error: error.message,
    stack: error.stack,
    url: req.url,
    method: req.method,
    body: req.body
  });
  
  next(error);
}