import { api } from '../api';
import { ENDPOINTS } from '../../config/api/endpoints';
import type { TestReport, DealerReport, RevenueReport, ReportFilters } from '../../types/reports.types';

const TEST_FEE = 500; // Test ücreti
const DEALER_SHARE = 0.90; // Bayi payı %90
const SYSTEM_SHARE = 0.10; // Sistem payı %10
const KDV_RATE = 0.20; // KDV %20

export class ReportsService {
  static async getTestReports(filters: ReportFilters): Promise<TestReport[]> {
    try {
      const response = await api.get(`${ENDPOINTS.REPORTS}/tests`, { params: filters });
      return response.data;
    } catch (error) {
      // Mock veri dönelim
      return [];
    }
  }

  static async getDealerReports(filters: ReportFilters): Promise<DealerReport[]> {
    try {
      const response = await api.get(`${ENDPOINTS.REPORTS}/dealers`, { params: filters });
      return response.data;
    } catch (error) {
      // Mock veri dönelim
      return [];
    }
  }

  static async getRevenueReport(filters: ReportFilters): Promise<RevenueReport> {
    try {
      const response = await api.get(`${ENDPOINTS.REPORTS}/revenue`, { params: filters });
      return response.data;
    } catch (error) {
      // Mock veri dönelim
      const mockCompanies = [
        {
          id: 1,
          name: 'Garantili Arabam',
          totalTests: 450,
          revenue: 450 * TEST_FEE * DEALER_SHARE,
          systemShare: 450 * TEST_FEE * SYSTEM_SHARE,
          kdvAmount: 450 * TEST_FEE * SYSTEM_SHARE * KDV_RATE
        },
        {
          id: 2,
          name: 'General Oto Ekspertiz',
          totalTests: 420,
          revenue: 420 * TEST_FEE * DEALER_SHARE,
          systemShare: 420 * TEST_FEE * SYSTEM_SHARE,
          kdvAmount: 420 * TEST_FEE * SYSTEM_SHARE * KDV_RATE
        },
        {
          id: 3,
          name: 'Dynobil',
          totalTests: 400,
          revenue: 400 * TEST_FEE * DEALER_SHARE,
          systemShare: 400 * TEST_FEE * SYSTEM_SHARE,
          kdvAmount: 400 * TEST_FEE * SYSTEM_SHARE * KDV_RATE
        }
      ];

      const totalTests = mockCompanies.reduce((sum, company) => sum + company.totalTests, 0);
      const totalRevenue = totalTests * TEST_FEE;
      const totalSystemShare = mockCompanies.reduce((sum, company) => sum + company.systemShare, 0);
      const totalKdv = mockCompanies.reduce((sum, company) => sum + company.kdvAmount, 0);

      return {
        totalRevenue,
        dealerShare: totalRevenue * DEALER_SHARE,
        systemShare: totalSystemShare,
        kdvAmount: totalKdv,
        netRevenue: totalRevenue - totalKdv,
        periodStart: '2024-03-01',
        periodEnd: '2024-03-31',
        companies: mockCompanies
      };
    }
  }

  static async exportToExcel(reportType: string, filters: ReportFilters): Promise<Blob> {
    const response = await api.get(`${ENDPOINTS.REPORTS}/export/${reportType}`, {
      params: filters,
      responseType: 'blob'
    });
    return response.data;
  }
}