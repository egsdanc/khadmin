import { AuthApi } from './api/auth.api';
import { healthApi } from './api/health.api';
import api from './api/base.api';

export { AuthApi, healthApi, api };