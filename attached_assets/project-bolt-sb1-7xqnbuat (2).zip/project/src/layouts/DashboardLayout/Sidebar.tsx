import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  BarChart3,
  Users, 
  Building2,
  Store, 
  FileSpreadsheet,
  Settings,
  CarFront,
  Gauge,
  Shield,
  UserCog,
  Wallet,
  FileText
} from 'lucide-react';
import { useAuthStore } from '../../store/auth.store';
import { cn } from '../../utils/cn';

const navigation = [
  { name: 'Panel', href: '/dashboard', icon: BarChart3 },
  { 
    name: 'Firmalar', 
    href: '/dashboard/firmalar', 
    icon: Building2,
    role: 1
  },
  { name: 'Bayiler', href: '/dashboard/bayiler', icon: Store },
  {
    name: 'Roller',
    href: '/dashboard/roller',
    icon: Shield,
    role: 1
  },
  { 
    name: 'Panel Kullanıcıları', 
    href: '/dashboard/kullanicilar', 
    icon: Users 
  },
  { 
    name: 'Program Kullanıcıları', 
    href: '/dashboard/program-kullanicilar', 
    icon: UserCog 
  },
  {
    name: 'Bakiye Yönetimi',
    href: '/dashboard/bakiye',
    icon: Wallet
  },
  {
    name: 'Testler',
    href: '/dashboard/testler',
    icon: FileSpreadsheet,
    subItems: [
      {
        name: 'Kilometre Hacker',
        href: '/dashboard/testler',
        icon: Gauge
      },
      {
        name: 'VIN Hacker',
        href: '/dashboard/testler/vin-reader',
        icon: CarFront
      }
    ]
  },
  {
    name: 'Raporlar',
    href: '/dashboard/raporlar',
    icon: FileText
  },
  { name: 'Ayarlar', href: '/dashboard/ayarlar', icon: Settings }
];

export function Sidebar() {
  const isSuperAdmin = useAuthStore(state => state.isSuperAdmin);

  const filteredNavigation = navigation.filter(item => 
    !item.role || (item.role === 1 && isSuperAdmin())
  );

  return (
    <div className="flex grow flex-col gap-y-5 overflow-y-auto border-r border-gray-200 bg-white px-6 pb-4">
      <div className="flex h-16 shrink-0 items-center">
        <Shield className="h-8 w-8 text-indigo-600" />
      </div>
      <nav className="flex flex-1 flex-col">
        <ul role="list" className="flex flex-1 flex-col gap-y-7">
          <li>
            <ul role="list" className="-mx-2 space-y-1">
              {filteredNavigation.map((item) => (
                <li key={item.name}>
                  <NavLink
                    to={item.href}
                    end={!item.subItems}
                    className={({ isActive }) =>
                      cn(
                        'group flex gap-x-3 rounded-md p-2 text-sm leading-6 font-semibold',
                        isActive
                          ? 'bg-gray-50 text-indigo-600'
                          : 'text-gray-700 hover:text-indigo-600 hover:bg-gray-50'
                      )
                    }
                  >
                    <item.icon className="h-6 w-6 shrink-0" aria-hidden="true" />
                    {item.name}
                  </NavLink>

                  {item.subItems && (
                    <ul role="list" className="mt-1 px-2">
                      {item.subItems.map((subItem) => (
                        <li key={subItem.name}>
                          <NavLink
                            to={subItem.href}
                            className={({ isActive }) =>
                              cn(
                                'group flex gap-x-3 rounded-md p-2 text-sm leading-6 font-medium',
                                isActive
                                  ? 'bg-gray-50 text-indigo-600'
                                  : 'text-gray-700 hover:text-indigo-600 hover:bg-gray-50'
                              )
                            }
                          >
                            <subItem.icon className="h-6 w-6 shrink-0" aria-hidden="true" />
                            {subItem.name}
                          </NavLink>
                        </li>
                      ))}
                    </ul>
                  )}
                </li>
              ))}
            </ul>
          </li>
        </ul>
      </nav>
    </div>
  );
}