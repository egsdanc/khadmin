import React from 'react';
import { X } from 'lucide-react';
import { Sidebar } from './Sidebar';

interface MobileSidebarProps {
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}

export function MobileSidebar({ sidebarOpen, setSidebarOpen }: MobileSidebarProps) {
  if (!sidebarOpen) return null;

  return (
    <div className="relative z-40 lg:hidden">
      <div className="fixed inset-0 bg-gray-600 bg-opacity-75" />

      <div className="fixed inset-0 z-40 flex">
        <div className="relative flex w-full max-w-xs flex-1 flex-col bg-white pt-5 pb-4">
          <div className="absolute top-0 right-0 -mr-12 pt-2">
            <button
              type="button"
              className="ml-1 flex h-10 w-10 items-center justify-center rounded-full focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
              onClick={() => setSidebarOpen(false)}
            >
              <span className="sr-only">Close sidebar</span>
              <X className="h-6 w-6 text-white" />
            </button>
          </div>
          <Sidebar />
        </div>
        <div className="w-14 flex-shrink-0" aria-hidden="true" />
      </div>
    </div>
  );
}