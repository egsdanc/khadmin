export const AUTH_CONSTANTS = {
  STORAGE_KEY: 'auth-storage',
  TOKEN_KEY: 'auth-token',
  MOCK_USER: {
    username: 'admin',
    password: '1'
  }
} as const;

export const AUTH_MESSAGES = {
  VALIDATION: {
    USERNAME_REQUIRED: 'Kullanıcı adı zorunludur',
    PASSWORD_REQUIRED: 'Şifre zorunludur',
    PASSWORD_MIN_LENGTH: 'Şifre en az 1 karakter olmalıdır'
  }
} as const;