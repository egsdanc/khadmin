export interface ProgramKullanici {
  id: number;
  isim: string;
  sifre: string;
  macAddress: string;
  firstLogin: boolean;
  firma: number;
  bayi?: number;
}

export interface ProgramKullaniciFormData {
  isim: string;
  sifre: string;
  macAddress: string;
  firstLogin: string;
  firma: string;
  bayi?: string;
}

export interface ProgramKullaniciFilters {
  search: string;
  firstLogin: string;
  firma?: string;
  bayi?: string;
}