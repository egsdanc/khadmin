export interface User {
  id: number;
  ad: string;
  email: string;
  image?: string;
  firma: number;
  role: number;
  kullanici_id: number;
  bayi?: number;
}

export interface LoginCredentials {
  username: string;
  password: string;
}

export interface AuthResponse {
  user: User;
  token: string;
}

export const UserRoles = {
  SUPER_ADMIN: 1,
  ADMIN: 2,
  USER: 3,
} as const;