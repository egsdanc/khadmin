export interface CompanyRevenue {
  id: number;
  name: string;
  totalTests: number;
  revenue: number;
  systemShare: number;
  kdvAmount: number;
}

export interface RevenueReport {
  totalRevenue: number;
  dealerShare: number;
  systemShare: number;
  kdvAmount: number;
  netRevenue: number;
  periodStart: string;
  periodEnd: string;
  companies: CompanyRevenue[];
}