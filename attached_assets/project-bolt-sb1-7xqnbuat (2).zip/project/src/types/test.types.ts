export interface TestDetail {
  id: number;
  plaka: string;
  markaModel: string;
  saseNo: string;
  motorNo: string;
  kontrolMod: string;
  km: string;
  ucret: number;
  tarih: string;
  details: Array<{
    id: number;
    moduleName: string;
    value: string;
    time: string;
  }>;
}