export interface TestFeeCalculation {
  testFee: number;        // Test ücreti
  systemShare: number;    // Sistem payı
  kdv: number;           // KDV
  totalDeduction: number; // Toplam kesinti
  dealerBalance: number;  // Bayiye kalan
}

export interface DealerBalance {
  dealerId: number;
  currentBalance: number;
  availableBalance: number;
}

export interface BalanceTransaction {
  id: number;
  dealerId: number;
  amount: number;
  type: 'DEDUCTION' | 'DEPOSIT';
  description: string;
  createdAt: string;
}