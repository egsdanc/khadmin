export interface Dealer {
  id: number;
  ad: string;
  firma: number;
  aktif: boolean;
  created_at: string;
  updated_at: string;
  il: string;
  ilce: string;
  adres: string;
  sabit_ip: string | null;
  yuzde_oran: number;
  tel: string;
  mail: string;
}

export interface DealerFormData extends Omit<Dealer, 'id' | 'created_at' | 'updated_at'> {}

export interface DealerRow extends Dealer {}