import { TEST_FEE } from '../config/constants';

export interface CompanyRevenue {
  name: string;
  totalTests: number;
  revenue: number;
  systemShare: number;
  kdvAmount: number;
  superAdminShare: number;
  superAdminKdv: number;
}

export function calculateRevenue(totalTests: number): CompanyRevenue {
  const testFee = TEST_FEE; // 500 TL
  const totalRevenue = totalTests * testFee;
  
  // Bayi geliri hesaplama (%90)
  const dealerShare = totalRevenue * 0.90;
  
  // Firma payı hesaplama (%10)
  const companyShare = totalRevenue * 0.10;
  const companyKdv = companyShare * 0.20; // Firma KDV'si
  
  // Super Admin (Emre Söken) payı hesaplama (%2)
  const superAdminShare = totalRevenue * 0.02;
  const superAdminKdv = superAdminShare * 0.20; // Super Admin KDV'si
  
  return {
    totalTests,
    revenue: dealerShare, // Bayi geliri
    systemShare: companyShare + superAdminShare, // Toplam sistem payı
    kdvAmount: companyKdv + superAdminKdv, // Toplam KDV
    superAdminShare,
    superAdminKdv
  };
}

export function calculateTotalRevenues(companies: Array<{ name: string; totalTests: number }>) {
  return companies.map(company => ({
    name: company.name,
    ...calculateRevenue(company.totalTests)
  }));
}