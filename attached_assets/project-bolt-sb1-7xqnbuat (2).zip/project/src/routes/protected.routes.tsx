import { RouteProps } from 'react-router-dom';
import { ProtectedRoute } from '../components/auth/ProtectedRoute';
import { DashboardLayout } from '../layouts/DashboardLayout';
import { DashboardPage } from '../pages/dashboard/DashboardPage';
import { FirmaListPage } from '../pages/dashboard/firma/FirmaListPage';
import { BayiListPage } from '../pages/dashboard/bayi/BayiListPage';
import { KullaniciListPage } from '../pages/dashboard/kullanici/KullaniciListPage';
import { TestListPage } from '../pages/dashboard/test/TestListPage';
import { VinReaderPage } from '../pages/dashboard/test/VinReaderPage';
import { AyarlarPage } from '../pages/dashboard/ayarlar/AyarlarPage';

export const protectedRoutes: RouteProps[] = [
  {
    path: '/dashboard',
    element: (
      <ProtectedRoute>
        <DashboardLayout />
      </ProtectedRoute>
    ),
    children: [
      {
        path: '',
        element: <DashboardPage />
      },
      {
        path: 'firmalar',
        element: <FirmaListPage />
      },
      {
        path: 'bayiler',
        element: <BayiListPage />
      },
      {
        path: 'kullanicilar',
        element: <KullaniciListPage />
      },
      {
        path: 'testler',
        element: <TestListPage />
      },
      {
        path: 'testler/vin-reader',
        element: <VinReaderPage />
      },
      {
        path: 'ayarlar',
        element: <AyarlarPage />
      }
    ]
  }
];