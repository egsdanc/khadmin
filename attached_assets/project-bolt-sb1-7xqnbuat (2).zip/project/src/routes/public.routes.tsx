import { RouteProps } from 'react-router-dom';
import { LoginPage } from '../pages/auth/LoginPage';

export const publicRoutes: RouteProps[] = [
  {
    path: '/',
    element: <LoginPage />
  },
  {
    path: '/login',
    element: <LoginPage />
  }
];