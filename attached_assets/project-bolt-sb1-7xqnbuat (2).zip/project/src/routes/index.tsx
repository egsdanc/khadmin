import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { LoginPage } from '../pages/auth/LoginPage';
import { DashboardLayout } from '../layouts/DashboardLayout';
import { DashboardPage } from '../pages/dashboard/DashboardPage';
import { FirmaListPage } from '../pages/dashboard/firma/FirmaListPage';
import { BayiListPage } from '../pages/dashboard/bayi/BayiListPage';
import { RolListPage } from '../pages/dashboard/rol/RolListPage';
import { KullaniciListPage } from '../pages/dashboard/kullanici/KullaniciListPage';
import { ProgramKullaniciPage } from '../pages/dashboard/program-kullanici/ProgramKullaniciPage';
import { BalanceManagementPage } from '../pages/dashboard/balance/BalanceManagementPage';
import { TestListPage } from '../pages/dashboard/test/TestListPage';
import { VinReaderPage } from '../pages/dashboard/test/VinReaderPage';
import { AyarlarPage } from '../pages/dashboard/ayarlar/AyarlarPage';
import { ProfilPage } from '../pages/dashboard/profil/ProfilPage';
import { ReportsPage } from '../pages/dashboard/reports/ReportsPage';
import { ProtectedRoute } from '../components/auth/ProtectedRoute';

export function AppRouter() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="/login" element={<LoginPage />} />
        
        <Route path="/dashboard" element={
          <ProtectedRoute>
            <DashboardLayout />
          </ProtectedRoute>
        }>
          <Route index element={<DashboardPage />} />
          <Route path="firmalar" element={<FirmaListPage />} />
          <Route path="bayiler" element={<BayiListPage />} />
          <Route path="roller" element={<RolListPage />} />
          <Route path="kullanicilar" element={<KullaniciListPage />} />
          <Route path="program-kullanicilar" element={<ProgramKullaniciPage />} />
          <Route path="bakiye" element={<BalanceManagementPage />} />
          <Route path="testler" element={<TestListPage />} />
          <Route path="testler/vin-reader" element={<VinReaderPage />} />
          <Route path="raporlar" element={<ReportsPage />} />
          <Route path="ayarlar" element={<AyarlarPage />} />
          <Route path="profil" element={<ProfilPage />} />
        </Route>

        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    </BrowserRouter>
  );
}