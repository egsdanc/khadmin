import React from 'react';
import { formatCurrency } from '../../../utils/format';
import { TestDetail } from '../../../types/test.types';

interface TestDetailPrintProps {
  test: TestDetail;
}

export function TestDetailPrint({ test }: TestDetailPrintProps) {
  return (
    <div className="p-8">
      <div className="text-center mb-8">
        <h1 className="text-2xl font-bold">Test Raporu</h1>
      </div>

      <div className="mb-8">
        <h2 className="text-lg font-semibold border-b pb-2 mb-4">Araç Bilgileri</h2>
        <div className="grid grid-cols-2 gap-4">
          <InfoField label="Plaka" value={test.plaka} />
          <InfoField label="Marka/Model" value={test.markaModel} />
          <InfoField label="Şase No" value={test.saseNo} />
          <InfoField label="Motor No" value={test.motorNo} />
          <InfoField label="Kontrol Mod" value={test.kontrolMod} />
          <InfoField label="Kilometre" value={test.km} />
        </div>
      </div>

      <div>
        <h2 className="text-lg font-semibold border-b pb-2 mb-4">Test Sonuçları</h2>
        <table className="min-w-full">
          <thead>
            <tr>
              <th className="text-left py-2 text-sm font-medium text-gray-900">Modül</th>
              <th className="text-left py-2 text-sm font-medium text-gray-900">Değer</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {test.details.map((detail) => (
              <tr key={detail.id}>
                <td className="py-2 text-sm">{detail.moduleName}</td>
                <td className="py-2 text-sm">{detail.value}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-8 pt-4 border-t">
        <div className="flex justify-end">
          <div>
            <p className="text-sm text-gray-600">Test Ücreti</p>
            <p className="font-medium text-lg">{formatCurrency(test.ucret)}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

interface InfoFieldProps {
  label: string;
  value: string;
}

function InfoField({ label, value }: InfoFieldProps) {
  return (
    <div>
      <p className="text-sm text-gray-600">{label}</p>
      <p className="font-medium">{value}</p>
    </div>
  );
}