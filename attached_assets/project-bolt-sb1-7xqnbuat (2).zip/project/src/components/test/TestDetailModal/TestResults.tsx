import React from 'react';
import { TestDetail } from '../../../types/test.types';

interface TestResultsProps {
  details: TestDetail['details'];
}

export function TestResults({ details }: TestResultsProps) {
  return (
    <div>
      <h4 className="text-sm font-medium text-gray-900 mb-4">Test Sonuçları</h4>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr>
              <th className="py-2 px-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-[50%]">
                Modül
              </th>
              <th className="py-2 px-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-[50%]">
                Değer
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {details.map((detail) => (
              <tr key={detail.id}>
                <td className="py-2 px-3">
                  <div className="text-sm text-gray-900 break-all" title={detail.moduleName}>
                    {detail.moduleName}
                  </div>
                </td>
                <td className="py-2 px-3">
                  <div className="text-sm text-gray-900 break-all" title={detail.value}>
                    {detail.value}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}