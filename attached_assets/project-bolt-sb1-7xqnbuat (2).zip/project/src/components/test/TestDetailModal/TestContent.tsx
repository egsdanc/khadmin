import React from 'react';
import { VehicleInfo } from './VehicleInfo';
import { TestResults } from './TestResults';
import { TestDetail } from '../../../types/test.types';

interface TestContentProps {
  test: TestDetail;
}

export function TestContent({ test }: TestContentProps) {
  return (
    <div className="space-y-6">
      <VehicleInfo test={test} />
      <TestResults details={test.details} />
    </div>
  );
}