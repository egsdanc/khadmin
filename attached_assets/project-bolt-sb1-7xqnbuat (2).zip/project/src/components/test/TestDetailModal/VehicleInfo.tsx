import React from 'react';
import { TestDetail } from '../../../types/test.types';

interface VehicleInfoProps {
  test: TestDetail;
}

export function VehicleInfo({ test }: VehicleInfoProps) {
  return (
    <div className="bg-gray-50 rounded-lg p-4">
      <h4 className="text-sm font-medium text-gray-900 mb-4">Araç Bilgileri</h4>
      <div className="grid grid-cols-2 gap-x-6 gap-y-4">
        <InfoField label="Plaka" value={test.plaka} />
        <InfoField label="Marka/Model" value={test.markaModel} />
        <InfoField label="Şase No" value={test.saseNo} />
        <InfoField label="Motor No" value={test.motorNo} />
        <InfoField label="Kontrol Mod" value={test.kontrolMod} />
        <InfoField label="Kilometre" value={test.km} />
      </div>
    </div>
  );
}

interface InfoFieldProps {
  label: string;
  value: string;
}

function InfoField({ label, value }: InfoFieldProps) {
  return (
    <div>
      <dt className="text-sm text-gray-500">{label}</dt>
      <dd className="mt-1 text-sm font-medium text-gray-900 break-all">{value}</dd>
    </div>
  );
}