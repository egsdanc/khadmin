import React from 'react';
import { formatCurrency } from '../../../../utils/format';

interface DetailContentProps {
  data: any;
  type: 'test' | 'vin';
}

export function DetailContent({ data, type }: DetailContentProps) {
  return (
    <div className="space-y-6">
      <div className="bg-gray-50 p-4 rounded-lg">
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          <InfoField label="Plaka" value={data.plaka} />
          <InfoField label="Şase No" value={type === 'test' ? data.saseNo : data.sase} />
          <InfoField label="Motor No" value={type === 'test' ? data.motorNo : data.motor} />
          <InfoField 
            label={type === 'test' ? 'Marka/Model' : 'Paket'} 
            value={type === 'test' ? data.markaModel : data.paket} 
          />
          <InfoField 
            label={type === 'test' ? 'Kilometre' : 'Kontrol Mod'} 
            value={type === 'test' ? data.km : data.kontrolmod} 
          />
          {type === 'test' && (
            <InfoField label="Kontrol Mod" value={data.kontrolMod} />
          )}
          <InfoField label="Ücret" value={formatCurrency(data.ucret)} className="text-green-600" />
          {type === 'vin' && (
            <InfoField label="Açıklama" value={data.aciklama} />
          )}
        </div>
      </div>

      <div>
        <h4 className="text-sm font-medium text-gray-900 mb-4">
          {type === 'test' ? 'Modül Detayları' : 'VIN Detayları'}
        </h4>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="py-2 text-left text-sm font-semibold text-gray-900 w-1/2 pl-4">
                  Modül
                </th>
                <th className="py-2 text-left text-sm font-semibold text-gray-900 w-1/4 pl-4">
                  {type === 'test' ? 'KM' : 'VIN 1'}
                </th>
                {type === 'vin' && (
                  <th className="py-2 text-left text-sm font-semibold text-gray-900 w-1/4 pl-4">
                    VIN 2
                  </th>
                )}
              </tr>
            </thead>
            <tbody>
              {data.details.map((detail: any) => (
                <tr key={detail.id} className="border-b border-gray-100">
                  <td className="py-2 text-sm text-gray-900 pl-4 text-left">
                    {detail.moduleName}
                  </td>
                  <td className="py-2 text-sm text-gray-900 pl-4 text-left">
                    {detail.value}
                  </td>
                  {type === 'vin' && (
                    <td className="py-2 text-sm text-gray-900 pl-4 text-left">
                      {detail.value2}
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

interface InfoFieldProps {
  label: string;
  value: string;
  className?: string;
}

function InfoField({ label, value, className }: InfoFieldProps) {
  return (
    <div>
      <label className="text-sm font-medium text-gray-500">{label}</label>
      <p className={`mt-1 text-sm text-gray-900 ${className || ''}`}>{value}</p>
    </div>
  );
}