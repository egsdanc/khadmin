import React from 'react';
import { formatCurrency } from '../../../utils/format';

interface DetailPrintProps {
  data: any;
  type: 'test' | 'vin';
}

export function DetailPrint({ data, type }: DetailPrintProps) {
  return (
    <div className="bg-white w-[210mm] min-h-[297mm] p-[20mm] mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-2xl font-bold">
          {type === 'test' ? 'Kilometre Hacker' : 'VIN Hacker'}
        </h1>
        <p className="text-gray-500 text-sm">
          {new Date(data.tarih).toLocaleString('tr-TR')}
        </p>
      </div>

      <div className="mb-8">
        <h2 className="text-lg font-semibold border-b pb-2 mb-4">Araç Bilgileri</h2>
        <div className="grid grid-cols-2 gap-4">
          <InfoField label="Plaka" value={data.plaka} />
          <InfoField 
            label={type === 'test' ? 'Marka/Model' : 'Paket'} 
            value={type === 'test' ? data.markaModel : data.paket} 
          />
          <InfoField 
            label="Şase No" 
            value={type === 'test' ? data.saseNo : data.sase} 
          />
          <InfoField 
            label="Motor No" 
            value={type === 'test' ? data.motorNo : data.motor} 
          />
          <InfoField 
            label="Kontrol Mod" 
            value={type === 'test' ? data.kontrolMod : data.kontrolmod} 
          />
          {type === 'test' ? (
            <InfoField label="Kilometre" value={data.km} />
          ) : (
            <InfoField label="Açıklama" value={data.aciklama} />
          )}
        </div>
      </div>

      <div>
        <h2 className="text-lg font-semibold border-b pb-2 mb-4">
          {type === 'test' ? 'Modül Detayları' : 'VIN Detayları'}
        </h2>
        <table className="w-full">
          <thead>
            <tr className="border-b">
              <th className="text-left py-2 text-sm font-medium text-gray-900">Modül</th>
              <th className="text-left py-2 text-sm font-medium text-gray-900">
                {type === 'test' ? 'KM' : 'VIN 1'}
              </th>
              {type === 'vin' && (
                <th className="text-left py-2 text-sm font-medium text-gray-900">VIN 2</th>
              )}
            </tr>
          </thead>
          <tbody className="divide-y">
            {data.details.map((detail: any) => (
              <tr key={detail.id}>
                <td className="py-2 text-sm text-left">{detail.moduleName}</td>
                <td className="py-2 text-sm text-left">{detail.value}</td>
                {type === 'vin' && (
                  <td className="py-2 text-sm text-left">{detail.value2}</td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-8 pt-4 border-t">
        <div className="flex justify-between items-center">
          <div>
            <p className="text-sm text-gray-600">Test Ücreti</p>
            <p className="font-medium text-lg">{formatCurrency(data.ucret)}</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-600">Rapor Tarihi</p>
            <p className="font-medium">{new Date().toLocaleDateString('tr-TR')}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

interface InfoFieldProps {
  label: string;
  value: string;
}

function InfoField({ label, value }: InfoFieldProps) {
  return (
    <div>
      <p className="text-sm text-gray-600">{label}</p>
      <p className="font-medium">{value}</p>
    </div>
  );
}