import React from 'react';
import { Wallet, Building2, Receipt, Calculator } from 'lucide-react';
import { formatCurrency } from '../../utils/format';
import { CompanyRevenue } from '../../utils/revenue';

interface RevenueCardsProps {
  data: {
    companies: CompanyRevenue[];
  };
}

export function RevenueCards({ data }: RevenueCardsProps) {
  // Toplam sistem geliri (firma payı + super admin payı + KDV'ler)
  const totalSystemRevenue = data.companies.reduce((sum, company) => 
    sum + company.systemShare + company.kdvAmount, 0
  );

  // Firma bazlı toplam gelir (bayilerin geliri)
  const totalCompanyRevenue = data.companies.reduce((sum, company) => 
    sum + company.revenue, 0
  );

  // Emre Söken geliri (super admin payı + KDV)
  const emreSokenRevenue = data.companies.reduce((sum, company) => 
    sum + company.superAdminShare + company.superAdminKdv, 0
  );

  // Toplam KDV
  const totalKdv = data.companies.reduce((sum, company) => 
    sum + company.kdvAmount, 0
  );

  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
      {/* Toplam Bayi Geliri */}
      <div className="bg-blue-50 overflow-hidden rounded-lg p-6">
        <div className="flex items-center">
          <div className="flex-shrink-0">
            <Building2 className="h-6 w-6 text-blue-600" />
          </div>
          <div className="ml-4 w-full">
            <p className="truncate text-sm font-medium text-blue-600">Bayi Gelirleri</p>
            <p className="mt-1 text-xl font-semibold text-blue-900">
              {formatCurrency(totalCompanyRevenue)}
            </p>
            <p className="mt-1 text-xs text-blue-600">%90 pay</p>
          </div>
        </div>
      </div>

      {/* Sistem Geliri */}
      <div className="bg-indigo-50 overflow-hidden rounded-lg p-6">
        <div className="flex items-center">
          <div className="flex-shrink-0">
            <Receipt className="h-6 w-6 text-indigo-600" />
          </div>
          <div className="ml-4 w-full">
            <p className="truncate text-sm font-medium text-indigo-600">Sistem Geliri</p>
            <p className="mt-1 text-xl font-semibold text-indigo-900">
              {formatCurrency(totalSystemRevenue)}
            </p>
            <p className="mt-1 text-xs text-indigo-600">%10 firma + %2 admin + KDV</p>
          </div>
        </div>
      </div>

      {/* Emre Söken Geliri */}
      <div className="bg-green-50 overflow-hidden rounded-lg p-6">
        <div className="flex items-center">
          <div className="flex-shrink-0">
            <Wallet className="h-6 w-6 text-green-600" />
          </div>
          <div className="ml-4 w-full">
            <p className="truncate text-sm font-medium text-green-600">Emre Söken Geliri</p>
            <p className="mt-1 text-xl font-semibold text-green-900">
              {formatCurrency(emreSokenRevenue)}
            </p>
            <p className="mt-1 text-xs text-green-600">%2 + KDV</p>
          </div>
        </div>
      </div>

      {/* KDV */}
      <div className="bg-purple-50 overflow-hidden rounded-lg p-6">
        <div className="flex items-center">
          <div className="flex-shrink-0">
            <Calculator className="h-6 w-6 text-purple-600" />
          </div>
          <div className="ml-4 w-full">
            <p className="truncate text-sm font-medium text-purple-600">Toplam KDV</p>
            <p className="mt-1 text-xl font-semibold text-purple-900">
              {formatCurrency(totalKdv)}
            </p>
            <p className="mt-1 text-xs text-purple-600">%20 KDV</p>
          </div>
        </div>
      </div>
    </div>
  );
}