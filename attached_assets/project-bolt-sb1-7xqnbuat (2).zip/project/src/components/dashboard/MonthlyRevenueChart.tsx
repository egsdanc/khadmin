import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { formatCurrency } from '../../utils/format';

// Son 12 aylık örnek veri
const monthlyData = [
  { month: 'Ocak', bayiGeliri: 225000, sistemGeliri: 25000, adminGeliri: 5000 },
  { month: 'Şubat', bayiGeliri: 210000, sistemGeliri: 23333, adminGeliri: 4667 },
  { month: 'Mart', bayiGeliri: 200000, sistemGeliri: 22222, adminGeliri: 4444 },
  { month: 'Nisan', bayiGeliri: 180000, sistemGeliri: 20000, adminGeliri: 4000 },
  { month: 'Mayıs', bayiGeliri: 195000, sistemGeliri: 21667, adminGeliri: 4333 },
  { month: 'Haziran', bayiGeliri: 215000, sistemGeliri: 23889, adminGeliri: 4778 },
  { month: 'Temmuz', bayiGeliri: 230000, sistemGeliri: 25556, adminGeliri: 5111 },
  { month: 'Ağustos', bayiGeliri: 245000, sistemGeliri: 27222, adminGeliri: 5444 },
  { month: 'Eylül', bayiGeliri: 235000, sistemGeliri: 26111, adminGeliri: 5222 },
  { month: 'Ekim', bayiGeliri: 220000, sistemGeliri: 24444, adminGeliri: 4889 },
  { month: 'Kasım', bayiGeliri: 240000, sistemGeliri: 26667, adminGeliri: 5333 },
  { month: 'Aralık', bayiGeliri: 250000, sistemGeliri: 27778, adminGeliri: 5556 }
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white p-4 border border-gray-200 shadow-lg rounded-lg">
        <p className="text-sm font-semibold mb-2">{label}</p>
        {payload.map((entry: any, index: number) => (
          <p key={index} className="text-sm" style={{ color: entry.color }}>
            {entry.name}: {formatCurrency(entry.value)}
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export function MonthlyRevenueChart() {
  const [activeType, setActiveType] = useState('all');

  const chartData = monthlyData.map(item => ({
    month: item.month,
    'Bayi Geliri': item.bayiGeliri,
    'Sistem Geliri': item.sistemGeliri,
    'Emre Söken Geliri': item.adminGeliri
  }));

  return (
    <div className="bg-white p-6 rounded-lg shadow">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-base font-semibold text-gray-900">
          Aylık Gelir Dağılımı
        </h3>
        <div className="flex gap-2">
          <button
            onClick={() => setActiveType('all')}
            className={`px-3 py-1 rounded text-sm ${
              activeType === 'all' 
                ? 'bg-indigo-100 text-indigo-700' 
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Tümü
          </button>
          <button
            onClick={() => setActiveType('bayi')}
            className={`px-3 py-1 rounded text-sm ${
              activeType === 'bayi' 
                ? 'bg-blue-100 text-blue-700' 
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Bayi
          </button>
          <button
            onClick={() => setActiveType('sistem')}
            className={`px-3 py-1 rounded text-sm ${
              activeType === 'sistem' 
                ? 'bg-green-100 text-green-700' 
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Sistem
          </button>
          <button
            onClick={() => setActiveType('admin')}
            className={`px-3 py-1 rounded text-sm ${
              activeType === 'admin' 
                ? 'bg-purple-100 text-purple-700' 
                : 'text-gray-600 hover:bg-gray-100'
            }`}
          >
            Emre Söken
          </button>
        </div>
      </div>

      <div className="h-[400px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis 
              tickFormatter={(value) => `₺${value.toLocaleString()}`}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            {(activeType === 'all' || activeType === 'bayi') && (
              <Bar 
                dataKey="Bayi Geliri" 
                fill="#3B82F6" 
                name="Bayi Geliri"
              />
            )}
            {(activeType === 'all' || activeType === 'sistem') && (
              <Bar 
                dataKey="Sistem Geliri" 
                fill="#10B981" 
                name="Sistem Geliri"
              />
            )}
            {(activeType === 'all' || activeType === 'admin') && (
              <Bar 
                dataKey="Emre Söken Geliri" 
                fill="#8B5CF6" 
                name="Emre Söken Geliri"
              />
            )}
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}