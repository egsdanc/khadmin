import React from 'react';
import { formatCurrency } from '../../utils/format';
import { useAuthStore } from '../../store/auth.store';
import { BalanceService } from '../../services/balance/balance.service';

export function BalanceInfo() {
  const user = useAuthStore(state => state.user);
  const calculation = BalanceService.calculateTestFee();

  return (
    <div className="bg-white p-4 rounded-lg shadow">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Bakiye Bilgileri</h3>
      
      <div className="space-y-3">
        <div className="flex justify-between">
          <span className="text-gray-500">Test Ücreti:</span>
          <span className="font-medium">{formatCurrency(calculation.testFee)}</span>
        </div>
        
        <div className="flex justify-between">
          <span className="text-gray-500">Sistem Payı (%10):</span>
          <span className="text-red-600">-{formatCurrency(calculation.systemShare)}</span>
        </div>
        
        <div className="flex justify-between">
          <span className="text-gray-500">KDV (%20):</span>
          <span className="text-red-600">-{formatCurrency(calculation.kdv)}</span>
        </div>
        
        <div className="border-t pt-2">
          <div className="flex justify-between font-medium">
            <span className="text-gray-900">Toplam Kesinti:</span>
            <span className="text-red-600">-{formatCurrency(calculation.totalDeduction)}</span>
          </div>
        </div>
        
        <div className="border-t pt-2">
          <div className="flex justify-between font-medium">
            <span className="text-gray-900">Bayiye Kalan:</span>
            <span className="text-green-600">{formatCurrency(calculation.dealerBalance)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}