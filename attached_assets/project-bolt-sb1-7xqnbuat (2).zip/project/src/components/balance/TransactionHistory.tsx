import React from 'react';
import { formatCurrency } from '../../utils/format';
import { Badge } from '../ui/Badge';
import { BalanceTransaction } from '../../types/balance.types';

interface TransactionHistoryProps {
  transactions: BalanceTransaction[];
}

export function TransactionHistory({ transactions }: TransactionHistoryProps) {
  // Toplam tutarları hesapla
  const totals = transactions.reduce((acc, transaction) => {
    if (transaction.type === 'DEPOSIT') {
      acc.totalDeposits += transaction.amount;
    } else {
      acc.totalDeductions += transaction.amount;
    }
    return acc;
  }, { totalDeposits: 0, totalDeductions: 0 });

  return (
    <div className="bg-white p-4 rounded-lg shadow">
      <h3 className="text-base font-semibold text-gray-900 mb-4">
        İşlem Geçmişi
      </h3>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Tarih
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                İşlem
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Tutar
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                Açıklama
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {transactions.map((transaction) => (
              <tr key={transaction.id}>
                <td className="px-4 py-3 text-sm text-gray-900">
                  {new Date(transaction.createdAt).toLocaleString('tr-TR')}
                </td>
                <td className="px-4 py-3">
                  <Badge
                    variant={transaction.type === 'DEPOSIT' ? 'success' : 'danger'}
                  >
                    {transaction.type === 'DEPOSIT' ? 'Yükleme' : 'Kesinti'}
                  </Badge>
                </td>
                <td className="px-4 py-3 text-sm">
                  <span className={transaction.type === 'DEPOSIT' ? 'text-green-600' : 'text-red-600'}>
                    {transaction.type === 'DEPOSIT' ? '+' : '-'}
                    {formatCurrency(transaction.amount)}
                  </span>
                </td>
                <td className="px-4 py-3 text-sm text-gray-500">
                  {transaction.description}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Toplam Tutarlar */}
      <div className="mt-6 border-t pt-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="bg-green-50 p-4 rounded-lg">
            <p className="text-sm text-green-600 font-medium">Toplam Yükleme</p>
            <p className="mt-1 text-2xl font-semibold text-green-700">
              {formatCurrency(totals.totalDeposits)}
            </p>
          </div>
          <div className="bg-red-50 p-4 rounded-lg">
            <p className="text-sm text-red-600 font-medium">Toplam Kesinti</p>
            <p className="mt-1 text-2xl font-semibold text-red-700">
              {formatCurrency(totals.totalDeductions)}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}