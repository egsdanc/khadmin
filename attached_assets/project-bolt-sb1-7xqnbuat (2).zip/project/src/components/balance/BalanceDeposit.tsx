import React, { useState } from 'react';
import { PlusCircle } from 'lucide-react';
import { Input } from '../ui/Input';
import { Select } from '../ui/Select';
import { Button } from '../ui/Button';
import { balanceApi } from '../../services/balance/balance.api';
import toast from 'react-hot-toast';

interface BalanceDepositProps {
  onSuccess?: () => void;
}

export function BalanceDeposit({ onSuccess }: BalanceDepositProps) {
  const [formData, setFormData] = useState({
    amount: '',
    firma: '',
    bayi: ''
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await balanceApi.depositBalance(Number(formData.bayi), Number(formData.amount));
      toast.success('Bakiye yükleme işlemi başarılı');
      setFormData({ amount: '', firma: '', bayi: '' });
      onSuccess?.();
    } catch (error) {
      toast.error('Bakiye yükleme işlemi başarısız');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white p-4 rounded-lg shadow">
      <h3 className="text-lg font-medium text-gray-900 mb-4">Bakiye Yükle</h3>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <Select
          label="Firma"
          name="firma"
          value={formData.firma}
          onChange={handleChange}
          required
        >
          <option value="">Firma Seçiniz</option>
          <option value="1">Garantili Arabam</option>
          <option value="2">General Oto Ekspertiz</option>
          <option value="3">Dynobil</option>
        </Select>

        <Select
          label="Bayi"
          name="bayi"
          value={formData.bayi}
          onChange={handleChange}
          required
        >
          <option value="">Bayi Seçiniz</option>
          <option value="1">Ankara / Yenimahalle</option>
          <option value="2">İstanbul / Kadıköy</option>
          <option value="3">İzmir / Karşıyaka</option>
        </Select>

        <Input
          label="Yüklenecek Tutar"
          name="amount"
          type="number"
          value={formData.amount}
          onChange={handleChange}
          min="1"
          required
          placeholder="Tutar giriniz"
        />
        
        <Button
          type="submit"
          loading={loading}
          className="w-full flex items-center justify-center gap-2"
        >
          <PlusCircle className="h-4 w-4" />
          Bakiye Yükle
        </Button>
      </form>
    </div>
  );
}