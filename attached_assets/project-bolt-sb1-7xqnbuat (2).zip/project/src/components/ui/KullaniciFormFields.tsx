import React from 'react';
import { Input } from './Input';
import { Select } from './Select';

interface KullaniciFormFieldsProps {
  formData: Record<string, string>;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
}

export function KullaniciFormFields({ formData, onChange }: KullaniciFormFieldsProps) {
  return (
    <div className="grid grid-cols-1 gap-x-6 gap-y-8">
      <div className="col-span-full">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Input
            label="Ad"
            name="ad"
            required
            placeholder="Kullanıcı adını giriniz"
            value={formData.ad}
            onChange={onChange}
          />
          <Input
            label="E-posta"
            name="email"
            type="email"
            required
            placeholder="E-posta adresini giriniz"
            value={formData.email}
            onChange={onChange}
          />
          <Input
            label="Şifre"
            name="password"
            type="password"
            required
            placeholder="Şifre giriniz"
            value={formData.password}
            onChange={onChange}
          />
          <Select
            label="Firma"
            name="firma"
            required
            value={formData.firma}
            onChange={onChange}
          >
            <option value="">Firma Seçiniz</option>
            <option value="0">Merkez</option>
            <option value="1">Firma 1</option>
            <option value="2">Firma 2</option>
          </Select>
          <Select
            label="Rol"
            name="role"
            required
            value={formData.role}
            onChange={onChange}
          >
            <option value="">Rol Seçiniz</option>
            <option value="1">Super Admin</option>
            <option value="2">Admin</option>
            <option value="3">Bayi</option>
          </Select>
          <Select
            label="Bayi"
            name="bayi"
            value={formData.bayi}
            onChange={onChange}
          >
            <option value="">Bayi Seçiniz</option>
            <option value="1">Bayi 1</option>
            <option value="2">Bayi 2</option>
          </Select>
        </div>
      </div>
    </div>
  );
}