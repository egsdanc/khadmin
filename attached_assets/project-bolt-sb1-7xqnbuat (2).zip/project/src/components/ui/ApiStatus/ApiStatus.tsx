import React from 'react';
import { useHealthCheck } from '../../../services/api/health/hooks/useHealthCheck';
import { cn } from '../../../utils/cn';
import { StatusIcon } from './StatusIcon';
import { DatabaseStatus } from './DatabaseStatus';

export function ApiStatus() {
  const status = useHealthCheck();

  if (!status) return null;

  return (
    <div
      className={cn(
        'fixed bottom-4 right-4 p-4 rounded-lg shadow-lg transition-colors duration-200',
        status.isHealthy ? 'bg-green-50' : 'bg-red-50'
      )}
    >
      <div className="flex flex-col gap-2">
        <div className="flex items-center gap-2">
          <StatusIcon isHealthy={status.isHealthy} />
          <span className={cn('text-sm', status.isHealthy ? 'text-green-700' : 'text-red-700')}>
            {status.isHealthy ? 'Sistem çalışıyor' : 'Bağlantı hatası'}
          </span>
        </div>
        <DatabaseStatus 
          isConnected={status.database}
          message={status.message}
        />
      </div>
    </div>
  );
}