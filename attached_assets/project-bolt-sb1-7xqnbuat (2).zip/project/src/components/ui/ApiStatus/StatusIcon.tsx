import React from 'react';
import { AlertCircle, CheckCircle2 } from 'lucide-react';

interface StatusIconProps {
  isHealthy: boolean;
}

export function StatusIcon({ isHealthy }: StatusIconProps) {
  if (isHealthy) {
    return <CheckCircle2 className="h-5 w-5 text-green-500" />;
  }
  return <AlertCircle className="h-5 w-5 text-red-500" />;
}