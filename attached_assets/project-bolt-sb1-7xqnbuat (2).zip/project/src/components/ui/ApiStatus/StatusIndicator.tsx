import React from 'react';
import { AlertCircle, CheckCircle2 } from 'lucide-react';
import { cn } from '../../../utils/cn';

interface StatusIndicatorProps {
  isHealthy: boolean;
}

export function StatusIndicator({ isHealthy }: StatusIndicatorProps) {
  return (
    <div className="flex items-center gap-2">
      {isHealthy ? (
        <CheckCircle2 className="h-5 w-5 text-green-500" />
      ) : (
        <AlertCircle className="h-5 w-5 text-red-500" />
      )}
      <span className={cn('text-sm', isHealthy ? 'text-green-700' : 'text-red-700')}>
        {isHealthy ? 'Sistem çalışıyor' : 'Bağlantı hatası'}
      </span>
    </div>
  );
}