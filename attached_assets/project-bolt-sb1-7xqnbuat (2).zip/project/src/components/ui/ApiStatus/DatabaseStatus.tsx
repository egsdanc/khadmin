import React from 'react';
import { Database } from 'lucide-react';
import { cn } from '../../../utils/cn';

interface DatabaseStatusProps {
  isConnected: boolean;
  message: string;
}

export function DatabaseStatus({ isConnected, message }: DatabaseStatusProps) {
  return (
    <div className="flex items-center gap-2">
      <Database className={cn(
        'h-5 w-5',
        isConnected ? 'text-green-500' : 'text-red-500'
      )} />
      <span className={cn(
        'text-sm',
        isConnected ? 'text-green-700' : 'text-red-700'
      )}>
        {message}
      </span>
    </div>
  );
}