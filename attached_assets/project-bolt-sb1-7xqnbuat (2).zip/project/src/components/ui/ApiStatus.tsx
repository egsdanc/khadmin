import React from 'react';
import { CheckCircle2 } from 'lucide-react';

export function ApiStatus() {
  return (
    <div className="fixed bottom-4 right-4 p-4 rounded-lg shadow-lg bg-green-50">
      <div className="flex items-center gap-2">
        <CheckCircle2 className="h-5 w-5 text-green-500" />
        <span className="text-sm text-green-700">Sistem çalışıyor</span>
      </div>
    </div>
  );
}