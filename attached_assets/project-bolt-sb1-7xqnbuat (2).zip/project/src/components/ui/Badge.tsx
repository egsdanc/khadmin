import { cn } from "@/utils/cn"

interface BadgeProps extends React.HTMLAttributes<HTMLDivElement> {
  variant?: 'default' | 'secondary' | 'success' | 'warning' | 'danger';
}

export function Badge({ 
  className, 
  variant = 'default', 
  ...props 
}: BadgeProps) {
  return (
    <div
      className={cn(
        "inline-flex items-center rounded-md px-2 py-1 text-xs font-medium ring-1 ring-inset",
        {
          'bg-gray-50 text-gray-600 ring-gray-500/10': variant === 'default',
          'bg-indigo-50 text-indigo-700 ring-indigo-600/20': variant === 'secondary',
          'bg-green-50 text-green-700 ring-green-600/20': variant === 'success',
          'bg-yellow-50 text-yellow-700 ring-yellow-600/20': variant === 'warning',
          'bg-red-50 text-red-700 ring-red-600/20': variant === 'danger',
        },
        className
      )}
      {...props}
    />
  )
}