import React from 'react';
import { ShieldAlert } from 'lucide-react';

export function LoginFormHeader() {
  return (
    <div className="text-center">
      <div className="flex justify-center mb-6">
        <ShieldAlert className="h-12 w-12 text-indigo-600" />
      </div>
      <h2 className="text-3xl font-extrabold text-gray-900 mb-2">
        Kilometre Hacker Yönetim Paneli
      </h2>
      <p className="text-gray-600">
        Kilometre Hacker: Aracınızın Aklını Alır!
      </p>
    </div>
  );
}