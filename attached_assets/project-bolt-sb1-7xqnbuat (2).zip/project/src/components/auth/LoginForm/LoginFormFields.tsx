import React from 'react';
import { Lock, User } from 'lucide-react';
import { Input } from '../../ui/Input';

interface LoginFormFieldsProps {
  username: string;
  password: string;
  errors: {
    username?: string;
    password?: string;
  };
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export function LoginFormFields({
  username,
  password,
  errors,
  onChange
}: LoginFormFieldsProps) {
  return (
    <>
      <Input
        id="username"
        name="username"
        type="text"
        required
        icon={User}
        placeholder="Kullanıcı adı"
        value={username}
        onChange={onChange}
        error={errors.username}
      />
      
      <Input
        id="password"
        name="password"
        type="password"
        required
        icon={Lock}
        placeholder="Şifre"
        value={password}
        onChange={onChange}
        error={errors.password}
      />
    </>
  );
}