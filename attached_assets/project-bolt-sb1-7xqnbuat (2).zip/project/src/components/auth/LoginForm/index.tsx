import React from 'react';
import { Button } from '../../ui/Button';
import { LoginFormHeader } from './LoginFormHeader';
import { LoginFormFields } from './LoginFormFields';
import { useLoginForm } from './useLoginForm';

export function LoginForm() {
  const { formState, loading, handleSubmit, handleChange } = useLoginForm();

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-50 to-blue-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full">
        <LoginFormHeader />
        
        <div className="mt-8 bg-white py-8 px-4 shadow-lg sm:rounded-lg sm:px-10">
          <form className="space-y-6" onSubmit={handleSubmit}>
            <LoginFormFields
              username={formState.username}
              password={formState.password}
              errors={formState.errors}
              onChange={handleChange}
            />

            <Button
              type="submit"
              loading={loading}
              className="w-full"
            >
              Giriş Yap
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}