import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { AuthService } from '../../../services/auth/auth.service';
import { useAuthStore } from '../../../store/auth.store';
import { UserRoles } from '../../../types/auth';
import { API_MESSAGES } from '../../../config/api.config';
import { AUTH_MESSAGES } from '../../../constants/auth.constants';

interface LoginFormState {
  username: string;
  password: string;
  errors: {
    username?: string;
    password?: string;
  };
}

interface UseLoginForm {
  formState: LoginFormState;
  loading: boolean;
  handleSubmit: (e: React.FormEvent) => Promise<void>;
  handleChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export function useLoginForm(): UseLoginForm {
  const [formState, setFormState] = useState<LoginFormState>({
    username: '',
    password: '',
    errors: {}
  });
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const setAuth = useAuthStore((state) => state.setAuth);

  const validateForm = (): boolean => {
    const errors: LoginFormState['errors'] = {};

    if (!formState.username) {
      errors.username = AUTH_MESSAGES.VALIDATION.USERNAME_REQUIRED;
    }

    if (!formState.password) {
      errors.password = AUTH_MESSAGES.VALIDATION.PASSWORD_REQUIRED;
    } else if (formState.password.length < 1) {
      errors.password = AUTH_MESSAGES.VALIDATION.PASSWORD_MIN_LENGTH;
    }

    setFormState(prev => ({ ...prev, errors }));
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent): Promise<void> => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setLoading(true);

    try {
      const response = await AuthService.login({
        username: formState.username,
        password: formState.password
      });
      
      setAuth(response.user, response.token);
      
      if (response.user.role === UserRoles.SUPER_ADMIN) {
        toast.success(API_MESSAGES.SUPER_ADMIN_LOGIN);
        navigate('/dashboard');
      } else {
        toast.success(API_MESSAGES.LOGIN_SUCCESS);
        navigate('/dashboard');
      }
    } catch (error) {
      toast.error(API_MESSAGES.LOGIN_FAILED);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>): void => {
    const { name, value } = e.target;
    setFormState(prev => ({
      ...prev,
      [name]: value,
      errors: {
        ...prev.errors,
        [name]: undefined
      }
    }));
  };

  return {
    formState,
    loading,
    handleSubmit,
    handleChange
  };
}