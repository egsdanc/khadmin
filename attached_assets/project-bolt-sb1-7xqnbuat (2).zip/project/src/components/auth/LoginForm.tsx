import { LoginForm } from './LoginForm/index';

export { LoginForm };
export default LoginForm;