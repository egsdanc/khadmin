import React, { useEffect } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { AuthService } from '../../services/auth/auth.service';

interface ProtectedRouteProps {
  children: React.ReactNode;
}

export function ProtectedRoute({ children }: ProtectedRouteProps) {
  const location = useLocation();
  const isAuthenticated = AuthService.isAuthenticated();

  useEffect(() => {
    if (!isAuthenticated) {
      localStorage.setItem('redirectPath', location.pathname);
    }
  }, [isAuthenticated, location]);

  if (!isAuthenticated) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  return <>{children}</>;
}