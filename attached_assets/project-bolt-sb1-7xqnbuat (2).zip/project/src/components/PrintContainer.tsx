import React, { forwardRef } from 'react';

interface PrintContainerProps {
  children: React.ReactNode;
}

export const PrintContainer = forwardRef<HTMLDivElement, PrintContainerProps>(
  ({ children }, ref) => (
    <div ref={ref} className="print-content">
      {children}
    </div>
  )
);

PrintContainer.displayName = 'PrintContainer';