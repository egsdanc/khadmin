import React, { Fragment } from 'react';
import { Menu, Transition } from '@headlessui/react';
import { NotificationBell } from './NotificationBell';
import { NotificationList } from './NotificationList';
import { useNotificationStore } from '../../services/notifications/notification.store';
import { Button } from '../ui/Button';

export function NotificationDropdown() {
  const { markAllAsRead, clearAll } = useNotificationStore();

  return (
    <Menu as="div" className="relative inline-block text-left">
      <Menu.Button className="flex items-center">
        <NotificationBell />
      </Menu.Button>

      <Transition
        as={Fragment}
        enter="transition ease-out duration-100"
        enterFrom="transform opacity-0 scale-95"
        enterTo="transform opacity-100 scale-100"
        leave="transition ease-in duration-75"
        leaveFrom="transform opacity-100 scale-100"
        leaveTo="transform opacity-0 scale-95"
      >
        <Menu.Items className="absolute right-0 mt-2 w-96 origin-top-right rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
          <div className="p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">
                Bildirimler
              </h3>
              <div className="flex gap-2">
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => markAllAsRead()}
                >
                  Tümünü Okundu İşaretle
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => clearAll()}
                >
                  Temizle
                </Button>
              </div>
            </div>
            <NotificationList />
          </div>
        </Menu.Items>
      </Transition>
    </Menu>
  );
}