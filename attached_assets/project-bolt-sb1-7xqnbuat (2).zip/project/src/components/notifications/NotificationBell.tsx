import React from 'react';
import { Bell } from 'lucide-react';
import { useNotificationStore } from '../../services/notifications/notification.store';
import { cn } from '../../utils/cn';

export function NotificationBell() {
  const unreadCount = useNotificationStore((state) => state.unreadCount);

  return (
    <div className="relative">
      <Bell className="h-6 w-6 text-gray-400 hover:text-gray-500 cursor-pointer" />
      {unreadCount > 0 && (
        <span className={cn(
          "absolute -top-1 -right-1 h-4 w-4 rounded-full",
          "bg-red-500 text-white text-xs flex items-center justify-center",
          "animate-pulse"
        )}>
          {unreadCount}
        </span>
      )}
    </div>
  );
}