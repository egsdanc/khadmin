import React from 'react';
import { useNotificationStore } from '../../services/notifications/notification.store';
import { formatDistanceToNow } from 'date-fns';
import { tr } from 'date-fns/locale';
import { X, CheckCircle, AlertCircle, Info, AlertTriangle } from 'lucide-react';
import { cn } from '../../utils/cn';

export function NotificationList() {
  const { notifications, markAsRead, removeNotification } = useNotificationStore();

  const getIcon = (type: string) => {
    switch (type) {
      case 'success':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      default:
        return <Info className="h-5 w-5 text-blue-500" />;
    }
  };

  return (
    <div className="max-h-[400px] overflow-y-auto divide-y divide-gray-200">
      {notifications.length === 0 ? (
        <div className="p-4 text-center text-gray-500">
          Bildirim bulunmuyor
        </div>
      ) : (
        notifications.map((notification) => (
          <div
            key={notification.id}
            className={cn(
              "p-4 hover:bg-gray-50 transition-colors",
              !notification.read && "bg-blue-50"
            )}
            onClick={() => markAsRead(notification.id)}
          >
            <div className="flex items-start">
              <div className="flex-shrink-0">
                {getIcon(notification.type)}
              </div>
              <div className="ml-3 flex-1">
                <p className="text-sm font-medium text-gray-900">
                  {notification.title}
                </p>
                <p className="mt-1 text-sm text-gray-500">
                  {notification.message}
                </p>
                <p className="mt-1 text-xs text-gray-400">
                  {formatDistanceToNow(notification.timestamp, { 
                    addSuffix: true,
                    locale: tr 
                  })}
                </p>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  removeNotification(notification.id);
                }}
                className="ml-4 text-gray-400 hover:text-gray-500"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>
        ))
      )}
    </div>
  );
}